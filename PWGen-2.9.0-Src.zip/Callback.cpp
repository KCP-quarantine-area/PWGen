// Callback.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Callback.h"
#include "Language.h"
#include "Main.h"
#include "Util.h"
#include "TopMostManager.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "TntStdCtrls"
#pragma link "TntComCtrls"
#pragma resource "*.dfm"
TCallbackForm *CallbackForm;
//---------------------------------------------------------------------------
__fastcall TCallbackForm::TCallbackForm(TComponent* Owner)
        : TTntForm(Owner), m_state(STATE_IDLE)
{
  m_sErrMsg = UTF8Encode(TRL("Process was cancelled by the user"));
}
//---------------------------------------------------------------------------
void __fastcall TCallbackForm::Init(TForm* pCaller,
                                    const WString& sTitle,
                                    const WString& sProgressInfo,
                                    int nMaxValue)
{
  m_pCaller = pCaller;
  m_sProgressInfo = sProgressInfo;
  m_nMaxValue = nMaxValue;

  Caption = sTitle;
  ProgressBar->Max = nMaxValue;
  ProgressBar->Position = 0;

  Top = MainForm->Top + (MainForm->Height - Height) / 2;
  Left = MainForm->Left + (MainForm->Width - Width) / 2;

  m_pCaller->Enabled = false;
  m_state = STATE_RUNNING;

  Show();
}
//---------------------------------------------------------------------------
void __fastcall TCallbackForm::Callback(int nValue)
{
  ProgressBar->Position = nValue;
  ProgressLbl->Caption = FormatW(m_sProgressInfo, nValue, m_nMaxValue);

  Application->ProcessMessages();

  if (m_state == STATE_CANCELED) {
    m_state = STATE_RUNNING;
    throw ECallback(m_sErrMsg);
  }
}
//---------------------------------------------------------------------------
void __fastcall TCallbackForm::Terminate(void)
{
  m_pCaller->Enabled = true;
  m_state = STATE_IDLE;
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TCallbackForm::CancelBtnClick(TObject *Sender)
{
  m_state = STATE_CANCELED;
}
//---------------------------------------------------------------------------
void __fastcall TCallbackForm::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
  if (Key == VK_ESCAPE || (Shift.Contains(ssCtrl) && (Key == 'C' || Key == 'Q' || Key == 'X')))
    m_state = STATE_CANCELED;
}
//---------------------------------------------------------------------------
void __fastcall TCallbackForm::TntFormShow(TObject *Sender)
{
  TopMostManager::GetInstance()->SetForm(this);
}
//---------------------------------------------------------------------------

