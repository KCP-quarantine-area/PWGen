// Util.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#include <stdio.h>
#include <clipbrd.hpp>
#include <vector>
#include <exception>
#include <stdexcept>
#include <shfolder.h>
#pragma hdrstop

#include "Util.h"
#include "MemUtil.h"
#include "hrtimer.h"
#include "Language.h"
#include "Main.h"
#include "sha256.h"
#include "FastPRNG.h"
#include "EntropyManager.h"
#include "TntComCtrls.hpp"
#include "dragdrop.h"
#include "TopMostManager.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

WString g_msgBoxCaptionList[4] =
  { L"Info", L"Warning", L"Question", L"Error" };

//---------------------------------------------------------------------------
static void strCr2Crlf(SecureWString& sSrc)
{
  wchar_t* pwszBuf = sSrc.Data();

  int nNumCR = 0;
  while ((pwszBuf = wcschr(pwszBuf, '\r')) != NULL) {
    if (*++pwszBuf == '\n')
      return;
    nNumCR++;
  }

  if (nNumCR == 0)
    return;

  int nSize = sSrc.Size();
  SecureWString sTemp(nSize + nNumCR);
  for (int nI = 0, nJ = 0; nI < nSize; nI++) {
    sTemp[nJ++] = sSrc[nI];
    if (sSrc[nI] == '\r')
      sTemp[nJ++] = '\n';
  }

  sSrc = sTemp;
}
//---------------------------------------------------------------------------
int MsgBox(const WString& sText,
           int nFlags)
{
  int nIcon = nFlags & 0xFF;
  int nListIndex = 0;

  if (nIcon >= MB_ICONINFORMATION)
    nListIndex = 0;
  else if (nIcon >= MB_ICONWARNING)
    nListIndex = 1;
  else if (nIcon >= MB_ICONQUESTION)
    nListIndex = 2;
  else if (nIcon >= MB_ICONERROR)
    nListIndex = 3;

  if (TopMostManager::GetInstance()->AlwaysOnTop)
    nFlags |= MB_TOPMOST;

  MainForm->Tag = 1;
  int nResult = MessageBoxW(Application->Handle, sText.c_bstr(),
    g_msgBoxCaptionList[nListIndex].c_bstr(), nFlags);
  MainForm->Tag = 0;

  // the handle of the message box doesn't belong to our application,
  // so TApplication::OnMessage is not invoked => we have to incorporate
  // the entropy manually here
  // we simply assume a mouse event and assign 1 bit of entropy to it
  TMessage msg;
  msg.Msg = 0;
  msg.WParam = 0;
  msg.LParam = 0;
  msg.Result = nResult;
  g_pEntropyMng->AddEvent(msg, entOther, 1);

  return nResult;
}
//---------------------------------------------------------------------------
void OutOfDiskSpaceError(void)
{
  throw EStreamError(ETRL("Out of disk space"));
}
//---------------------------------------------------------------------------
int GetEditBoxTextLen(TCustomEdit* pEdit)
{
  if (Win32PlatformIsUnicode)
    return GetWindowTextLengthW(pEdit->Handle);
  return pEdit->GetTextLen();
}
//---------------------------------------------------------------------------
void GetEditBoxTextBuf(TCustomEdit* pEdit,
                       SecureWString& sDest)
{
  if (Win32PlatformIsUnicode) {
    int nLen = GetWindowTextLengthW(pEdit->Handle) + 1;
    sDest.New(nLen);
    GetWindowTextW(pEdit->Handle, sDest, nLen);
  }
  else {
    int nLen = pEdit->GetTextLen() + 1;
    SecureAnsiString sTemp(nLen);
    pEdit->GetTextBuf(sTemp, nLen);

    int nLenW = MultiByteToWideChar(CP_ACP, 0, sTemp, -1, NULL, 0);
    sDest.New(nLenW);
    MultiByteToWideChar(CP_ACP, 0, sTemp, -1, sDest, nLenW);
  }
}
//---------------------------------------------------------------------------
void GetEditBoxSelTextBuf(TCustomEdit* pEdit,
                          SecureWString& sDest)
{
  if (Win32PlatformIsUnicode) {
    SecureWString sTemp;
    GetEditBoxTextBuf(pEdit, sTemp);

    int nLen = pEdit->SelLength;
    sDest.New(nLen + 1);
    wcsncpy(sDest, sTemp + pEdit->SelStart, nLen);
    sDest[nLen] = '\0';
  }
  else {
    int nLen = pEdit->SelLength + 1;
    SecureAnsiString sTemp(nLen);
    pEdit->GetSelTextBuf(sTemp, nLen);

    int nLenW = MultiByteToWideChar(CP_ACP, 0, sTemp, -1, NULL, 0);
    sDest.New(nLenW);
    MultiByteToWideChar(CP_ACP, 0, sTemp, -1, sDest, nLenW);
  }
}
//---------------------------------------------------------------------------
void GetRichEditSelTextBuf(TCustomRichEdit* pEdit,
                           SecureWString& sDest)
{
  if (Win32PlatformIsUnicode) {
    CHARRANGE range;
    SendMessageW(pEdit->Handle, EM_EXGETSEL, 0, word32(&range));
    sDest.New(range.cpMax - range.cpMin + 1);
    SendMessageW(pEdit->Handle, EM_GETSELTEXT, 0, word32(sDest.Data()));

    strCr2Crlf(sDest);
  }
  else
    GetEditBoxSelTextBuf(pEdit, sDest);
}
//---------------------------------------------------------------------------
void SetEditBoxTextBuf(TCustomEdit* pEdit,
                       const wchar_t* pwszSrc)
{
  if (Win32PlatformIsUnicode) {
    SetWindowTextW(pEdit->Handle, pwszSrc);
    pEdit->Perform(CM_TEXTCHANGED, 0, 0);
  }
  else {
    int nLenA = WideCharToMultiByte(CP_ACP, 0, pwszSrc, -1, NULL, 0, NULL, NULL);
    SecureAnsiString sTemp(nLenA);
    WideCharToMultiByte(CP_ACP, 0, pwszSrc, -1, sTemp, nLenA, NULL, NULL);
    pEdit->SetTextBuf(sTemp);
  }
}
//---------------------------------------------------------------------------
void ClearEditBoxTextBuf(TCustomEdit* pEdit,
                         int nTextLen)
{
  // OK, this is an important function: it overwrites and eventually 'clears'
  // the text buffer of the Windows control. Yes, this solution is
  // somewhat lousy, but unfortunately we cannot access the buffer directly
  // -- no way via VCL.

  // this character table contains 34 space characters to accelerate the
  // formatting done by Windows; if the text doesn't contain any spaces,
  // the formatting becomes quite slow...
  // the probability of a space to occur is ~27%.
  static const char CHARTABLE128[129] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~                                  ";

  nTextLen = std::max(pEdit->GetTextLen(), nTextLen);
  if (nTextLen == 0)
    return;

  try {
    std::vector<wchar_t> randStr(nTextLen + 1);
    randStr[nTextLen] = '\0';

    word8 rand[64];
    int nRandPos = sizeof(rand);
    for (std::vector<wchar_t>::iterator it = randStr.begin();
         it != randStr.end(); it++) {
      if (nRandPos == sizeof(rand)) {
        fprng_fillbuf(rand, sizeof(rand));
        nRandPos = 0;
      }
      *it = CHARTABLE128[rand[nRandPos++] & 127];
    }

    SetEditBoxTextBuf(pEdit, randStr.begin());
  }
  catch (...)
  {
  }

  pEdit->Clear();
}
//---------------------------------------------------------------------------
bool GetClipboardTextBuf(SecureWString* psDestW,
                         SecureAnsiString* psDestA,
                         word32& lTextLen) // length in chars!
{
  TClipboard* pClipboard = Clipboard();
  bool blResult = false;

  try {
    pClipboard->Open();
    if (psDestW != NULL && pClipboard->HasFormat(CF_UNICODETEXT))
    {
      HGLOBAL hText = (HGLOBAL) pClipboard->GetAsHandle(CF_UNICODETEXT);
      if (hText != NULL)
      {
        wchar_t* pwszText = (wchar_t*) GlobalLock(hText);
        if (pwszText != NULL)
        {
          lTextLen = wcslen(pwszText);
          psDestW->New(pwszText, lTextLen + 1);

          GlobalUnlock(hText);

          blResult = true;
        }
      }
    }
    else if (pClipboard->HasFormat(CF_TEXT))
    {
      HGLOBAL hText = (HGLOBAL) pClipboard->GetAsHandle(CF_TEXT);
      if (hText != NULL)
      {
        char* pszText = (char*) GlobalLock(hText);
        if (pszText != NULL)
        {
          if (psDestW != NULL) {
            word32 lBufLen = MultiByteToWideChar(CP_ACP, 0, pszText, -1, NULL, 0);
            psDestW->New(lBufLen);
            MultiByteToWideChar(CP_ACP, 0, pszText, -1, *psDestW, lBufLen);
            lTextLen = lBufLen - 1; // excluding '\0'
          }
          else {
            lTextLen = strlen(pszText);
            psDestA->New(pszText, lTextLen + 1);
          }

          GlobalUnlock(hText);

          blResult = true;
        }
      }
    }
  }
  __finally {
    pClipboard->Close();
  }

  return blResult;
}
//---------------------------------------------------------------------------
void SetClipboardTextBuf(const wchar_t* pwszSrcW,
                         const char* pszSrcA)
{
  TClipboard* pClipboard = Clipboard();

  try {
    pClipboard->Open();

    if (pwszSrcW != NULL) {
      if (Win32PlatformIsUnicode) {
        HGLOBAL hText = GlobalAlloc(GMEM_MOVEABLE,
          (wcslen(pwszSrcW) + 1) * sizeof(wchar_t));
        if (hText == NULL)
          OutOfMemoryError();

        wchar_t* pwszText = (wchar_t*) GlobalLock(hText);
        if (pwszText == NULL) {
          GlobalFree(hText);
          OutOfMemoryError(); // should never happen, hText should have been NULL before
        }

        wcscpy(pwszText, pwszSrcW);

        GlobalUnlock(hText);

        pClipboard->SetAsHandle(CF_UNICODETEXT, unsigned(hText));
      }
      else {
        word32 lAnsiLen = WideCharToMultiByte(CP_ACP, 0, pwszSrcW, -1, NULL, 0,
          NULL, NULL);

        SecureAnsiString sAnsiStr(lAnsiLen);
        WideCharToMultiByte(CP_ACP, 0, pwszSrcW, -1, sAnsiStr, lAnsiLen, NULL, NULL);

        pClipboard->SetTextBuf(sAnsiStr);
      }
    }
    else {
      pClipboard->SetTextBuf((char*) pszSrcA);
    }
  }
  __finally {
    pClipboard->Close();
  }
}
//---------------------------------------------------------------------------
bool StartEditBoxDragDrop(TCustomEdit* pEdit)
{
  CLIPFORMAT cf;
  HGLOBAL hMem;

  // get the selected text from the edit box
  if (Win32PlatformIsUnicode) {
    cf = CF_UNICODETEXT;

    SecureWString sText;

    if (pEdit->SelLength == 0)
      GetEditBoxTextBuf(pEdit, sText);
    else
      GetEditBoxSelTextBuf(pEdit, sText);

    // allocate system memory for storing the text
    hMem = GlobalAlloc(GHND, sText.Size() * sizeof(wchar_t));
    wchar_t* pwszMem = (wchar_t*) GlobalLock(hMem);

    wcscpy(pwszMem, sText.Data());
  }
  else {
    cf = CF_TEXT;

    SecureAnsiString asText;

    if (pEdit->SelLength == 0) {
      asText.New(pEdit->GetTextLen() + 1);
      pEdit->GetTextBuf(asText.Data(), asText.Size());
    }
    else {
      asText.New(pEdit->SelLength + 1);
      pEdit->GetSelTextBuf(asText.Data(), asText.Size());
    }

    hMem = GlobalAlloc(GHND, asText.Size());
    char* pszMem = (char*) GlobalLock(hMem);

    strcpy(pszMem, asText.Data());
  }

  GlobalUnlock(hMem);

  FORMATETC fmtetc = { cf, 0, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
  STGMEDIUM stgmed = { TYMED_HGLOBAL, { 0 }, 0 };

  // transfer the current selection into the IDataObject
  stgmed.hGlobal = hMem;

  IDataObject *pDataObject;
  IDropSource *pDropSource;

  // Create IDataObject and IDropSource COM objects
  CreateDropSource(&pDropSource);
  CreateDataObject(&fmtetc, &stgmed, 1, &pDataObject);

  //
  //	** ** ** The drag-drop operation starts here! ** ** **
  //
  DWORD dwEffect;
  DWORD dwResult;
  dwResult = DoDragDrop(pDataObject, pDropSource, DROPEFFECT_COPY, &dwEffect);

  pDataObject->Release();
  pDropSource->Release();

  return dwResult == DRAGDROP_S_DROP;
}
//---------------------------------------------------------------------------
bool ExecuteShellOp(const WString& sOperation, bool blShowErrorMsg)
{
  if (sOperation.IsEmpty())
    return false;

  bool blSuccess = false;

  try {
    if (Win32PlatformIsUnicode) {
      //std::wstring sOperation = sInput.c_bstr();
      blSuccess = int(ShellExecuteW(NULL, L"open",
        sOperation.c_bstr(), NULL, NULL, SW_SHOWNORMAL)) > 32;
    }
    else {
      AnsiString asOperation = sOperation;
      blSuccess = int(ShellExecuteA(NULL, "open",
        asOperation.c_str(), NULL, NULL, SW_SHOWNORMAL)) > 32;
    }
  }
  catch (std::exception& e) {
    throw Exception(CppStdExceptionToString(&e));
  }
  catch (...) {
  }

  if (!blSuccess && blShowErrorMsg)
    MsgBox(TRLFormat("Could not open file/execute operation\n\"%s\".", sOperation),
      MB_ICONERROR);

  return blSuccess;
}
//---------------------------------------------------------------------------
int CompareVersions(const AnsiString& asVer1,
                    const AnsiString& asVer2)
{
  static const char VERSION_FORMAT[] = "%d.%d.%d";
  int ver1[3] = {-1,-1,-1}, ver2[3] = {-1,-1,-1};

  sscanf(asVer1.c_str(), VERSION_FORMAT, &ver1[0], &ver1[1], &ver1[2]);
  sscanf(asVer2.c_str(), VERSION_FORMAT, &ver2[0], &ver2[1], &ver2[2]);

  // handle obsolete version numbering "x.yy":
  // convert it to "x.0.yy"
  if (ver1[2] < 0 && ver1[1] >= 0) {
    ver1[2] = ver1[1];
    ver1[1] = 0;
  }
  if (ver2[2] < 0 && ver2[1] >= 0) {
    ver2[2] = ver2[1];
    ver2[1] = 0;
  }

  if (ver1[0] != ver2[0])
    return (ver1[0] > ver2[0]) ? 1 : -1;
  if (ver1[1] != ver2[1])
    return (ver1[1] > ver2[1]) ? 1 : -1;
  if (ver1[2] != ver2[2])
    return (ver1[2] > ver2[2]) ? 1 : -1;

  return 0;
}
//---------------------------------------------------------------------------
WString GetAppDataPath(void)
{
  WString sPath;

  if (Win32PlatformIsUnicode) {
    wchar_t wszPath[MAX_PATH];

    if (SHGetFolderPathW(NULL, CSIDL_APPDATA, NULL, 0, wszPath) == S_OK)
      sPath = WString(wszPath) + WString("\\");
  }
  else {
    char szPath[MAX_PATH];

    if (SHGetFolderPathA(NULL, CSIDL_APPDATA, NULL, 0, szPath) == S_OK)
      sPath = WString(szPath) + WString("\\");
  }

  return sPath;
  /*typedef HRESULT (WINAPI* PGFPW)(HWND, int, HANDLE, DWORD, wchar_t*);

  HINSTANCE hShellDLL = LoadLibrary("shell32.dll");

  if (hShellDLL == NULL)
    return "";

  PGFPW pGFPW = (PGFPW) GetProcAddress(hShellDLL, "SHGetFolderPathW");

  wchar_t wszPath[MAX_PATH];
  WString sPath;

  if (pGFPW != NULL && pGFPW(NULL, 26, NULL, 0, wszPath) == S_OK)
    sPath = WString(wszPath) + WString(L"\\");

  FreeLibrary(hShellDLL);

  return sPath;*/
}
//---------------------------------------------------------------------------
AnsiString FontToString(TFont* pFont)
{
  return Format("%s;%d,%d,%s", ARRAYOFCONST((pFont->Name, pFont->Size,
    int(pFont->Style.Contains(fsBold) | (pFont->Style.Contains(fsItalic) << 1) |
    (pFont->Style.Contains(fsUnderline) << 2) | (pFont->Style.Contains(fsStrikeOut) << 3)),
    ColorToString(pFont->Color))));
}
//---------------------------------------------------------------------------
int StringToFont(AnsiString asFont,
                 TFont* pFont)
{
  if (asFont.IsEmpty())
    return 0;

  int nPos = asFont.Pos(";");
  if (nPos < 2)
    return 0;

  pFont->Name = asFont.SubString(1, nPos - 1);
  int nNumParsed = 1;

  asFont.Delete(1, nPos);

  nPos = asFont.Pos(",");
  if (nPos < 2)
    return nNumParsed;

  int nSize = StrToIntDef(asFont.SubString(1, nPos - 1), 0);
  if (nSize == 0)
    return nNumParsed;

  pFont->Size = nSize;
  nNumParsed++;

  asFont.Delete(1, nPos);

  nPos = asFont.Pos(",");
  if (nPos == 1 || nPos > 3)
    return nNumParsed;

  int nFlags = StrToIntDef(asFont.SubString(1, nPos - 1), 0);
  TFontStyles style;
  if (nFlags & 1)
    style << fsBold;
  if (nFlags & 2)
    style << fsItalic;
  if (nFlags & 4)
    style << fsUnderline;
  if (nFlags & 8)
    style << fsStrikeOut;

  pFont->Style = style;
  nNumParsed++;

  asFont.Delete(1, nPos);
  if (asFont.Length() == 0)
    return nNumParsed;

  pFont->Color = StringToColor(asFont);
  nNumParsed++;

  return nNumParsed;
}
//---------------------------------------------------------------------------
AnsiString CppStdExceptionToString(std::exception* e)
{
  AnsiString asMsg;

  if (dynamic_cast<std::bad_alloc*>(e) != NULL)
    asMsg = "std::bad_alloc: Could not allocate memory (out of memory?)";
  else if (dynamic_cast<std::bad_exception*>(e) != NULL)
    asMsg = "std::bad_exception: Exception thrown by unexpected handler";
  else if (dynamic_cast<std::logic_error*>(e) != NULL)
    asMsg = "std::logic_error";
  else if (dynamic_cast<std::runtime_error*>(e) != NULL)
    asMsg = "std::runtime_error";
  else
    asMsg = "std::exception: Unrecognized type";

  return asMsg;
}
//---------------------------------------------------------------------------
WString ConvertCr2Crlf(const WString& sSrc)
{
  if (sSrc.IsEmpty())
    return WString();

  const wchar_t* pwszStr = sSrc.c_bstr();
  int nLen = sSrc.Length();
  std::wstring sDest;
  sDest.reserve(nLen);
  while (nLen--) {
    if (*pwszStr == '\n')
      sDest.push_back('\r');
    sDest.push_back(*pwszStr++);
  }
  return WString(sDest.c_str());
}
//---------------------------------------------------------------------------
