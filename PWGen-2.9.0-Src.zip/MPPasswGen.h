// MPPasswGen.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#ifndef MPPasswGenH
#define MPPasswGenH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
#include "TntForms.hpp"
#include "TntComCtrls.hpp"
#include "TntStdCtrls.hpp"
#include "AESCtrPRNG.h"
#include "SecureMem.h"
#include "TntButtons.hpp"
#include "TntExtCtrls.hpp"
#include <Buttons.hpp>
#include <jpeg.hpp>
#include "TntMenus.hpp"
#include <Menus.hpp>

class TMPPasswGenDlg : public TTntForm
{
__published:	// IDE-managed Components
        TTntGroupBox *MasterPasswGroup;
        TTntButton *EnterPasswBtn;
        TTntCheckBox *ConfirmPasswCheck;
        TTntCheckBox *ShowPasswHashCheck;
        TTntCheckBox *KeyExpiryCheck;
        TTntEdit *KeyExpiryTimeBox;
        TTntUpDown *KeyExpiryTimeSpinBtn;
        TTntLabel *PasswStatusLbl;
        TTntEdit *PasswStatusBox;
        TTntLabel *PasswExpiryCountdownLbl;
        TTntButton *ClearKeyBtn;
        TTntGroupBox *PasswGeneratorGroup;
        TTntLabel *ParameterLbl;
        TTntEdit *ParameterBox;
        TTntLabel *CharSetLbl;
        TTntComboBox *CharSetList;
        TTntLabel *LengthLbl;
        TTntEdit *PasswLengthBox;
        TTntUpDown *PasswLengthSpinBtn;
        TTntButton *ClearParameterBtn;
        TTntLabel *ResultingPasswLbl;
        TTntEdit *PasswBox;
        TTntButton *GenerateBtn;
        TTntLabel *KeyExpiryInfoLbl;
        TTntButton *UseAsDefaultRNGBtn;
        TTntButton *CloseBtn;
        TTimer *KeyExpiryTimer;
        TTntLabel *KeyExpiryCountdownLbl;
        TTntSpeedButton *TogglePasswBtn;
        TTntLabel *PasswInfoLbl;
        TTntPanel *PasswSecurityBarPanel;
        TTntImage *PasswSecurityBar;
        TTntCheckBox *HashapassCompatCheck;
        TTntLabel *CharSetInfoLbl;
        TTntPopupMenu *PasswBoxMenu;
        TTntMenuItem *PasswBoxMenu_Undo;
        TTntMenuItem *PasswBoxMenu_N1;
        TTntMenuItem *PasswBoxMenu_Cut;
        TTntMenuItem *PasswBoxMenu_Copy;
        TTntMenuItem *PasswBoxMenu_EncryptCopy;
        TTntMenuItem *PasswBoxMenu_Paste;
        TTntMenuItem *PasswBoxMenu_Delete;
        TTntMenuItem *PasswBoxMenu_N2;
        TTntMenuItem *PasswBoxMenu_SelectAll;
        void __fastcall EnterPasswBtnClick(TObject *Sender);
        void __fastcall KeyExpiryTimerTimer(TObject *Sender);
        void __fastcall ClearKeyBtnClick(TObject *Sender);
        void __fastcall GenerateBtnClick(TObject *Sender);
        void __fastcall KeyExpiryCheckClick(TObject *Sender);
        void __fastcall ClearParameterBtnClick(TObject *Sender);
        void __fastcall TogglePasswBtnClick(TObject *Sender);
        void __fastcall TntFormClose(TObject *Sender,
          TCloseAction &Action);
        void __fastcall CloseBtnClick(TObject *Sender);
        void __fastcall UseAsDefaultRNGBtnClick(TObject *Sender);
        void __fastcall HashapassCompatCheckClick(TObject *Sender);
        void __fastcall ParameterBoxKeyPress(TObject *Sender, char &Key);
        void __fastcall TntFormActivate(TObject *Sender);
        void __fastcall CharSetListChange(TObject *Sender);
        void __fastcall PasswBoxMenuPopup(TObject *Sender);
        void __fastcall PasswBoxMenu_UndoClick(TObject *Sender);
        void __fastcall PasswBoxMenu_CutClick(TObject *Sender);
        void __fastcall PasswBoxMenu_CopyClick(TObject *Sender);
        void __fastcall PasswBoxMenu_EncryptCopyClick(TObject *Sender);
        void __fastcall PasswBoxMenu_PasteClick(TObject *Sender);
        void __fastcall PasswBoxMenu_DeleteClick(TObject *Sender);
        void __fastcall PasswBoxMenu_SelectAllClick(TObject *Sender);
        void __fastcall TntFormShow(TObject *Sender);
        void __fastcall PasswSecurityBarMouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall ParameterLblMouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
private:	// User declarations
        AESCtrPRNG* m_pRandGen;
        SecureMem<word8> m_key;
        int m_nExpiryCountdown;
        IDropTarget* m_pPasswBoxDropTarget;
        IDropTarget* m_pParamBoxDropTarget;

        void __fastcall LoadConfig(void);
        void __fastcall ClearKey(bool blExpired = false,
                                 bool blClearKeyOnly = false);
        void __fastcall SetKeyExpiry(bool blSetup = false);
public:		// User declarations
        __fastcall TMPPasswGenDlg(TComponent* Owner);
        __fastcall ~TMPPasswGenDlg();
        void __fastcall SaveConfig(void);
};
//---------------------------------------------------------------------------
extern PACKAGE TMPPasswGenDlg *MPPasswGenDlg;
//---------------------------------------------------------------------------
#endif
