// UpdateCheck.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <stdio.h>
#include <urlmon.h>
#include <wininet.h>
#pragma hdrstop

#include "UpdateCheck.h"
#include "Main.h"
#include "ProgramDef.h"
#include "StringFileStreamW.h"
#include "Language.h"
#include "Util.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "urlmon.lib"
#pragma link "wininet.lib"

//---------------------------------------------------------------------------
int __fastcall TUpdateCheckThread::CheckForUpdates(bool blShowError)
{
  try {
    HRESULT hResult;
    WString sFileName;

    const WString sAltUrl = WString(PROGRAM_URL_VERSION) +
      WString("?fakeParam=") + WString(IntToHex(int(time(NULL)), 8));

    if (Win32PlatformIsUnicode) {
      wchar_t wszFileName[MAX_PATH];
      wszFileName[0] = '\0';

      //const wchar_t* pwszUrl = L"http://pwgen-win.sourceforge.net/manual.pdf";
      const wchar_t* pwszUrl = PROGRAM_URL_VERSION;

      // first try to delete a cache entry of the file before downloading it
      // to ensure that we get the latest version from the server
      if (!DeleteUrlCacheEntryW(pwszUrl) && GetLastError() == ERROR_ACCESS_DENIED)
        pwszUrl = sAltUrl.c_bstr();

      hResult = URLDownloadToCacheFileW(NULL, pwszUrl, wszFileName,
        MAX_PATH, 0, NULL);

      sFileName = WString(wszFileName);
    }
    else {
      char szFileName[MAX_PATH];
      szFileName[0] = '\0';

      AnsiString asUrl = PROGRAM_URL_VERSION;

      if (!DeleteUrlCacheEntryA(asUrl.c_str()) && GetLastError() == ERROR_ACCESS_DENIED)
        asUrl = sAltUrl;

      hResult = URLDownloadToCacheFileA(NULL, asUrl.c_str(), szFileName,
        MAX_PATH, 0, NULL);

      sFileName = WString(szFileName);
    }

    if (hResult != S_OK || sFileName.IsEmpty())
      throw Exception(ETRL("Could not download version file"));

    std::auto_ptr<TStringFileStreamW> pFile(
      new TStringFileStreamW(sFileName, fmOpenRead, ceAnsi, true, 1024));

    const int BUFSIZE = 256;
    wchar_t wszBuf[BUFSIZE];

    pFile->ReadString(wszBuf, BUFSIZE);
    WString sVersion = Trim(WString(wszBuf));
    WString sUrl, sNote;

    int nVer1 = -1, nVer2 = -1, nVer3 = -1;
    int nNumScanned = sscanf(AnsiString(sVersion).c_str(),
      "%d.%d.%d", &nVer1, &nVer2, &nVer3);
    if (nNumScanned == 3 && nVer1 >= 0 && nVer2 >= 0 && nVer3 >= 0) {
      pFile->ReadString(wszBuf, BUFSIZE);
      sUrl = Trim(WString(wszBuf));
      pFile->ReadString(wszBuf, BUFSIZE);
      sNote = Trim(WString(wszBuf));
    }
    else
      sVersion = "";

    if (sVersion.IsEmpty() || sUrl.IsEmpty())
      throw Exception(ETRL("URL not found, or unknown format of version file"));

    if (CompareVersions(sVersion, PROGRAM_VERSION) > 0) {
      WString sMsg = TRLFormat("A new version (%s) of PWGen is available!\nDo you want "
          "to visit the download page now?", sVersion);
      if (!sNote.IsEmpty())
        sMsg += WString("\n\n") + TRLFormat("(NOTE: %s)", sNote);
      if (MsgBox(sMsg, MB_ICONINFORMATION + MB_YESNO) == IDYES)
        ExecuteShellOp(sUrl, true);
      return 1;
    }
  }
  catch (Exception& e) {
    if (blShowError)
      MsgBox(TRLFormat("Error while checking for updates:\n%s.",
        UTF8Decode(e.Message)), MB_ICONERROR);
    return -1;
  }

  return 0;
}
