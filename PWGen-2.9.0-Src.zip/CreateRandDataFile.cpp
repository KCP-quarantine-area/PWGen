// CreateRandDataFile.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "CreateRandDataFile.h"
#include "EntropyManager.h"
#include "Main.h"
#include "CallBack.h"
#include "Util.h"
#include "Language.h"
#include "TopMostManager.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "TntStdCtrls"
#pragma link "TntDialogs"
#pragma resource "*.dfm"
TCreateRandDataFileDlg *CreateRandDataFileDlg;

static const AnsiString
  CONFIG_ID = "CreateRandDataFile";

//---------------------------------------------------------------------------
__fastcall TCreateRandDataFileDlg::TCreateRandDataFileDlg(TComponent* Owner)
        : TTntForm(Owner)
{
  Constraints->MaxHeight = Height;
  Constraints->MinHeight = Height;
  Constraints->MinWidth = Width;

  if (g_pLangSupp != NULL) {
    TRLCaption(this);
    TRLCaption(FileNameLbl);
    TRLCaption(FileSizeLbl);
    TRLCaption(CloseBtn);
    TRLCaption(CreateFileBtn);
    TRLHint(BrowseBtn);

    for (int nI = 0; nI < SizeUnitList->Items->Count; nI++)
      SizeUnitList->Items->Strings[nI] = TRL(SizeUnitList->Items->Strings[nI]);
  }
  LoadConfig();
}
//---------------------------------------------------------------------------
void __fastcall TCreateRandDataFileDlg::LoadConfig(void)
{
  Width = g_pIni->ReadInteger(CONFIG_ID, "WindowWidth", Width);
  FileSizeBox->Text = g_pIni->ReadString(CONFIG_ID, "FileSize", "");

  int nSizeUnitIdx = g_pIni->ReadInteger(CONFIG_ID, "FileSizeUnitIdx", 0);
  SizeUnitList->ItemIndex = (nSizeUnitIdx >= 0 && nSizeUnitIdx <= 2) ?
    nSizeUnitIdx : 0;
}
//---------------------------------------------------------------------------
void __fastcall TCreateRandDataFileDlg::SaveConfig(void)
{
  g_pIni->WriteString(CONFIG_ID, "WindowWidth", Width);
  g_pIni->WriteString(CONFIG_ID, "FileSize", FileSizeBox->Text);
  g_pIni->WriteInteger(CONFIG_ID, "FileSizeUnitIdx", SizeUnitList->ItemIndex);
}
//---------------------------------------------------------------------------
void __fastcall TCreateRandDataFileDlg::CreateFileBtnClick(TObject *Sender)
{
  const IO_BUFSIZE = 65536;

  WString sFileName = FileNameBox->Text;
  if (WideExtractFilePath(sFileName).IsEmpty())
    sFileName = g_sExePath + sFileName;

  double dFileSize = StrToFloatDef(FileSizeBox->Text, 0);
  if (SizeUnitList->ItemIndex == 1)
    dFileSize *= 1024;
  else if (SizeUnitList->ItemIndex == 2)
    dFileSize *= 1048576;

  if (dFileSize <= 0 || dFileSize > INT_MAX) {
    MsgBox(TRL("Invalid file size."), MB_ICONERROR);
    FileSizeBox->SetFocus();
    return;
  }

  int nFileSize = int(dFileSize);

  if (DiskFree(word8(UpCase(sFileName[1]) - 'A' + 1)) < nFileSize) {
    MsgBox(TRL("Not enough free disk space available\nto create the file."),
      MB_ICONERROR);
    return;
  }

  bool blCallback;
  if (nFileSize > 1048576) {
    blCallback = true;
    CallbackForm->Init(this, TRL("Creating random data file ..."), TRL("%d of "
      "%d KB written."), nFileSize / 1024);
    Screen->Cursor = crAppStart;
  }
  else {
    blCallback = false;
    Screen->Cursor = crHourGlass;
  }

  //TTntFileStream* pFile = NULL;

  bool blSuccess = false;
  String sMsg;
  int nTotalWritten = 0;

  Refresh();

  RandomPool* pRandPool = RandomPool::GetInstance();
  if (g_pRandSrc == pRandPool) {
    // add system entropy & initialize the PRNG
    g_pEntropyMng->AddSystemEntropy();
    pRandPool->RandReady();
  }

  try {
    std::auto_ptr<TTntFileStream> pFile(new TTntFileStream(sFileName, fmCreate));

    SecureMem<word8> randBuf(IO_BUFSIZE);

    int nRestToWrite = nFileSize;

    while (nRestToWrite > 0) {
      int nBytesToWrite = std::min(nRestToWrite, IO_BUFSIZE);

      g_pRandSrc->GetData(randBuf, nBytesToWrite);

      int nBytesWritten = pFile->Write(randBuf, nBytesToWrite);
      nTotalWritten += nBytesWritten;

      if (blCallback)
        CallbackForm->Callback(nTotalWritten / 1024);

      if (nBytesWritten < nBytesToWrite)
        OutOfDiskSpaceError();

      nRestToWrite -= nBytesWritten;
    }

    sMsg = TRLFormat("File \"%s\" successfully created.\n\n%d bytes written.",
      WideExtractFileName(sFileName), nTotalWritten);
    blSuccess = true;
  }
  catch (Exception& e) {
    sMsg = TRLFormat("Error while creating file\n\"%s\":\n%s.\n\n%d bytes written.",
      sFileName, UTF8Decode(e.Message), nTotalWritten);
  }

  //if (pFile != NULL) {
//    FlushFileBuffers((HANDLE) pFile->Handle);
    //delete pFile;
  pRandPool->Flush();
  if (g_pRandSrc == pRandPool) {
    g_pEntropyMng->ConsumeEntropyBits(
      std::min<double>(nTotalWritten * 8.0, RandomPool::MAX_ENTROPY));
    MainForm->UpdateEntropyProgress();
  }

  Screen->Cursor = crDefault;

  MsgBox(sMsg, (blSuccess) ? MB_ICONINFORMATION : MB_ICONERROR);

  if (blCallback)
    CallbackForm->Terminate();
}
//---------------------------------------------------------------------------
void __fastcall TCreateRandDataFileDlg::BrowseBtnClick(TObject *Sender)
{
  MainForm->SaveDlg->FilterIndex = 1;

  TopMostManager::GetInstance()->NormalizeTopMosts(this);
  bool blSuccess = MainForm->SaveDlg->Execute();
  TopMostManager::GetInstance()->RestoreTopMosts(this);

  if (!blSuccess)
    return;

  FileNameBox->Text = MainForm->SaveDlg->FileName;
  FileNameBox->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TCreateRandDataFileDlg::FileNameBoxChange(TObject *Sender)
{
  CreateFileBtn->Enabled = (GetEditBoxTextLen(FileNameBox) != 0) &&
    (GetEditBoxTextLen(FileSizeBox) != 0);
}
//---------------------------------------------------------------------------
void __fastcall TCreateRandDataFileDlg::FormShow(TObject *Sender)
{
  Top = MainForm->Top + (MainForm->Height - Height) / 2;
  Left = MainForm->Left + (MainForm->Width - Width) / 2;
  TopMostManager::GetInstance()->SetForm(this);
}
//---------------------------------------------------------------------------
void __fastcall TCreateRandDataFileDlg::FormActivate(TObject *Sender)
{
  FileNameBox->SetFocus();
}
//---------------------------------------------------------------------------

