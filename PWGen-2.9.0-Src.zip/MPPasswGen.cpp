// MPPasswGen.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#include <Math.hpp>
#include <Clipbrd.hpp>
#pragma hdrstop

#include "MPPasswGen.h"
#include "Main.h"
#include "RandomPool.h"
#include "PasswEnter.h"
#include "Language.h"
#include "Util.h"
#include "CryptUtil.h"
#include "sha1.h"
#include "base64.h"
#include "FastPRNG.h"
#include "dragdrop.h"
#include "TopMostManager.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "TntComCtrls"
#pragma link "TntStdCtrls"
#pragma link "TntButtons"
#pragma link "TntExtCtrls"
#pragma link "TntMenus"
#pragma resource "*.dfm"
TMPPasswGenDlg *MPPasswGenDlg;

static const char PASSWORD_CHAR = '*';

static const int
          MPPG_CHARSETS_NUM = 6,
          PASSW_MAX_CHARS   = 10000,
          PASSW_DEFAULT_LEN = 16;

static const char* MPPG_CHARSETS[MPPG_CHARSETS_NUM] =
      { "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
        "ACEFHJKLMNPRTUVWXYabcdefghijkmnopqrstuvwxyz3479",
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~",
        "ACEFHJKLMNPRTUVWXYabcdefghijkmnopqrstuvwxyz3479!\"#$%&'()*+,-./:;<=>?@[\\]^_`{}~",
        "0123456789abcdef",
        "0123456789ABCDEF"
      };

static const char MPPG_KEYGEN_SALTSTR[] = "PWGen MP Password Generator";

// functions that provide compatibility with "Hashapass"
static void unicodeToLSByte(const wchar_t* pwszSrc,
                            char* pszDest,
                            int nLen)
{
  while (nLen--)
    *pszDest++ = char(*pwszSrc++);
}

static void asciiToUnicode(const char* pszSrc,
                           wchar_t* pwszDest,
                           int nLen)
{
  while (nLen--)
    *pwszDest++ = *pszSrc++;
}


static const AnsiString
  CONFIG_ID = "MPPasswGen";

static word8 memcryptKey[16];

//---------------------------------------------------------------------------
__fastcall TMPPasswGenDlg::TMPPasswGenDlg(TComponent* Owner)
        : TTntForm(Owner), m_pRandGen(NULL)
{
  Constraints->MinHeight = Height;
  Constraints->MinWidth = Width;

  PasswLengthSpinBtn->Max = PASSW_MAX_CHARS;
  TTntStrings* pStrList = CharSetList->Items;

  pStrList->Add(FormatW("1: %s (A-Z, a-z, 0-9)", TRL("Alphanumeric")));
  pStrList->Add(FormatW("2: (1) %s", TRL("without ambiguous characters")));
  pStrList->Add(FormatW("3: (1) + %s (!\"#$%...)", TRL("special symbols")));
  pStrList->Add(FormatW("4: (3) %s", TRL("without ambiguous characters")));
  pStrList->Add(FormatW("5: %s (0-9, a-f)", TRL("Hexadecimal")));
  pStrList->Add(FormatW("6: %s (0-9, A-F)", TRL("Hexadecimal")));

  MPPasswGenDlg->PasswBox->Font = MainForm->PasswBox->Font;

  if (g_pLangSupp != NULL) {
    TRLCaption(this);
    TRLCaption(MasterPasswGroup);
    TRLCaption(EnterPasswBtn);
    TRLCaption(ClearKeyBtn);
    TRLCaption(PasswStatusLbl);
    TRLCaption(KeyExpiryInfoLbl);
    TRLCaption(ConfirmPasswCheck);
    TRLCaption(ShowPasswHashCheck);
    TRLCaption(KeyExpiryCheck);
    TRLCaption(HashapassCompatCheck);
    TRLCaption(PasswGeneratorGroup);
    TRLCaption(ParameterLbl);
    TRLCaption(ClearParameterBtn);
    TRLCaption(CharSetLbl);
    TRLCaption(LengthLbl);
    TRLCaption(ResultingPasswLbl);
    TRLCaption(GenerateBtn);
    TRLCaption(UseAsDefaultRNGBtn);
    TRLCaption(CloseBtn);
    TRLHint(TogglePasswBtn);

    for (int nI = 0; nI < PasswBoxMenu->Items->Count; nI++)
      TRLCaption((TTntMenuItem*) PasswBoxMenu->Items->Items[nI]);
  }

  PasswSecurityBar->Hint = MainForm->PasswSecurityBar->Hint;

  RegisterDropWindow(PasswBox->Handle, Win32PlatformIsUnicode, &m_pPasswBoxDropTarget);
  RegisterDropWindow(ParameterBox->Handle, Win32PlatformIsUnicode, &m_pParamBoxDropTarget);

  LoadConfig();
}
//---------------------------------------------------------------------------
__fastcall TMPPasswGenDlg::~TMPPasswGenDlg()
{
  UnregisterDropWindow(ParameterBox->Handle, m_pParamBoxDropTarget);
  UnregisterDropWindow(PasswBox->Handle, m_pPasswBoxDropTarget);
  memzero(memcryptKey, sizeof(memcryptKey));
  ClearEditBoxTextBuf(PasswBox, 256);
  ClearEditBoxTextBuf(ParameterBox, 256);
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::LoadConfig(void)
{
  int nTop = g_pIni->ReadInteger(CONFIG_ID, "WindowTop", -1);
  int nLeft = g_pIni->ReadInteger(CONFIG_ID, "WindowLeft", -1);

  if (nTop >= 0 && nLeft >= 0) {
    Top = nTop;
    Left = nLeft;
  }
  else
    Position = poScreenCenter;

  Height = g_pIni->ReadInteger(CONFIG_ID, "WindowHeight", Height);
  Width = g_pIni->ReadInteger(CONFIG_ID, "WindowWidth", Width);

  ConfirmPasswCheck->Checked = g_pIni->ReadBool(CONFIG_ID, "ConfirmPassw", false);
  ShowPasswHashCheck->Checked = g_pIni->ReadBool(CONFIG_ID, "ShowPasswHash", true);
  KeyExpiryCheck->Checked = g_pIni->ReadBool(CONFIG_ID, "KeyExpiry", true);
  KeyExpiryCheckClick(this);

  KeyExpiryTimeSpinBtn->Position =
    g_pIni->ReadInteger(CONFIG_ID, "KeyExpiryTime", 300);

  HashapassCompatCheck->Checked =
    g_pIni->ReadBool(CONFIG_ID, "HashapassCompatible", false);
  HashapassCompatCheckClick(this);

  int nCharSetIdx = g_pIni->ReadInteger(CONFIG_ID, "CharSetListIdx", 0);
  if (nCharSetIdx < 0 || nCharSetIdx >= MPPG_CHARSETS_NUM)
    nCharSetIdx = 0;
  CharSetList->ItemIndex = nCharSetIdx;
  CharSetListChange(this);

  PasswLengthSpinBtn->Position = g_pIni->ReadInteger(CONFIG_ID, "PasswLength",
    PASSW_DEFAULT_LEN);
  TogglePasswBtn->Down = g_pIni->ReadBool(CONFIG_ID, "HidePassw", false);
  TogglePasswBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::SaveConfig(void)
{
  g_pIni->WriteInteger(CONFIG_ID, "WindowTop", Top);
  g_pIni->WriteInteger(CONFIG_ID, "WindowLeft", Left);
  g_pIni->WriteInteger(CONFIG_ID, "WindowHeight", Height);
  g_pIni->WriteInteger(CONFIG_ID, "WindowWidth", Width);
  g_pIni->WriteBool(CONFIG_ID, "ConfirmPassw", ConfirmPasswCheck->Checked);
  g_pIni->WriteBool(CONFIG_ID, "ShowPasswHash", ShowPasswHashCheck->Checked);
  g_pIni->WriteBool(CONFIG_ID, "KeyExpiry", KeyExpiryCheck->Checked);
  g_pIni->WriteInteger(CONFIG_ID, "KeyExpiryTime", KeyExpiryTimeSpinBtn->Position);
  g_pIni->WriteBool(CONFIG_ID, "HashapassCompatible", HashapassCompatCheck->Checked);
  g_pIni->WriteInteger(CONFIG_ID, "CharSetListIdx", CharSetList->ItemIndex);
  g_pIni->WriteInteger(CONFIG_ID, "PasswLength", PasswLengthSpinBtn->Position);
  g_pIni->WriteBool(CONFIG_ID, "HidePassw", TogglePasswBtn->Down);
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::ClearKey(bool blExpired,
                                         bool blClearKeyOnly)
{
  m_key.Empty();
  memzero(memcryptKey, sizeof(memcryptKey));

  if (!blClearKeyOnly) {
    ClearEditBoxTextBuf(PasswBox, 256);
    ClearEditBoxTextBuf(ParameterBox, 256);
    PasswSecurityBarPanel->Visible = false;
    PasswInfoLbl->Visible = false;
  }

  KeyExpiryTimer->Enabled = false;
  m_nExpiryCountdown = 0;
  KeyExpiryCountdownLbl->Caption = "";
  GenerateBtn->Enabled = false;
  UseAsDefaultRNGBtn->Enabled = false;

  TDateTime currTime = TDateTime::CurrentTime();
  WString sInfo = currTime.TimeString() + WString(" ");

  if (blExpired)
    sInfo += TRL("Key has expired.");
  else
    sInfo += TRL("Key has been cleared.");

  PasswStatusBox->Text = sInfo;
  HashapassCompatCheck->Enabled = true;
  ClearKeyBtn->Enabled = blClearKeyOnly;
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::SetKeyExpiry(bool blSetup)
{
  bool blExpire = KeyExpiryCheck->Checked;
  bool blTimeZero = KeyExpiryTimeSpinBtn->Position == 0;

  if (blExpire && blTimeZero && !blSetup)
    ClearKey(true, true);
  else if (blExpire && !blTimeZero) {
    KeyExpiryTimer->Enabled = true;
    m_nExpiryCountdown = KeyExpiryTimeSpinBtn->Position;
    KeyExpiryCountdownLbl->Caption = IntToStr(m_nExpiryCountdown);
  }
  else {
    KeyExpiryTimer->Enabled = false;
    KeyExpiryCountdownLbl->Caption = "";
  }
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::EnterPasswBtnClick(TObject *Sender)
{
  SecureWString sPassw;
  bool blSuccess = PasswEnterDlg->Execute(ConfirmPasswCheck->Checked ?
    PASSWENTER_FLAG_CONFIRMPASSW : 0, TRL("Master password")) == mrOk;
  if (blSuccess)
    PasswEnterDlg->GetPassw(sPassw);

  PasswEnterDlg->Clear();
  RandomPool::GetInstance()->Flush();

  if (!blSuccess)
    return;

  bool blHashapass = HashapassCompatCheck->Checked;
  SecureMem<word8> tempKey(AESCtrPRNG::KEY_SIZE);

  if (blHashapass) {
    m_key.New(sPassw.Size() - 1);
    unicodeToLSByte(sPassw, (char*) m_key.Data(), m_key.Size());
  }

  sha256_hmac((const word8*) sPassw.Data(), (sPassw.Size() - 1) * sizeof(wchar_t),
    MPPG_KEYGEN_SALTSTR, sizeof(MPPG_KEYGEN_SALTSTR) - 1, tempKey, 0);

  if (!blHashapass)
    m_key.Assign(tempKey);

  // encrypt the key before storing it in memory
  fprng_fillbuf(memcryptKey, sizeof(memcryptKey));
  memcrypt_128bit(m_key, m_key, m_key.Size(), memcryptKey, AES_ENCRYPT);

  int nHashValue = -1;

  if (ShowPasswHashCheck->Checked) {
    SecureMem<word8> hash(32);
    sha256(tempKey, tempKey.Size(), hash, 0);

    nHashValue = (hash[0] << 8) | hash[1];
  }

  TDateTime currTime = TDateTime::CurrentTime();

  WString sPasswInfo = currTime.TimeString() + WString(" ") +
    TRL("New key generated.");

  if (nHashValue >= 0)
    sPasswInfo += FormatW(" Hash: %.4x.", nHashValue);

  PasswStatusBox->Text = sPasswInfo;

  ClearKeyBtn->Enabled = true;
  GenerateBtn->Enabled = true;
  UseAsDefaultRNGBtn->Enabled = true;
  HashapassCompatCheck->Enabled = false;
  UseAsDefaultRNGBtn->Enabled = !blHashapass;

  SetKeyExpiry(true);

  ParameterBox->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::KeyExpiryTimerTimer(TObject *Sender)
{
  m_nExpiryCountdown--;
  KeyExpiryCountdownLbl->Caption = IntToStr(m_nExpiryCountdown);

  if (m_nExpiryCountdown == 0)
    ClearKey(true);
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::ClearKeyBtnClick(TObject *Sender)
{
  ClearKey();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::GenerateBtnClick(TObject *Sender)
{
  if (m_key.IsEmpty())
    return;

  int nPasswBits;

  SecureMem<word8> plainKey(m_key.Size());
  memcrypt_128bit(m_key, plainKey, plainKey.Size(), memcryptKey, AES_DECRYPT);

  WString sParam = ParameterBox->Text;
  int nParamLen = sParam.Length();

  if (HashapassCompatCheck->Checked) {
    AnsiString asParam;

    if (nParamLen != 0) {
      asParam.SetLength(nParamLen);
      unicodeToLSByte(sParam, asParam.c_str(), nParamLen);
    }

    SecureMem<word8> passwBytes(20);

    sha1_hmac(plainKey, plainKey.Size(), asParam.c_str(), asParam.Length(),
      passwBytes);

    SecureAnsiString asPassw(9);
    word32 lOutputLen = 9;

    base64_encode(asPassw, &lOutputLen, passwBytes, 6, 0);

    SecureWString sPassw(9);
    asciiToUnicode(asPassw, sPassw, 9);

    SetEditBoxTextBuf(PasswBox, sPassw);

    nPasswBits = 48;
  }
  else {
    AESCtrPRNG randGen;

    randGen.SeedWithKey(plainKey, plainKey.Size(), (word8*) sParam.c_bstr(),
      sParam.Length() * sizeof(wchar_t));

    int nPasswLen = PasswLengthSpinBtn->Position;
    const char* pszCharSet = MPPG_CHARSETS[CharSetList->ItemIndex];
    int nCharSetSize = strlen(pszCharSet);

    SecureWString sPassw(nPasswLen + 1);

    for (int nI = 0; nI < nPasswLen; nI++)
      sPassw[nI] = pszCharSet[randGen.GetNumRange(nCharSetSize)];

    sPassw[nPasswLen] = '\0';

    SetEditBoxTextBuf(PasswBox, sPassw);

    nPasswBits = Floor(Log2(nCharSetSize) * nPasswLen);
  }

  PasswSecurityBarPanel->Visible = true;
  PasswInfoLbl->Visible = true;
  PasswSecurityBarPanel->Width = std::max((std::min(nPasswBits / 128.0, 1.0) *
    PasswSecurityBar->Width), 4);
  PasswInfoLbl->Caption = TRLFormat("%d bits", std::min(nPasswBits,
    AESCtrPRNG::KEY_SIZE*8));

  SetKeyExpiry();

  PasswBox->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::KeyExpiryCheckClick(TObject *Sender)
{
  KeyExpiryTimeBox->Enabled = KeyExpiryCheck->Checked;
  KeyExpiryTimeSpinBtn->Enabled = KeyExpiryCheck->Checked;
  if (Visible && KeyExpiryTimeBox->Enabled)
    KeyExpiryTimeBox->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::ClearParameterBtnClick(TObject *Sender)
{
  ParameterBox->Clear();
  ParameterBox->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::TogglePasswBtnClick(TObject *Sender)
{
  PasswBox->PasswordChar = (TogglePasswBtn->Down) ? PASSWORD_CHAR : '\0';
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::TntFormClose(TObject *Sender,
      TCloseAction &Action)
{
  if (!m_key.IsEmpty())
    ClearKey();
  if (Visible) {
    TopMostManager::GetInstance()->OnFormClose(this);
    if (g_nAppState & APPSTATE_HIDDEN)
      ShowWindow(Application->Handle, SW_HIDE);
  }
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::CloseBtnClick(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::UseAsDefaultRNGBtnClick(TObject *Sender)
{
  if (m_key.IsEmpty())
    return;

  SecureMem<word8> plainKey(m_key.Size());
  memcrypt_128bit(m_key, plainKey, plainKey.Size(), memcryptKey, AES_DECRYPT);

  if (g_pKeySeededPRNG.get() == NULL)
    g_pKeySeededPRNG.reset(new AESCtrPRNG);

  WString sParam = ParameterBox->Text;
  g_pKeySeededPRNG->SeedWithKey(plainKey, plainKey.Size(), (word8*) sParam.c_bstr(),
    sParam.Length() * sizeof(wchar_t));

  MainForm->UseKeySeededPRNG();
  SetKeyExpiry();
//  WindowState = wsMinimized;
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::HashapassCompatCheckClick(TObject *Sender)
{
  bool blEnabled = !HashapassCompatCheck->Checked;
  CharSetLbl->Enabled = blEnabled;
  CharSetList->Enabled = blEnabled;
  CharSetInfoLbl->Enabled = blEnabled;
  LengthLbl->Enabled = blEnabled;
  PasswLengthBox->Enabled = blEnabled;
  PasswLengthSpinBtn->Enabled = blEnabled;
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::ParameterBoxKeyPress(TObject *Sender,
      char &Key)
{
  if (Key == VK_RETURN)
    GenerateBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::TntFormActivate(TObject *Sender)
{
  if (m_key.IsEmpty())
    EnterPasswBtn->SetFocus();
  else
    ParameterBox->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::CharSetListChange(TObject *Sender)
{
  int nLen = strlen(MPPG_CHARSETS[CharSetList->ItemIndex]);
  double dEntropy = Log2(nLen);

  CharSetInfoLbl->Caption = TRLFormat("%d ch. / %.1f bits per ch.", nLen, dEntropy);
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::PasswBoxMenuPopup(TObject *Sender)
{
  bool blSelected = PasswBox->SelLength != 0;

  PasswBoxMenu_Undo->Enabled = PasswBox->CanUndo;
  PasswBoxMenu_Cut->Enabled = blSelected;
  PasswBoxMenu_Copy->Enabled = blSelected;
  PasswBoxMenu_EncryptCopy->Enabled = blSelected;
  PasswBoxMenu_Paste->Enabled = Clipboard()->HasFormat(CF_TEXT);
  PasswBoxMenu_Delete->Enabled = blSelected;
  PasswBoxMenu_SelectAll->Enabled = GetEditBoxTextLen(PasswBox) > 0;
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::PasswBoxMenu_UndoClick(TObject *Sender)
{
  PasswBox->Undo();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::PasswBoxMenu_CutClick(TObject *Sender)
{
  PasswBox->CutToClipboard();
  MainForm->CopiedSensitiveDataToClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::PasswBoxMenu_CopyClick(TObject *Sender)
{
  PasswBox->CopyToClipboard();
  MainForm->CopiedSensitiveDataToClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::PasswBoxMenu_EncryptCopyClick(
      TObject *Sender)
{
  SecureWString sText;
  GetEditBoxSelTextBuf(PasswBox, sText);
  MainForm->CryptText(true, &sText);
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::PasswBoxMenu_PasteClick(TObject *Sender)
{
  PasswBox->PasteFromClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::PasswBoxMenu_DeleteClick(TObject *Sender)
{
  PasswBox->SelText = "";
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::PasswBoxMenu_SelectAllClick(
      TObject *Sender)
{
  PasswBox->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::TntFormShow(TObject *Sender)
{
  TopMostManager::GetInstance()->SetForm(this);
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::PasswSecurityBarMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
  if (Shift.Contains(ssLeft))
    StartEditBoxDragDrop(PasswBox);
}
//---------------------------------------------------------------------------
void __fastcall TMPPasswGenDlg::ParameterLblMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
  if (Shift.Contains(ssLeft))
    StartEditBoxDragDrop(ParameterBox);
}
//---------------------------------------------------------------------------

