// PWGen.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USEFORM("Main.cpp", MainForm);
USEFORM("PasswList.cpp", PasswListForm);
USEFORM("PasswEnter.cpp", PasswEnterDlg);
USEFORM("PasswOptions.cpp", PasswOptionsDlg);
USEFORM("Callback.cpp", CallbackForm);
USEFORM("About.cpp", AboutForm);
USEFORM("CreateRandDataFile.cpp", CreateRandDataFileDlg);
USEFORM("QuickHelp.cpp", QuickHelpForm);
USEFORM("ProfileEditor.cpp", ProfileEditDlg);
USEFORM("CreateTrigramFile.cpp", CreateTrigramFileDlg);
USEFORM("MPPasswGen.cpp", MPPasswGenDlg);
USEFORM("Configuration.cpp", ConfigurationDlg);
USEFORM("ProvideEntropy.cpp", ProvideEntropyDlg);
//---------------------------------------------------------------------------
HANDLE g_hAppMutex;

WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 g_hAppMutex = CreateMutex(NULL, true, "PWGen Password Generator by C.T.");
                 if (g_hAppMutex == NULL)
                        RaiseLastOSError();

                 if (GetLastError() == ERROR_ALREADY_EXISTS) {
                   MessageBox(NULL, "An instance of PWGen is already running.\n"
                     "Please close it before starting a new instance.", "PWGen", MB_ICONWARNING);
                   return 0;
                 }

                 Application->Initialize();
                 Application->Title = "";
                 Application->CreateForm(__classid(TMainForm), &MainForm);
                 Application->CreateForm(__classid(TPasswListForm), &PasswListForm);
                 Application->CreateForm(__classid(TPasswEnterDlg), &PasswEnterDlg);
                 Application->CreateForm(__classid(TPasswOptionsDlg), &PasswOptionsDlg);
                 Application->CreateForm(__classid(TCallbackForm), &CallbackForm);
                 Application->CreateForm(__classid(TAboutForm), &AboutForm);
                 Application->CreateForm(__classid(TCreateRandDataFileDlg), &CreateRandDataFileDlg);
                 Application->CreateForm(__classid(TQuickHelpForm), &QuickHelpForm);
                 Application->CreateForm(__classid(TProfileEditDlg), &ProfileEditDlg);
                 Application->CreateForm(__classid(TCreateTrigramFileDlg), &CreateTrigramFileDlg);
                 Application->CreateForm(__classid(TMPPasswGenDlg), &MPPasswGenDlg);
                 Application->CreateForm(__classid(TConfigurationDlg), &ConfigurationDlg);
                 Application->CreateForm(__classid(TProvideEntropyDlg), &ProvideEntropyDlg);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
