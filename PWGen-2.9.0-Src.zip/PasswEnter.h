// PasswEnter.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//----------------------------------------------------------------------------
#ifndef PasswEnterH
#define PasswEnterH
//----------------------------------------------------------------------------
#include <Buttons.hpp>
#include <StdCtrls.hpp>
#include <Controls.hpp>
#include <Forms.hpp>
#include <Graphics.hpp>
#include <Classes.hpp>
#include <SysUtils.hpp>
#include <Windows.hpp>
#include <System.hpp>
//----------------------------------------------------------------------------
#include "TntForms.hpp"
#include "TntStdCtrls.hpp"
#include "SecureMem.h"
#include "UnicodeUtil.h"

const int
  PASSWENTER_FLAG_ENCRYPT      = 1,
  PASSWENTER_FLAG_DECRYPT      = 2,
  PASSWENTER_FLAG_CONFIRMPASSW = 4,
  PASSWENTER_FLAG_ENABLEOLDVER = 8;

class TPasswEnterDlg : public TTntForm
{
__published:
        TTntLabel *PasswLbl;
        TTntCheckBox *DisplayPasswCheck;
        TTntLabel *ConfirmPasswLbl;
        TTntCheckBox *OldVersionCheck;
        TTntButton *OKBtn;
        TTntButton *CancelBtn;
        TTntEdit *PasswBox;
        TTntEdit *ConfirmPasswBox;
        void __fastcall DisplayPasswCheckClick(TObject *Sender);
        void __fastcall OKBtnClick(TObject *Sender);
        void __fastcall PasswBoxChange(TObject *Sender);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall TntFormShow(TObject *Sender);
private:
        int m_nFlags;
        SecureWString a;
public:
	virtual __fastcall TPasswEnterDlg(TComponent* AOwner);
        int __fastcall Execute(int nFlags,
                               const WString& sTitle = "");
        void __fastcall GetPassw(SecureWString& sDest, int nPassw = 0);
        void __fastcall LoadConfig(void);
        void __fastcall SaveConfig(void);
        void __fastcall Clear(void);
};
//----------------------------------------------------------------------------
extern PACKAGE TPasswEnterDlg *PasswEnterDlg;
//----------------------------------------------------------------------------
#endif    
