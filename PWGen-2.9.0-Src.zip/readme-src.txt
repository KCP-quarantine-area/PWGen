﻿                            PWGen for Windows
                            =================
                Copyright (c) 2002-2016 by Christian Thöing


COMPILING PWGEN

  If you want to build PWGen yourself from the source code, you will need

    - Borland C++ Builder 6 or a higher version, including all updates
    - Tnt Delphi Unicode Controls version 2.3.0
      (available from http://www.axolot.com/TNT/)
    - [optional] stripreloc to remove the relocation section from the .exe
      file built by C++ Builder (this reduces the file size a bit)
      (check http://www.jrsoftware.org/striprlc.php)
    - [optional] Inno Setup to create the setup of PWGen (you should use the
      file PWGen.iss for this purpose)
    
 
LICENSE / COPYRIGHT NOTICE

  PWGen: Copyright (c) 2002-2015 by Christian Thöing <c.thoeing@web.de>.

  This program is FREE software; it is distributed under the terms and
  conditions of the GNU General Public License (GPL) as published by the
  Free Software Foundation. See "license.txt" for more details.

  This source code package contains the following third-party Open Source
  components:
  
    - implementations of AES, SHA1, SHA-256, and base64 encoding by Brainspark
      B.V. (PolarSSL library: http://polarssl.org)
    - miniLZO by Markus F.X.J. Oberhumer
      (http://www.oberhumer.com/opensource/lzo/)
    - diceware8k list created by Arnold G. Reinhold
      (http://www.diceware.com)


CONTACT

  PWGen is hosted at SourceForge; the project homepage is:

    http://pwgen-win.sourceforge.net

  For downloads, check:

    http://sourceforge.net/projects/pwgen-win/

  If you have any questions or problems, feel free to contact me!