// About.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "About.h"
#include "Main.h"
#include "Language.h"
#include "ProgramDef.h"
#include "Util.h"
#include "TopMostManager.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "TntStdCtrls"
#pragma link "TntExtCtrls"
#pragma resource "*.dfm"
TAboutForm *AboutForm;
//---------------------------------------------------------------------------
__fastcall TAboutForm::TAboutForm(TComponent* Owner)
        : TTntForm(Owner)
{
  Caption = TRLFormat("About %s", PROGRAM_NAME);
  ProgramLbl->Caption = WString(PROGRAM_NAME) + WString(" v") + WString(PROGRAM_VERSION);
#ifdef _DEBUG
  ProgramLbl->Caption = ProgramLbl->Caption + WString(" debug");
#endif
  if (Win32PlatformIsUnicode)
    UnicodeLbl->Caption = "unicode";
  CopyrightLbl->Caption = PROGRAM_COPYRIGHT;
  AuthorLbl->Caption = PROGRAM_AUTHOR;
  AuthorLbl->Hint = WString("mailto:") + WString(PROGRAM_AUTHOR_EMAIL);
  WWWLbl->Caption = PROGRAM_URL_WEBSITE;
  ViewLicenseLbl->Hint = PROGRAM_LICENSEFILE;
  if (g_pLangSupp != NULL) {
    TRLCaption(LicenseLbl);
    TRLCaption(ViewLicenseLbl);
    TRLCaption(OKBtn);
  }

  float fImgScale = float(PixelsPerInch) / Screen->PixelsPerInch;
  if (fImgScale != 1) {
    LogoImg->Height *= fImgScale;
    LogoImg->Width *= fImgScale;
  }

  WString sLangName = TRLDEF(LANGUAGE_NAME, "English");
  WString sLangVer = TRLDEF(LANGUAGE_VERSION, "");
  if (!sLangVer.IsEmpty())
    sLangName += WString(" (v") + sLangVer + WString(")");
  WString sTransl = TRLDEF(LANGUAGE_AUTHOR, "(original language)");
  LanguageInfoLbl->Caption = TRLFormat("Current language: %s\n"
    "Translator: %s", sLangName, sTransl);
}
//---------------------------------------------------------------------------
void __fastcall TAboutForm::FormShow(TObject *Sender)
{
  Top = MainForm->Top + (MainForm->Height - Height) / 2;
  Left = MainForm->Left + (MainForm->Width - Width) / 2;
  TopMostManager::GetInstance()->SetForm(this);
}
//---------------------------------------------------------------------------
void __fastcall TAboutForm::AuthorLblClick(TObject *Sender)
{
  ExecuteShellOp(AuthorLbl->Hint);
}
//---------------------------------------------------------------------------
void __fastcall TAboutForm::WWWLblClick(TObject *Sender)
{
  ExecuteShellOp(PROGRAM_URL_WEBSITE);
}
//---------------------------------------------------------------------------
void __fastcall TAboutForm::ViewLicenseLblClick(TObject *Sender)
{
  ExecuteShellOp(g_sExePath + WString(PROGRAM_LICENSEFILE));
}
//---------------------------------------------------------------------------
