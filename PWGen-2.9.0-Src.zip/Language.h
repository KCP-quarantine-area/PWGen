// Language.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#ifndef LanguageH
#define LanguageH
//---------------------------------------------------------------------------
#include <map>
#include "UnicodeUtil.h"
#include "TntMenus.hpp"

class LanguageSupport
{
private:
  std::map<word32, std::wstring> m_transl;
  std::map<word32, std::wstring>::iterator m_lastEntry;

  bool FindTransl(const AnsiString& asStr);
  bool FindTransl(const WString& sStr);

public:

  // constructor
  // -> language file name
  LanguageSupport(const WString& sFileName);

  // translation
  // -> string to translate
  // <- translated string
  WString Translate(const AnsiString& asStr);
  WString Translate(const WString& sStr);

  // translation
  // -> string to translate
  // -> default string to return if translation couldn't be found
  // <- translated string
  WString TranslateDef(const AnsiString& asStr,
                       const AnsiString& asDefault);

  // call this function if the last translation failed (i.e., caused an exception)
  // -> error message to display
  // -> if 'true', remove the erroneous entry from the list
  void LastTranslError(const AnsiString& asErrMsg,
                       bool blRemoveEntry = true);
};

extern LanguageSupport* g_pLangSupp;


// some useful functions

WString TRL(const AnsiString& asStr)
{
  if (g_pLangSupp == NULL)
    return asStr;
  return g_pLangSupp->Translate(asStr);
}

WString TRL(const WString& sStr)
{
  if (g_pLangSupp == NULL)
    return sStr;
  return g_pLangSupp->Translate(sStr);
}

WString TRL(const char* pszStr)
{
  if (g_pLangSupp == NULL)
    return WString(pszStr);
  return g_pLangSupp->Translate(AnsiString(pszStr));
}

WString TRLDEF(const AnsiString& asStr, const AnsiString& asDefault)
{
  if (g_pLangSupp == NULL)
    return asDefault;
  return g_pLangSupp->TranslateDef(asStr, asDefault);
}

void TRLS(WString& sStr)
{
  if (g_pLangSupp != NULL)
    sStr = g_pLangSupp->Translate(sStr);
}

template <class T> void TRLCaption(T* pControl)
{
  pControl->Caption = TRL(pControl->Caption);
}

void TRLMenuItem(TTntMenuItem* pItem)
{
  WString sCaption = pItem->Caption;
  int nAmpPos = sCaption.Pos("&");
  if (nAmpPos > 0)
    sCaption.Delete(nAmpPos, 1);
  pItem->Caption = TRL(sCaption);
}

template <class T> void TRLHint(T* pControl)
{
  pControl->Hint = TRL(pControl->Hint);
}

AnsiString ETRL(const AnsiString& asErrMsg)
{
  return UTF8Encode(TRL(asErrMsg));
}

WString TRLFormat(const AnsiString asFormat, ...);


#endif
