// PasswList.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "PasswList.h"
#include "Main.h"
#include "Util.h"
#include "Language.h"
#include "StringFileStreamW.h"
#include "TopMostManager.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "TntComCtrls"
#pragma link "TntMenus"
#pragma resource "*.dfm"
TPasswListForm *PasswListForm;

static const AnsiString
  CONFIG_ID = "PasswList";

//---------------------------------------------------------------------------
__fastcall TPasswListForm::TPasswListForm(TComponent* Owner)
        : TTntForm(Owner)
{
  if (g_pLangSupp != NULL) {
    TRLCaption(this);
    for (int nI = 0; nI < PasswListMenu->Items->Count; nI++)
      TRLCaption((TTntMenuItem*) PasswListMenu->Items->Items[nI]);
  }
  LoadConfig();
}
//---------------------------------------------------------------------------
__fastcall TPasswListForm::~TPasswListForm()
{
  ClearEditBoxTextBuf(PasswList);
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::LoadConfig(void)
{
  int nTop = g_pIni->ReadInteger(CONFIG_ID, "WindowTop", INT_MAX);
  int nLeft = g_pIni->ReadInteger(CONFIG_ID, "WindowLeft", INT_MAX);
  if (nTop == INT_MAX || nLeft == INT_MAX)
    Position = poScreenCenter;
  else {
    Top = nTop;
    Left = nLeft;
  }

  Height = g_pIni->ReadInteger(CONFIG_ID, "WindowHeight", Height);
  Width = g_pIni->ReadInteger(CONFIG_ID, "WindowWidth", Width);

  StringToFont(g_pIni->ReadString(CONFIG_ID, "Font", ""), PasswList->Font);
  FontDlg->Font = PasswList->Font;
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::SaveConfig(void)
{
  g_pIni->WriteInteger(CONFIG_ID, "WindowTop", Top);
  g_pIni->WriteInteger(CONFIG_ID, "WindowLeft", Left);
  g_pIni->WriteInteger(CONFIG_ID, "WindowHeight", Height);
  g_pIni->WriteInteger(CONFIG_ID, "WindowWidth", Width);
  g_pIni->WriteString(CONFIG_ID, "Font", FontToString(PasswList->Font));
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::Execute(void)
{
  PasswList->SelStart = 0;
  Show();
  if (WindowState == wsMinimized)
    WindowState = wsNormal;
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::PasswListMenu_CopyClick(TObject *Sender)
{
  PasswList->CopyToClipboard();
  MainForm->CopiedSensitiveDataToClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::PasswListMenu_SelectAllClick(TObject *Sender)
{
  PasswList->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::PasswListMenu_SaveAsFileClick(TObject *Sender)
{
  MainForm->SaveDlg->Title = TRL("Save password list");
  MainForm->Tag = 1;
  if (!MainForm->SaveDlg->Execute()) {
    MainForm->Tag = 0;
    return;
  }
  MainForm->Tag = 0;

  WString sFileName = MainForm->SaveDlg->FileName;
  //TStringFileStreamW* pFile = NULL;

  Screen->Cursor = crHourGlass;
  bool blSuccess = false;
  WString sMsg;

  try {
    SecureWString sPasswList;
    GetEditBoxTextBuf(PasswList, sPasswList);

    std::auto_ptr<TStringFileStreamW> pFile(new TStringFileStreamW(sFileName, fmCreate, g_fileEncoding, true,
      PASSW_MAX_BYTES));

    int nBytesWritten;
    if (!pFile->WriteString(sPasswList, sPasswList.Size() - 1, nBytesWritten))
      OutOfDiskSpaceError();

/*
    wchar_t* pwszPassw = sPasswList.Data();

    while (pwszPassw != NULL) {
      wchar_t* pwszNext = wcschr(pwszPassw, '\n');
      int nPasswLen;

      if (pwszNext == NULL)
        nPasswLen = wcslen(pwszPassw);
      else {
        pwszNext++;
        nPasswLen = int(pwszNext - pwszPassw);
      }

      if (!pFile->WriteString(pwszPassw, nPasswLen))
        OutOfDiskSpaceError();

      pwszPassw = pwszNext;
    }
*/
    //delete pFile;

    blSuccess = true;
    sMsg = TRLFormat("File \"%s\" successfully created.", WideExtractFileName(sFileName));
  }
  catch (Exception& e) {
    //if (pFile != NULL)
    //  delete pFile;
    sMsg = TRLFormat("Error while creating file\n\"%s\":\n%s.", sFileName,
      UTF8Decode(e.Message));
  }

  Screen->Cursor = crDefault;

  MsgBox(sMsg, (blSuccess) ? MB_ICONINFORMATION : MB_ICONERROR);
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::PasswListMenuPopup(TObject *Sender)
{
  bool blSelected = PasswList->SelLength != 0;

  PasswListMenu_Copy->Enabled = blSelected;
  PasswListMenu_EncryptCopy->Enabled = blSelected;
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::PasswListMenu_ChangeFontClick(TObject *Sender)
{
  MainForm->Tag = 1;
  if (FontDlg->Execute())
    PasswList->Font = FontDlg->Font;
  MainForm->Tag = 0;
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::FormClose(TObject *Sender, TCloseAction &Action)
{
  ClearEditBoxTextBuf(PasswList);
  TopMostManager::GetInstance()->OnFormClose(this);
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::FormKeyPress(TObject *Sender, char &Key)
{
  if (Key == VK_ESCAPE)
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::PasswListMenu_EncryptCopyClick(
      TObject *Sender)
{
  SecureWString sText;
  GetRichEditSelTextBuf(PasswList, sText);
  MainForm->CryptText(true, &sText);
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::TntFormShow(TObject *Sender)
{
  TopMostManager::GetInstance()->SetForm(this);
}
//---------------------------------------------------------------------------
void __fastcall TPasswListForm::PasswListStartDrag(TObject *Sender,
      TDragObject *&DragObject)
{
  StartEditBoxDragDrop(PasswList);
}
//---------------------------------------------------------------------------

