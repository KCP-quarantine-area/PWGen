// MemUtil.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <mem.h>
#pragma hdrstop

#include "MemUtil.h"
#include "aes.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)


void memzero(void* pMem, word32 lSize)
{
  memset(pMem, 0, lSize);
}
//---------------------------------------------------------------------------
void memcrypt_128bit(const word8* pSrc,
                     word8* pDest,
                     word32 lSize,
                     const word8* pKey,
                     int nMode)
{
  aes_context cryptCtx;
  aes_setkey_enc(&cryptCtx, pKey, 128);

  word8 iv[16];
  memzero(iv, sizeof(iv));

  word32 lIVOff = 0;
  aes_crypt_cfb128(&cryptCtx, nMode, lSize, &lIVOff, iv, pSrc, pDest);

  memzero(&cryptCtx, sizeof(aes_context));
  memzero(iv, sizeof(iv));
}
//---------------------------------------------------------------------------
