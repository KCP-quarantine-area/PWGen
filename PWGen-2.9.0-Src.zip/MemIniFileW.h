// MemIniFileW.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#ifndef MemIniFileWH
#define MemIniFileWH
//---------------------------------------------------------------------------
#include <inifiles.hpp>
#include <TntClasses.hpp>
#include "UnicodeUtil.h"

class TMemIniFileW : public TMemIniFile
{
private:
  WString m_sFileName;

public:

  __fastcall TMemIniFileW(const WString& sFileName);

  void __fastcall UpdateFile(void);

  void __fastcall WriteWString(const AnsiString& asSection,
                               const AnsiString& asIdent,
                               const WString& sValue)
  {
    TMemIniFile::WriteString(asSection, asIdent, WStringToUtf8(sValue));
  }

  WString __fastcall ReadWString(const AnsiString& asSection,
                                 const AnsiString& asIdent,
                                 const AnsiString& asDefault)
  {
    return Utf8ToWString(TMemIniFile::ReadString(asSection, asIdent, asDefault));
  }

  __property WString FileName =
  { read=m_sFileName, write=m_sFileName };
};


#endif
 