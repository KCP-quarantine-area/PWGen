// ProfileEditor.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------

#ifndef ProfileEditorH
#define ProfileEditorH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "TntForms.hpp"
#include "TntStdCtrls.hpp"
//---------------------------------------------------------------------------
class TProfileEditDlg : public TTntForm
{
__published:	// IDE-managed Components
        TTntListBox *ProfileList;
        TTntLabel *ProfileNameLbl;
        TTntCheckBox *SaveAdvancedOptionsCheck;
        TTntCheckBox *ConfirmCheck;
        TTntButton *LoadBtn;
        TTntButton *DeleteBtn;
        TTntButton *AddBtn;
        TTntButton *CloseBtn;
        TTntEdit *ProfileNameBox;
        void __fastcall ProfileListClick(TObject *Sender);
        void __fastcall ProfileNameBoxChange(TObject *Sender);
        void __fastcall LoadBtnClick(TObject *Sender);
        void __fastcall DeleteBtnClick(TObject *Sender);
        void __fastcall AddBtnClick(TObject *Sender);
        void __fastcall ProfileNameBoxKeyPress(TObject *Sender, char &Key);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall ProfileListDblClick(TObject *Sender);
        void __fastcall TntFormShow(TObject *Sender);
private:	// User declarations
        bool m_blModified;
public:		// User declarations
        __fastcall TProfileEditDlg(TComponent* Owner);
        void __fastcall LoadConfig(void);
        void __fastcall SaveConfig(void);
        bool __fastcall Execute(void);
};
//---------------------------------------------------------------------------
extern PACKAGE TProfileEditDlg *ProfileEditDlg;
//---------------------------------------------------------------------------
#endif
