// hrtimer.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#ifndef hrtimerH
#define hrtimerH
//---------------------------------------------------------------------------
#include "types.h"

const int HRT_NONE_ACCURACY_DERATING = 10000; // 100 nanoseconds => 1 millisecond

enum THighResTimer {
  hrtNone,   // uses GetSystemTimeAsFileTime()
  hrtRDTSC,  // uses RDTSC Pentium instruction
  hrtQPC     // uses Windows API function QueryPerformanceCounter()
};

extern THighResTimer g_highResTimer;

// check which high resolution timer is available
// -> does the Windows API recognize the parameter for checking if the
//    RDTSC instruction is present?
THighResTimer HighResTimerCheck(bool blWinApiRDTSC);

// get the current value of the high resolution timer
// -> buffer for the timer value (size must be at least 8 bytes)
void HighResTimer(void* pTimer);

#endif
 