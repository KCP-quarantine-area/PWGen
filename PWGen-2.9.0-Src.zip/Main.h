// Main.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <CheckLst.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <Menus.hpp>
#include <jpeg.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
#include <windows.h>
#include "TntButtons.hpp"
#include "TntComCtrls.hpp"
#include "TntDialogs.hpp"
#include "TntExtCtrls.hpp"
#include "TntMenus.hpp"
#include "TntStdCtrls.hpp"
#include "RandomPool.h"
#include "PasswGen.h"
#include "PasswOptions.h"
#include "RandomGenerator.h"
#include "MemIniFileW.h"
#include "CGAUGES.h"
#include "Configuration.h"
#include "UpdateCheck.h"

#define MYWM_NOTIFY  (WM_APP + 100)
#define IDC_MYICON   1006

struct PWGenProfile {
  WString ProfileName;
  bool IncludeChars;
  int CharsLength;
  WString CharSet;
  bool IncludeWords;
  int WordsNum;
  WString WordListFileName;
  bool CombineWordsChars;
  bool SpecifyLength;
  AnsiString SpecifyLengthString;
  bool FormatPassw;
  WString FormatString;
  int PasswNum;
  bool AdvancedOptionsUsed;
  PasswOptions AdvancedPasswOptions;
};

const int
  PASSW_MAX_BYTES  = 65536,
  PROFILES_MAX_NUM = 50;

const int
  APPSTATE_MINIMIZED  = 0x01,
  APPSTATE_HIDDEN     = 0x02,
  APPSTATE_SYSTEMTRAY = 0x04;

extern std::auto_ptr<TMemIniFileW> g_pIni;
extern std::auto_ptr<TList> g_pProfileList;
extern RandomGenerator* g_pRandSrc;
extern std::auto_ptr<RandomGenerator> g_pKeySeededPRNG;
extern WString g_sExePath;
extern WString g_sAppDataPath;
extern CharacterEncoding g_fileEncoding;
extern int g_nAppState;

class TMainForm : public TTntForm
{
__published:	// IDE-managed Components
        TTntPanel *ToolBar;
        TTntLabel *LogoLbl;
        TTntGroupBox *PasswGroup;
        TTntEdit *PasswBox;
        TTntButton *GenerateBtn;
        TTntLabel *PasswInfoLbl;
        TTntGroupBox *SettingsGroup;
        TTntCheckBox *IncludeCharsCheck;
        TTntCheckBox *IncludeWordsCheck;
        TTntLabel *CharsLengthLbl;
        TTntLabel *WordsNumLbl;
        TTntLabel *WordListFileLbl;
        TTntLabel *CharSetLbl;
        TTntLabel *CharSetInfoLbl;
        TTntLabel *WordListInfoLbl;
        TTntSpeedButton *MPPasswGenBtn;
        TTntGroupBox *RandomPoolGroup;
        TTntLabel *EntropyBitsLbl;
        TTntSpeedButton *ToggleRandPoolBtn;
        TTntOpenDialog *OpenDlg;
        TTntSpeedButton *ClearClipBtn;
        TTntSpeedButton *ConfigBtn;
        TTntSaveDialog *SaveDlg;
        TTntSpeedButton *CryptTextBtn;
        TTntPopupMenu *EntropyProgressMenu;
        TTntMenuItem *EntropyProgressMenu_ResetCounters;
        TTntComboBox *CharSetList;
        TTntCheckBox *CombineWordsCharsCheck;
        TTntPopupMenu *TrayMenu;
        TTntMenuItem *TrayMenu_Restore;
        TTntMenuItem *TrayMenu_N1;
        TTntMenuItem *TrayMenu_GenPassw;
        TTntMenuItem *TrayMenu_GenAndShowPassw;
        TTntMenuItem *TrayMenu_N2;
        TTntMenuItem *TrayMenu_ClearClip;
        TTntMenuItem *TrayMenu_EncryptClip;
        TTntMenuItem *TrayMenu_DecryptClip;
        TTntMenuItem *TrayMenu_CreateRandDataFile;
        TTntMenuItem *TrayMenu_N3;
        TTntMenuItem *TrayMenu_OpenManual;
        TTntMenuItem *TrayMenu_About;
        TTntMenuItem *TrayMenu_N4;
        TTntMenuItem *TrayMenu_Exit;
        TTimer *Timer;
        TTntSpeedButton *HelpBtn;
        TTntPopupMenu *ListMenu;
        TTntMenuItem *ListMenu_Cut;
        TTntMenuItem *ListMenu_Copy;
        TTntMenuItem *ListMenu_Paste;
        TTntMenuItem *ListMenu_Delete;
        TTntMenuItem *ListMenu_N3;
        TTntMenuItem *ListMenu_ClearList;
        TTntMenuItem *ListMenu_Undo;
        TTntMenuItem *ListMenu_N1;
        TTntMenuItem *ListMenu_SelectAll;
        TTntMenuItem *ListMenu_N2;
        TTntMainMenu *MainMenu;
        TTntMenuItem *MainMenu_File;
        TTntMenuItem *MainMenu_Tools;
        TTntMenuItem *MainMenu_Options;
        TTntMenuItem *MainMenu_Help;
        TTntMenuItem *MainMenu_File_Exit;
        TTntMenuItem *MainMenu_Tools_ClearClipboard;
        TTntMenuItem *MainMenu_Tools_EncryptClip;
        TTntMenuItem *MainMenu_Tools_DecryptClip;
        TTntMenuItem *MainMenu_Tools_N2;
        TTntMenuItem *MainMenu_Tools_CreateRandDataFile;
        TTntMenuItem *MainMenu_Options_Language;
        TTntMenuItem *MainMenu_Options_N2;
        TTntMenuItem *MainMenu_Options_Language_English;
        TTntMenuItem *MainMenu_Options_SaveSettingsOnExit;
        TTntMenuItem *MainMenu_Options_SaveSettingsNow;
        TTntMenuItem *MainMenu_Help_OpenManual;
        TTntMenuItem *MainMenu_Help_N1;
        TTntComboBox *WLFNList;
        TTntEdit *CharsLengthBox;
        TTntUpDown *CharsLengthSpinBtn;
        TTntEdit *WordsNumBox;
        TTntUpDown *WordsNumSpinBtn;
        TTntPopupMenu *PasswBoxMenu;
        TTntMenuItem *PasswBoxMenu_Copy;
        TTntMenuItem *PasswBoxMenu_SelectAll;
        TTntMenuItem *PasswBoxMenu_N3;
        TTntMenuItem *PasswBoxMenu_ChangeFont;
        TTntMenuItem *PasswBoxMenu_Undo;
        TTntMenuItem *PasswBoxMenu_N1;
        TTntMenuItem *PasswBoxMenu_Cut;
        TTntMenuItem *PasswBoxMenu_Paste;
        TTntMenuItem *PasswBoxMenu_Delete;
        TTntMenuItem *PasswBoxMenu_N2;
        TTntMenuItem *PasswBoxMenu_Editable;
        TFontDialog *FontDlg;
        TCGauge *EntropyProgress;
        TTntSpeedButton *TogglePasswBtn;
        TTntCheckBox *FormatPasswCheck;
        TTntComboBox *FormatList;
        TTntLabel *MultiplePasswLbl;
        TTntEdit *PasswNumBox;
        TTntButton *GenerateBtn2;
        TTntButton *AdvancedBtn;
        TTntSpeedButton *CharSetInfoBtn;
        TTntSpeedButton *BrowseBtn;
        TTntMenuItem *MainMenu_Help_VisitWebsite;
        TTntMenuItem *MainMenu_Help_Donate;
        TTntMenuItem *MainMenu_Help_N2;
        TTntLabel *FormatPasswInfoLbl;
        TTntSpeedButton *WordListInfoBtn;
        TTntMenuItem *EntropyProgressMenu_TotalEntropyBits;
        TTntMenuItem *EntropyProgressMenu_N1;
        TTntSpeedButton *CharSetHelpBtn;
        TTntSpeedButton *FormatPasswHelpBtn;
        TTntImage *Logo;
        TTntPanel *PasswSecurityBarPanel;
        TTntImage *PasswSecurityBar;
        TTntMenuItem *MainMenu_Help_TimerInfo;
        TTntMenuItem *MainMenu_File_Profile;
        TTntMenuItem *MainMenu_File_Profile_N1;
        TTntMenuItem *MainMenu_File_Profile_ProfileEditor;
        TTntSpeedButton *ProfileEditorBtn;
        TTntMenuItem *TrayMenu_Profile;
        TTntMenuItem *TrayMenu_Profile_N1;
        TTntMenuItem *TrayMenu_Profile_ProfileEditor;
        TTntSpeedButton *GenerateBtn3;
        TTntMenuItem *MainMenu_File_N1;
        TTntMenuItem *MainMenu_Tools_N3;
        TTntMenuItem *MainMenu_Tools_CreateTrigramFile;
        TTntMenuItem *MainMenu_Help_CheckForUpdates;
        TTntMenuItem *MainMenu_Help_N3;
        TTntMenuItem *MainMenu_Help_About;
        TTntMenuItem *MainMenu_Tools_N1;
        TTntMenuItem *MainMenu_Tools_MPPasswGen;
        TTntMenuItem *MainMenu_Tools_DetermRandGen;
        TTntMenuItem *MainMenu_Tools_DetermRandGen_Reset;
        TTntMenuItem *MainMenu_Tools_DetermRandGen_Deactivate;
        TTntMenuItem *TrayMenu_MPPasswGen;
        TTntMenuItem *PasswBoxMenu_EnablePasswTest;
        TTntMenuItem *PasswBoxMenu_N4;
        TTntMenuItem *PasswBoxMenu_EncryptCopy;
        TTntMenuItem *MainMenu_Options_Config;
        TTntMenuItem *MainMenu_Tools_N4;
        TTntMenuItem *MainMenu_Tools_ProvideAddEntropy;
        TTntBevel *Separator;
        TTntMenuItem *MainMenu_Options_AlwaysOnTop;
        TTntMenuItem *MainMenu_Options_N1;
        TTntMenuItem *MainMenu_Tools_ProvideAddEntropy_AsText;
        TTntMenuItem *MainMenu_Tools_ProvideAddEntropy_FromFile;
        TTntEdit *SpecifyLengthBox;
        TTntCheckBox *SpecifyLengthCheck;
        void __fastcall GenerateBtnClick(TObject *Sender);
        void __fastcall IncludeCharsCheckClick(TObject *Sender);
        void __fastcall CharSetInfoBtnClick(TObject *Sender);
        void __fastcall ToggleRandPoolBtnClick(TObject *Sender);
        void __fastcall BrowseBtnClick(TObject *Sender);
        void __fastcall ClearClipBtnClick(TObject *Sender);
        void __fastcall MPPasswGenBtnClick(TObject *Sender);
        void __fastcall CryptTextBtnMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall CryptTextBtnClick(TObject *Sender);
        void __fastcall EntropyProgressMenu_ResetCountersClick(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall MainMenu_Options_LanguageItemClick(TObject *Sender);
        void __fastcall MainMenu_Options_SaveSettingsNowClick(TObject *Sender);
        void __fastcall MainMenu_Help_AboutClick(TObject *Sender);
        void __fastcall TrayMenu_RestoreClick(TObject *Sender);
        void __fastcall TrayMenu_EncryptClipClick(TObject *Sender);
        void __fastcall TrayMenu_DecryptClipClick(TObject *Sender);
        void __fastcall TrayMenu_ExitClick(TObject *Sender);
        void __fastcall TimerTick(TObject *Sender);
        void __fastcall FormPaint(TObject *Sender);
        void __fastcall HelpBtnClick(TObject *Sender);
        void __fastcall AdvancedBtnClick(TObject *Sender);
        void __fastcall ListMenuPopup(TObject *Sender);
        void __fastcall ListMenu_UndoClick(TObject *Sender);
        void __fastcall ListMenu_CutClick(TObject *Sender);
        void __fastcall ListMenu_CopyClick(TObject *Sender);
        void __fastcall ListMenu_PasteClick(TObject *Sender);
        void __fastcall ListMenu_DeleteClick(TObject *Sender);
        void __fastcall ListMenu_SelectAllClick(TObject *Sender);
        void __fastcall ListMenu_ClearListClick(TObject *Sender);
        void __fastcall CharSetListEnter(TObject *Sender);
        void __fastcall WLFNListEnter(TObject *Sender);
        void __fastcall CharSetListKeyPress(TObject *Sender, char &Key);
        void __fastcall PasswNumBoxKeyPress(TObject *Sender, char &Key);
        void __fastcall PasswBoxKeyPress(TObject *Sender, char &Key);
        void __fastcall CharSetListExit(TObject *Sender);
        void __fastcall PasswBoxMenu_CopyClick(TObject *Sender);
        void __fastcall PasswBoxMenu_SelectAllClick(TObject *Sender);
        void __fastcall PasswBoxMenu_ChangeFontClick(TObject *Sender);
        void __fastcall TogglePasswBtnClick(TObject *Sender);
        void __fastcall CharsLengthBoxExit(TObject *Sender);
        void __fastcall WordsNumBoxExit(TObject *Sender);
        void __fastcall MainMenu_Help_VisitWebsiteClick(TObject *Sender);
        void __fastcall MainMenu_Help_DonateClick(TObject *Sender);
        void __fastcall PasswNumBoxExit(TObject *Sender);
        void __fastcall FormatListExit(TObject *Sender);
        void __fastcall WLFNListExit(TObject *Sender);
        void __fastcall WordListInfoBtnClick(TObject *Sender);
        void __fastcall WLFNListKeyPress(TObject *Sender, char &Key);
        void __fastcall FormatListEnter(TObject *Sender);
        void __fastcall EntropyProgressMenuPopup(TObject *Sender);
        void __fastcall CharSetHelpBtnClick(TObject *Sender);
        void __fastcall FormatPasswHelpBtnClick(TObject *Sender);
        void __fastcall PasswBoxChange(TObject *Sender);
        void __fastcall PasswBoxMenuPopup(TObject *Sender);
        void __fastcall PasswBoxMenu_UndoClick(TObject *Sender);
        void __fastcall PasswBoxMenu_CutClick(TObject *Sender);
        void __fastcall PasswBoxMenu_PasteClick(TObject *Sender);
        void __fastcall PasswBoxMenu_DeleteClick(TObject *Sender);
        void __fastcall PasswBoxMenu_EditableClick(TObject *Sender);
        void __fastcall MainMenu_Help_TimerInfoClick(TObject *Sender);
        void __fastcall ProfileEditorBtnClick(TObject *Sender);
        void __fastcall MainMenu_File_ProfileClick(TObject *Sender);
        void __fastcall TrayMenuPopup(TObject *Sender);
        void __fastcall MainMenu_Tools_CreateTrigramFileClick(
          TObject *Sender);
        void __fastcall MainMenu_Help_CheckForUpdatesClick(
          TObject *Sender);
        void __fastcall MainMenu_Tools_MPPasswGenClick(TObject *Sender);
        void __fastcall MainMenu_Tools_DetermRandGen_ResetClick(
          TObject *Sender);
        void __fastcall MainMenu_Tools_DetermRandGen_DeactivateClick(
          TObject *Sender);
        void __fastcall PasswBoxMenu_EnablePasswTestClick(TObject *Sender);
        void __fastcall MainMenu_File_ExitClick(TObject *Sender);
        void __fastcall PasswBoxMenu_EncryptCopyClick(TObject *Sender);
        void __fastcall MainMenu_Options_ConfigClick(TObject *Sender);
        void __fastcall MainMenu_Tools_CreateRandDataFileClick(
          TObject *Sender);
        void __fastcall TntFormResize(TObject *Sender);
        void __fastcall MainMenu_Options_AlwaysOnTopClick(TObject *Sender);
        void __fastcall MainMenu_Tools_ProvideAddEntropy_AsTextClick(TObject *Sender);
        void __fastcall MainMenu_Tools_ProvideAddEntropy_FromFileClick(
          TObject *Sender);
        void __fastcall PasswGroupMouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall SpecifyLengthCheckClick(TObject *Sender);
private:	// User declarations
        RandomPool* m_pRandPool;
        PasswordGenerator m_passwGen;
        WString m_sCharSetInput;
        WString m_sCharSetInfo;
        WString m_sWLFileName;
        WString m_sWordListInfo;
        WString m_sWLFileNameErr;
        WString m_sHelpFileName;
        WString m_sRandSeedFileName;
        WString m_sEntropyBitsLbl;
        WString m_sStartupErrors;
        WString m_sCharSetHelp;
        WString m_sFormatPasswHelp;
        int m_nNumStartupErrors;
        int m_nAutoClearClipCnt;
        bool m_blStartup;
        bool m_blCharSetError;
        //bool m_blSystemTray;
        //bool m_blMinimized;
        bool m_blShowEntProgress;
        bool m_blRestart;
        bool m_blConfigReadOnly;
        bool m_blHotKeySet;
        Configuration m_config;
        PasswOptions m_passwOptions;
        IDropTarget* m_pPasswBoxDropTarget;
        std::auto_ptr<TUpdateCheckThread> m_pUpdCheckThread;

        enum GeneratePasswDest
          { gpdGUISingle, gpdGUIList, gpdFileList, gpdClipboard, gpdMsgBox };

        void __fastcall DelayStartupError(const WString& sMsg);
        void __fastcall LoadLangConfig(void);
        bool __fastcall ChangeLanguage(const WString& sLangFileName);
        void __fastcall WriteRandSeedFile(bool blShowError = true);
        void __fastcall LoadConfig(void);
        bool __fastcall SaveConfig(void);
        int  __fastcall LoadCharSet(const WString& sInput,
                                    bool blShowError = false);
        int  __fastcall LoadWordListFile(const WString& sInput = "",
                                         bool blShowError = false,
                                         bool blResetInfoOnly = false);
        int  __fastcall LoadTrigramFile(const WString& sInput = "");
        void __fastcall GeneratePassw(GeneratePasswDest dest);
        int  __fastcall AddEntryToList(TTntComboBox* pComboBox,
                                       const WString& sEntry,
                                       bool blCaseSensitive);
        void __fastcall ShowPasswInfo(int nPasswLen, int nPasswBits,
                                      bool blEstimated = false);
        void __fastcall AppMessage(MSG& msg, bool& blHandled);
        void __fastcall AppException(TObject* Sender, Sysutils::Exception* E);
        void __fastcall AppMinimize(TObject* Sender);
        void __fastcall AppRestore(TObject* Sender);
        void __fastcall AppDeactivate(TObject* Sender);
        void __fastcall MyNotify(TMessage& msg);
        bool __fastcall TrayMessage(DWORD dwMessage);
        void __fastcall RecreateProfileMenus(void);
        void __fastcall OnHotKey(TMessage& msg);
        void __fastcall ChangeGUIFont(const AnsiString& asFontName,
                                      int nFontSize);
        void __fastcall ShowInfoBox(const WString& sInfo);
        void __fastcall SetAdvancedBtnCaption(void);
        void __fastcall OnUpdCheckThreadTerminate(TObject* Sender);
public:		// User declarations
        __fastcall TMainForm(TComponent* Owner);
        __fastcall ~TMainForm();
        bool __fastcall ApplyConfig(const Configuration& config);
        void __fastcall UpdateEntropyProgress(void);
        bool __fastcall ActivateHotKey(TShortCut hotKey);
        void __fastcall DeactivateHotKey(void);
        void __fastcall CreateProfile(const WString& sProfileName,
                                      bool blSaveAdvancedOptions,
                                      int nCreateIdx = -1);
        void __fastcall LoadProfile(int nIndex);
        void __fastcall DeleteProfile(int nIndex);
        void __fastcall UseKeySeededPRNG(void);
        void __fastcall CryptText(bool blEncrypt,
                                  const SecureWString* psText = NULL);
        void __fastcall CopiedSensitiveDataToClipboard(void);
BEGIN_MESSAGE_MAP
        VCL_MESSAGE_HANDLER(MYWM_NOTIFY, TMessage, MyNotify)
        VCL_MESSAGE_HANDLER(WM_HOTKEY, TMessage, OnHotKey)
END_MESSAGE_MAP(TForm)
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
