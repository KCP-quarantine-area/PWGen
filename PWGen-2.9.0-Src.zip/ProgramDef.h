// ProgramDef.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#ifndef ProgramDefH
#define ProgramDefH
//---------------------------------------------------------------------------

const wchar_t
  PROGRAM_NAME[]         = L"PWGen",
  PROGRAM_VERSION[]      = L"2.9.0",
  PROGRAM_LANGVER_MIN[]  = L"2.9.0",
  PROGRAM_AUTHOR[]       = L"Christian Th\xF6ing",
  PROGRAM_AUTHOR_EMAIL[] = L"c.thoeing@web.de",
  PROGRAM_COPYRIGHT[]    = L"Copyright \xa9 2002-2016",
  PROGRAM_URL_WEBSITE[]  = L"http://pwgen-win.sourceforge.net",
  PROGRAM_URL_DONATE[]   = L"http://sourceforge.net/donate/index.php?group_id=57385",
  PROGRAM_URL_VERSION[]  = L"http://pwgen-win.sourceforge.net/version.txt",
  PROGRAM_HELPFILE[]     = L"manual.pdf",
  PROGRAM_LICENSEFILE[]  = L"license.txt",
  PROGRAM_INIFILE[]      = L"PWGen.ini",
  PROGRAM_RANDSEEDFILE[] = L"randseed.dat";

const wchar_t
  LANGUAGE_NAME[]        = L"[LANGUAGENAME]",
  LANGUAGE_VERSION[]     = L"[LANGUAGEVERSION]",
  LANGUAGE_AUTHOR[]      = L"[LANGUAGEAUTHOR]",
  LANGUAGE_HELPFILE[]    = L"[LANGUAGEHELPFILE]";

const wchar_t
  LANGUAGE_DEFAULT[]     = L"English";

//---------------------------------------------------------------------------
#endif
