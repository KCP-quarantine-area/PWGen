// PasswEnter.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "PasswEnter.h"
#include "Util.h"
#include "Main.h"
#include "Language.h"
#include "TopMostManager.h"
//---------------------------------------------------------------------
#pragma link "TntStdCtrls"
#pragma resource "*.dfm"
TPasswEnterDlg *PasswEnterDlg;

static const char
  PASSWORD_CHAR = '*';

static const AnsiString
  CONFIG_ID     = "PasswEnter";

//---------------------------------------------------------------------
__fastcall TPasswEnterDlg::TPasswEnterDlg(TComponent* AOwner)
	: TTntForm(AOwner)
{
  Constraints->MaxHeight = Height;
  Constraints->MinHeight = Height;
  Constraints->MinWidth = Width;

  if (g_pLangSupp != NULL) {
    TRLCaption(PasswLbl);
    TRLCaption(ConfirmPasswLbl);
    TRLCaption(DisplayPasswCheck);
    TRLCaption(OKBtn);
    TRLCaption(CancelBtn);
  }
  LoadConfig();
}
//---------------------------------------------------------------------------
void __fastcall TPasswEnterDlg::LoadConfig(void)
{
  Width = g_pIni->ReadInteger(CONFIG_ID, "WindowWidth", Width);
  DisplayPasswCheck->Checked = g_pIni->ReadBool(CONFIG_ID, "DisplayPassw", false);
  DisplayPasswCheckClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TPasswEnterDlg::SaveConfig(void)
{
  g_pIni->WriteInteger(CONFIG_ID, "WindowWidth", Width);
  g_pIni->WriteBool(CONFIG_ID, "DisplayPassw", DisplayPasswCheck->Checked);
}
//---------------------------------------------------------------------
void __fastcall TPasswEnterDlg::DisplayPasswCheckClick(TObject *Sender)
{
  PasswBox->PasswordChar = (DisplayPasswCheck->Checked) ? '\0' : PASSWORD_CHAR;
  ConfirmPasswBox->PasswordChar = PasswBox->PasswordChar;
}
//---------------------------------------------------------------------------
void __fastcall TPasswEnterDlg::OKBtnClick(TObject *Sender)
{
  if (m_nFlags & PASSWENTER_FLAG_CONFIRMPASSW) {
    SecureWString sPassw1, sPassw2;
    GetPassw(sPassw1, 0);
    GetPassw(sPassw2, 1);
    if (sPassw1 != sPassw2) {
      MsgBox(TRL("Passwords are not identical."), MB_ICONWARNING);
      PasswBox->SetFocus();
      return;
    }
  }
  ModalResult = mrOk;
}
//---------------------------------------------------------------------------
int __fastcall TPasswEnterDlg::Execute(int nFlags,
                                       const WString& sTitle)
{
  if (nFlags & PASSWENTER_FLAG_ENCRYPT) {
    Caption = TRL("Encrypt");
    PasswLbl->Color = clYellow;
  }
  else if (nFlags & PASSWENTER_FLAG_DECRYPT) {
    Caption = TRL("Decrypt");
    PasswLbl->Color = clLime;
  }
  else {
    Caption = sTitle;
    PasswLbl->Color = clBtnFace;
  }

  ConfirmPasswLbl->Enabled = nFlags & PASSWENTER_FLAG_CONFIRMPASSW;
  ConfirmPasswBox->Enabled = nFlags & PASSWENTER_FLAG_CONFIRMPASSW;

  OldVersionCheck->Checked = false;
  OldVersionCheck->Enabled = nFlags & PASSWENTER_FLAG_ENABLEOLDVER;

  m_nFlags = nFlags;

  return ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TPasswEnterDlg::GetPassw(SecureWString& sDest,
                                         int nPassw)
{
  TTntEdit* pBox = (nPassw == 0) ? PasswBox : ConfirmPasswBox;
  GetEditBoxTextBuf(pBox, sDest);
}
//---------------------------------------------------------------------------
void __fastcall TPasswEnterDlg::Clear(void)
{
  ClearEditBoxTextBuf(PasswBox, 256);
  if (m_nFlags & PASSWENTER_FLAG_CONFIRMPASSW)
    ClearEditBoxTextBuf(ConfirmPasswBox, 256);
}
//---------------------------------------------------------------------------
void __fastcall TPasswEnterDlg::PasswBoxChange(TObject *Sender)
{
  OKBtn->Enabled = (GetEditBoxTextLen(PasswBox) != 0);
}
//---------------------------------------------------------------------------
void __fastcall TPasswEnterDlg::FormActivate(TObject *Sender)
{
  PasswBox->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TPasswEnterDlg::TntFormShow(TObject *Sender)
{
  Top = MainForm->Top + (MainForm->Height - Height) / 2;
  Left = MainForm->Left + (MainForm->Width - Width) / 2;
  TopMostManager::GetInstance()->SetForm(this);
}
//---------------------------------------------------------------------------

