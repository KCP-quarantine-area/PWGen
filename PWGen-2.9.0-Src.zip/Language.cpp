// Language.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#include <stdio.h>
#include <TntSystem.hpp>
#include <TntSysUtils.hpp>
#pragma hdrstop

#include "Language.h"
#include "UnicodeUtil.h"
#include "StringFileStreamW.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

LanguageSupport* g_pLangSupp = NULL;


// calculate hash of a string without case sensitivity
// function "sdbm" from http://www.cse.yorku.ca/~oz/hash.htm
// very fast & reliable with respect to collision resistance
// (alternatives: FNV1 (better than FNV1a!), CRC-32; both are a little bit
// better regarding collision resistance, but slower)

template<class T>
static word32 strihash(const T* pStr)
{
  word32 lHash = 0;
  int ch;

  while ((ch = *pStr++) != '\0')
    lHash = toupper(ch) + (lHash << 6) + (lHash << 16) - lHash;

  return lHash;
}


//---------------------------------------------------------------------------
LanguageSupport::LanguageSupport(const WString& sFileName)
{
  std::auto_ptr<TStringFileStreamW> pFile(new TStringFileStreamW(sFileName, fmOpenRead));
  static const int MSG_BUF_SIZE = 1024;
  wchar_t wszMsg[MSG_BUF_SIZE];
  wchar_t wszParsed[MSG_BUF_SIZE];
  int nMsgLen, nState = 0;
  word32 lHash;

  while ((nMsgLen = pFile->ReadString(wszMsg, MSG_BUF_SIZE)) > 0) {
    int nI, nParsedLen;

    for (nI = nParsedLen = 0; nI < nMsgLen; nI++) {
      if (wszMsg[nI] == '\\') {
        wchar_t wch = wszMsg[nI+1];
        switch (wch) {
        case 'n':
          wch = '\n'; break;
        case 'r':
          wch = '\r'; break;
        case 't':
          wch = '\t'; break;
        case '\\':
        case '\'':
        case '\"':
          break;
        default:
          continue;
        }
        wszParsed[nParsedLen++] = wch;
        nI++;
      }
      else if (wszMsg[nI] == '/' && wszMsg[nI+1] == '/')
        // comment sequence = "//"
        break;
      else
        wszParsed[nParsedLen++] = wszMsg[nI];
    }

    if (nParsedLen == 0)
      continue;

    wszParsed[nParsedLen] = '\0';

    WString sMsg = Trim(WString(wszParsed));
    if (sMsg.IsEmpty()) {
      nState = 0;
      continue;
    }

    if (nState == 0) {
      lHash = strihash(sMsg.c_bstr());
      nState = 1;
    }
    else {
      std::pair<std::map<word32,std::wstring>::iterator,bool> ret =
        m_transl.insert(std::pair<word32,std::wstring>(lHash, sMsg.c_bstr()));
#ifdef _DEBUG
      if (!ret.second) {
        ShowMessage("Collision found:\n" + sMsg);
      }
#endif
      nState = 0;
    }
  }
  
  if (m_transl.empty())
    throw Exception("Language file does not contain any valid entries");

  m_lastEntry = m_transl.end();
}
//---------------------------------------------------------------------------
bool LanguageSupport::FindTransl(const AnsiString& asStr)
{
  if (!asStr.IsEmpty()) {
    word32 lHash = strihash(asStr.c_str());

    if ((m_lastEntry = m_transl.find(lHash)) != m_transl.end())
      return true;
  }

  return false;
}
//---------------------------------------------------------------------------
bool LanguageSupport::FindTransl(const WString& sStr)
{
  if (!sStr.IsEmpty()) {
    word32 lHash = strihash(sStr.c_bstr());

    if ((m_lastEntry = m_transl.find(lHash)) != m_transl.end())
      return true;
  }

  return false;
}
//---------------------------------------------------------------------------
WString LanguageSupport::Translate(const AnsiString& asStr)
{
  // not found? return the original string
  if (!FindTransl(asStr))
    return asStr;
  return WString(m_lastEntry->second.c_str());
}
//---------------------------------------------------------------------------
WString LanguageSupport::Translate(const WString& sStr)
{
  if (!FindTransl(sStr))
    return sStr;
  return WString(m_lastEntry->second.c_str());
}
//---------------------------------------------------------------------------
WString LanguageSupport::TranslateDef(const AnsiString& asStr,
                                      const AnsiString& asDefault)
{
  // not found? return the default string
  if (!FindTransl(asStr))
    return asDefault;
  return WString(m_lastEntry->second.c_str());
}
//---------------------------------------------------------------------------
void LanguageSupport::LastTranslError(const AnsiString& asErrMsg,
                                      bool blRemoveEntry)
{
  if (m_lastEntry != m_transl.end()) {
    MessageBoxW(Application->Handle,
      FormatW("An error has occurred while trying to process\nthe translated "
      "message\n\n\"%s\":\n\n%s.", m_lastEntry->second.c_str(), UTF8Decode(asErrMsg)),
      L"Error", MB_ICONERROR);
    if (blRemoveEntry) {
      m_transl.erase(m_lastEntry);
      m_lastEntry = m_transl.end();
    }
  }
}
//---------------------------------------------------------------------------
WString TRLFormat(const AnsiString asFormat, ...)
{
  va_list argptr;
  va_start(argptr, asFormat);

  WString sResult;
  try {
    sResult = FormatW_AL(TRL(asFormat), argptr);
  }
  catch (...)
  {
    g_pLangSupp->LastTranslError("Error while formatting translated string");
    sResult = FormatW(asFormat, argptr);
  }

  va_end(argptr);

  return sResult;
}
//---------------------------------------------------------------------------
