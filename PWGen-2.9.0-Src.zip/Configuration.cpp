// Configuration.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Configuration.h"
#include "Main.h"
#include "Util.h"
#include "Language.h"
#include "TopMostManager.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "TntComCtrls"
#pragma link "TntStdCtrls"
#pragma resource "*.dfm"
TConfigurationDlg *ConfigurationDlg;

static const AnsiString
  CONFIG_ID = "ConfigWin";

//---------------------------------------------------------------------------
__fastcall TConfigurationDlg::TConfigurationDlg(TComponent* Owner)
        : TTntForm(Owner)
{
  Constraints->MaxHeight = Height;
  Constraints->MinHeight = Height;
  Constraints->MinWidth = Width;

  AutoClearClipTimeSpinBtn->Min = AUTOCLEARCLIPTIME_MIN;
  AutoClearClipTimeSpinBtn->Max = AUTOCLEARCLIPTIME_MAX;

  if (g_pLangSupp != NULL) {
    TRLCaption(this);
    TRLCaption(GeneralSheet);
    TRLCaption(ChangeFontLbl);
    TRLCaption(SelectFontBtn);
    TRLCaption(AutoClearClipCheck);
    TRLCaption(ShowSysTrayIconConstCheck);
    TRLCaption(MinimizeToSysTrayCheck);

    TRLCaption(HotKeySheet);
    TRLCaption(ActivateHotKeyCheck);
    TRLCaption(HotKeyActionsGroup);
    TRLCaption(HotKeyShowMainWinCheck);

    int nI;
    for (nI = 0; nI < HotKeyActionsList->Items->Count; nI++)
      HotKeyActionsList->Items->Strings[nI] =
        TRL(HotKeyActionsList->Items->Strings[nI]);

    TRLCaption(FilesSheet);
    TRLCaption(FileEncodingLbl);

    TRLCaption(UpdatesSheet);
    TRLCaption(AutoCheckUpdatesLbl);
    for (nI = 0; nI < AutoCheckUpdatesList->Items->Count; nI++)
      AutoCheckUpdatesList->Items->Strings[nI] =
        TRL(AutoCheckUpdatesList->Items->Strings[nI]);

    TRLCaption(OKBtn);
    TRLCaption(CancelBtn);
  }

  LoadConfig();
}
//---------------------------------------------------------------------------
void __fastcall TConfigurationDlg::LoadConfig(void)
{
  //Height = g_pIni->ReadInteger(CONFIG_ID, "WindowHeight", Height);
  Width = g_pIni->ReadInteger(CONFIG_ID, "WindowWidth", Width);
}
//---------------------------------------------------------------------------
void __fastcall TConfigurationDlg::SaveConfig(void)
{
  //g_pIni->WriteInteger(CONFIG_ID, "WindowHeight", Height);
  g_pIni->WriteInteger(CONFIG_ID, "WindowWidth", Width);
}
//---------------------------------------------------------------------------
void __fastcall TConfigurationDlg::GetOptions(Configuration& config)
{
  config.GUIFontName = FontDlg->Font->Name;
  config.GUIFontSize = FontDlg->Font->Size;
  config.AutoClearClip = AutoClearClipCheck->Checked;
  config.AutoClearClipTime = AutoClearClipTimeSpinBtn->Position;
  config.ShowSysTrayIconConst = ShowSysTrayIconConstCheck->Checked;
  config.MinimizeToSysTray = MinimizeToSysTrayCheck->Checked;
  config.AutoCheckUpdates = TAutoCheckUpdates(AutoCheckUpdatesList->ItemIndex);
  config.HotKeyActivated = ActivateHotKeyCheck->Checked;
  config.HotKey = HotKeyBox->HotKey;
  config.HotKeyActShowMainWin = HotKeyShowMainWinCheck->Checked;
  config.HotKeyAction = THotKeyAction(HotKeyActionsList->ItemIndex);
  config.FileEncoding = CharacterEncoding(FileEncodingList->ItemIndex);
}
//---------------------------------------------------------------------------
void __fastcall TConfigurationDlg::SetOptions(const Configuration& config)
{
  FontDlg->Font->Name = config.GUIFontName;
  FontDlg->Font->Size = config.GUIFontSize;
  ShowFontSample(FontDlg->Font);
  AutoClearClipCheck->Checked = config.AutoClearClip;
  AutoClearClipTimeSpinBtn->Position = config.AutoClearClipTime;
  AutoClearClipCheckClick(this);
  ShowSysTrayIconConstCheck->Checked = config.ShowSysTrayIconConst;
  MinimizeToSysTrayCheck->Checked = config.MinimizeToSysTray;
  AutoCheckUpdatesList->ItemIndex = config.AutoCheckUpdates;
  ActivateHotKeyCheck->Checked = config.HotKeyActivated;
  HotKeyBox->HotKey = config.HotKey;
  HotKeyShowMainWinCheck->Checked = config.HotKeyActShowMainWin;
  HotKeyActionsList->ItemIndex = config.HotKeyAction;
  ActivateHotKeyCheckClick(this);
  FileEncodingList->ItemIndex = int(config.FileEncoding);
}
//---------------------------------------------------------------------------
void __fastcall TConfigurationDlg::ShowFontSample(TFont* pFont)
{
  AnsiString asFont = pFont->Name + ", " + IntToStr(pFont->Size) + "pt";
  FontSampleLbl->Caption = asFont;
  FontSampleLbl->Font->Name = pFont->Name;
  FontSampleLbl->Font->Size = pFont->Size;
}
//---------------------------------------------------------------------------
void __fastcall TConfigurationDlg::SelectFontBtnClick(TObject *Sender)
{
  TopMostManager::GetInstance()->NormalizeTopMosts(this);
  bool blSuccess = FontDlg->Execute();
  TopMostManager::GetInstance()->RestoreTopMosts(this);

  if (blSuccess)
    ShowFontSample(FontDlg->Font);
}
//---------------------------------------------------------------------------
void __fastcall TConfigurationDlg::AutoClearClipCheckClick(
      TObject *Sender)
{
  AutoClearClipTimeBox->Enabled = AutoClearClipCheck->Checked;
  AutoClearClipTimeSpinBtn->Enabled = AutoClearClipCheck->Checked;
  if (Visible && AutoClearClipTimeBox->Enabled)
    AutoClearClipTimeBox->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TConfigurationDlg::ActivateHotKeyCheckClick(
      TObject *Sender)
{
  bool blChecked = ActivateHotKeyCheck->Checked;

  HotKeyBox->Enabled = blChecked;
  HotKeyShowMainWinCheck->Enabled = blChecked;
  HotKeyActionsList->Enabled = blChecked;

  if (Visible && blChecked)
    HotKeyBox->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TConfigurationDlg::TntFormShow(TObject *Sender)
{
  Top = MainForm->Top + (MainForm->Height - Height) / 2;
  Left = MainForm->Left + (MainForm->Width - Width) / 2;

  TopMostManager::GetInstance()->SetForm(this);

  ConfigPages->ActivePage = GeneralSheet;
}
//---------------------------------------------------------------------------
void __fastcall TConfigurationDlg::OKBtnClick(TObject *Sender)
{
  if (ActivateHotKeyCheck->Checked) {
    if (!HotKeyShowMainWinCheck->Checked && HotKeyActionsList->ItemIndex == 0) {
      MsgBox(TRL("Please select a hot key action."), MB_ICONWARNING);
      ConfigPages->ActivePage = HotKeySheet;
      HotKeyShowMainWinCheck->SetFocus();
      return;
    }
  }

  Configuration config;
  GetOptions(config);

  if (MainForm->ApplyConfig(config))
    ModalResult = mrOk;
}
//---------------------------------------------------------------------------


