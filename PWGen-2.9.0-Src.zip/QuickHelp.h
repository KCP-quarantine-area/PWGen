// QuickHelp.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------

#ifndef QuickHelpH
#define QuickHelpH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "TntForms.hpp"
#include "TntStdCtrls.hpp"
//---------------------------------------------------------------------------
#include "UnicodeUtil.h"
#include "TntComCtrls.hpp"
#include <ComCtrls.hpp>
#include "TntMenus.hpp"
#include <Menus.hpp>
#include <Dialogs.hpp>

class TQuickHelpForm : public TTntForm
{
__published:	// IDE-managed Components
        TTntRichEdit *QuickHelpBox;
        TTntPopupMenu *QuickHelpBoxMenu;
        TTntMenuItem *QuickHelpBoxMenu_AutoPosition;
        TTntMenuItem *QuickHelpBoxMenu_N1;
        TTntMenuItem *QuickHelpBoxMenu_ChangeFont;
        TFontDialog *FontDlg;
        void __fastcall FormKeyPress(TObject *Sender, char &Key);
        void __fastcall TntFormShow(TObject *Sender);
        void __fastcall TntFormClose(TObject *Sender,
          TCloseAction &Action);
        void __fastcall QuickHelpBoxMenu_ChangeFontClick(TObject *Sender);
private:	// User declarations
        //int m_nMinWidth;
        //int m_nMinHeight;
        //int m_nVScrollX;
public:		// User declarations
        __fastcall TQuickHelpForm(TComponent* Owner);
        void __fastcall LoadConfig(void);
        void __fastcall SaveConfig(void);
        void __fastcall Execute(const WString& sHelp, word32 lHelpId,
          int nPosX, int nPosY);
};
//---------------------------------------------------------------------------
extern PACKAGE TQuickHelpForm *QuickHelpForm;
//---------------------------------------------------------------------------
#endif
