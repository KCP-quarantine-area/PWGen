// ProfileEditor.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ProfileEditor.h"
#include "Main.h"
#include "Util.h"
#include "Language.h"
#include "TopMostManager.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "TntStdCtrls"
#pragma resource "*.dfm"
TProfileEditDlg *ProfileEditDlg;

static const AnsiString
  CONFIG_ID = "ProfileEditor";

//---------------------------------------------------------------------------
__fastcall TProfileEditDlg::TProfileEditDlg(TComponent* Owner)
        : TTntForm(Owner)
{
  Constraints->MinHeight = Height;
  Constraints->MinWidth = Width;

  if (g_pLangSupp != NULL) {
    TRLCaption(this);
    TRLCaption(LoadBtn);
    TRLCaption(DeleteBtn);
    TRLCaption(ConfirmCheck);
    TRLCaption(ProfileNameLbl);
    TRLCaption(AddBtn);
    TRLCaption(SaveAdvancedOptionsCheck);
    TRLCaption(CloseBtn);
  }

  LoadConfig();

  for (int nI = 0; nI < g_pProfileList->Count; nI++) {
    PWGenProfile* pProfile = (PWGenProfile*) g_pProfileList->Items[nI];
    WString sProfileName = pProfile->ProfileName;
    if (pProfile->AdvancedOptionsUsed)
      sProfileName += WString(" [+]");

    ProfileList->Items->Add(sProfileName);
  }
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::LoadConfig(void)
{
  Height = g_pIni->ReadInteger(CONFIG_ID, "WindowHeight", Height);
  Width = g_pIni->ReadInteger(CONFIG_ID, "WindowWidth", Width);
  ConfirmCheck->Checked = g_pIni->ReadBool(CONFIG_ID, "Confirm", true);
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::SaveConfig(void)
{
  g_pIni->WriteInteger(CONFIG_ID, "WindowHeight", Height);
  g_pIni->WriteInteger(CONFIG_ID, "WindowWidth", Width);
  g_pIni->WriteBool(CONFIG_ID, "Confirm", ConfirmCheck->Checked);
}
//---------------------------------------------------------------------------
bool __fastcall TProfileEditDlg::Execute(void)
{
/*
  for (int nI = 0; nI < ProfileList->Count; nI++)
    ProfileList->Selected[nI] = false;

  LoadBtn->Enabled = false;
  DeleteBtn->Enabled = false;
*/

  m_blModified = false;
  ShowModal();

  return m_blModified;
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::ProfileListClick(TObject *Sender)
{
  if (ProfileList->SelCount == 0) {
    LoadBtn->Enabled = false;
    DeleteBtn->Enabled = false;
  }
  else if (ProfileList->SelCount == 1) {
    PWGenProfile* pProfile;
    for (int nI = 0; nI < ProfileList->Items->Count; nI++) {
      if (ProfileList->Selected[nI]) {
        pProfile = (PWGenProfile*) g_pProfileList->Items[nI];
        break;
      }
    }

    ProfileNameBox->Text = pProfile->ProfileName;
    SaveAdvancedOptionsCheck->Checked = pProfile->AdvancedOptionsUsed;

    LoadBtn->Enabled = true;
    DeleteBtn->Enabled = true;
  }
  else {
    LoadBtn->Enabled = false;
    DeleteBtn->Enabled = true;
  }
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::ProfileNameBoxChange(TObject *Sender)
{
  AddBtn->Enabled = (GetEditBoxTextLen(ProfileNameBox) != 0);
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::LoadBtnClick(TObject *Sender)
{
  for (int nI = 0; nI < ProfileList->Items->Count; nI++) {
    if (ProfileList->Selected[nI]) {
      MainForm->LoadProfile(nI);
      break;
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::DeleteBtnClick(TObject *Sender)
{
  if (ProfileList->SelCount == 0)
    return;

  if (ConfirmCheck->Checked &&
      MsgBox(TRLFormat("Are you sure you want to delete %d profile(s)?",
      ProfileList->SelCount), MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO)
    return;

  int nI = 0;
  int nLast = 0;

  while (nI < ProfileList->Items->Count) {
    if (ProfileList->Selected[nI]) {
      MainForm->DeleteProfile(nI);
      ProfileList->Items->Delete(nI);
      nI = nLast;
    }
    else
      nLast = ++nI;
  }

  ProfileListClick(this);
  m_blModified = true;
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::AddBtnClick(TObject *Sender)
{
  if (ProfileNameBox->GetTextLen() == 0)
    return;

  WString sProfileName = ProfileNameBox->Text;
  bool blSaveAdvancedOptions = SaveAdvancedOptionsCheck->Checked;
  int nFoundIdx = -1;

  for (int nI = 0; nI < g_pProfileList->Count; nI++) {
    if (WideSameText(sProfileName,
        ((PWGenProfile*) g_pProfileList->Items[nI])->ProfileName)) {
      nFoundIdx = nI;
      break;
    }
  }

  if (nFoundIdx < 0 && g_pProfileList->Count == PROFILES_MAX_NUM) {
    MsgBox(TRLFormat("Maximum number of profiles (%d) reached.\nPlease delete "
      "or overwrite profiles.", PROFILES_MAX_NUM),
      MB_ICONWARNING);
    return;
  }

  if (nFoundIdx >= 0) {
    if (ConfirmCheck->Checked &&
        MsgBox(TRLFormat("A profile with the name \"%s\" already exists.\n"
        "Do you want to overwrite it?",
        ((PWGenProfile*) g_pProfileList->Items[nFoundIdx])->ProfileName),
        MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) {
      ProfileNameBox->SetFocus();
      return;
    }
  }

  MainForm->CreateProfile(sProfileName, blSaveAdvancedOptions, nFoundIdx);

  if (blSaveAdvancedOptions)
    sProfileName += WString(" [+]");

  if (nFoundIdx < 0)
    ProfileList->Items->Add(sProfileName);
  else
    ProfileList->Items->Strings[nFoundIdx] = sProfileName;

  ProfileNameBox->Clear();
  ProfileNameBox->SetFocus();
  m_blModified = true;
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::ProfileNameBoxKeyPress(TObject *Sender,
      char &Key)
{
  if (Key == VK_RETURN) {
    AddBtnClick(this);
    Key = 0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::FormActivate(TObject *Sender)
{
  ProfileNameBox->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::ProfileListDblClick(TObject *Sender)
{
  LoadBtn->Click();
}
//---------------------------------------------------------------------------
void __fastcall TProfileEditDlg::TntFormShow(TObject *Sender)
{
  Top = MainForm->Top + (MainForm->Height - Height) / 2;
  Left = MainForm->Left + (MainForm->Width - Width) / 2;
  TopMostManager::GetInstance()->SetForm(this);
}
//---------------------------------------------------------------------------

