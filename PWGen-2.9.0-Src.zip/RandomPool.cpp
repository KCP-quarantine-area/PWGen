// RandomPool.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "RandomPool.h"
#include "CryptUtil.h"
#include "TntSysUtils.hpp"
#include "hrtimer.h"
#include "FastPRNG.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

//RandomPool* g_pRandPool = NULL;

// sizeof(aes_context) = 280 bytes
// sizeof(sha256_context) = 236 bytes

static const int
  POOLPAGE_SIZE    = 4096, // size of the entire pool page in RAM
  KEY_SIZE         = 32, // AES key size used
  BLOCK_SIZE       = 16, // AES block size
  ADDBUF_SIZE      = 556, // size of add buffer
                          // (size optimized for minimal padding in SHA-2)
  GETBUF_SIZE      = 64, // size of get buffer
  TEMPBUF_SIZE     = BLOCK_SIZE, // size of temporary buffer
  POOL_OFFSET      = 0,
  HASHCTX_OFFSET   = POOL_OFFSET + RandomPool::POOL_SIZE,
  ADDBUF_OFFSET    = HASHCTX_OFFSET + sizeof(sha256_context),
  CIPHERKEY_OFFSET = ADDBUF_OFFSET + ADDBUF_SIZE,
  SECCTR_OFFSET    = CIPHERKEY_OFFSET + KEY_SIZE,
  CIPHERCTX_OFFSET = SECCTR_OFFSET + BLOCK_SIZE,
  GETBUF_OFFSET    = CIPHERCTX_OFFSET + sizeof(aes_context),
  TEMPBUF_OFFSET   = GETBUF_OFFSET + GETBUF_SIZE,
  UNUSED_SIZE_MAX  = POOLPAGE_SIZE - (TEMPBUF_OFFSET + TEMPBUF_SIZE),
  UNUSED_SIZE_MIN  = 64;

// fill buffer in pool page with random data
#define clearPoolBuf(pMem, lSize) fprng_fillbuf(pMem, lSize)


//---------------------------------------------------------------------------
RandomPool::RandomPool()
  : m_lAddBufPos(0), m_lGetBufPos(0), m_blKeySet(false), m_blCryptProv(false)
{
  m_pPoolPage = AllocPoolPage();
  if (m_pPoolPage == NULL)
    OutOfMemoryError();

  // hide the pool contents *somewhere* within the memory page
  m_lUnusedSize = UNUSED_SIZE_MIN + fprng_rand() % (UNUSED_SIZE_MAX - UNUSED_SIZE_MIN + 1);
  SetPoolPointers();

  if (CryptAcquireContext(&m_cryptProv, NULL, NULL, PROV_RSA_FULL, 0))
    m_blCryptProv = true;
  else if (signed(GetLastError()) == NTE_BAD_KEYSET)
    m_blCryptProv = CryptAcquireContext(
      &m_cryptProv, NULL, NULL, PROV_RSA_FULL, CRYPT_NEWKEYSET);
}
//---------------------------------------------------------------------------
RandomPool::~RandomPool()
{
  FreePoolPage();
  m_pPoolPage = NULL;
  m_pPool = NULL;
  m_pHashCtx = NULL;
  m_pAddBuf = NULL;
  m_pCipherKey = NULL;
  m_pSecCtr = NULL;
  m_pCipherCtx = NULL;
  m_pGetBuf = NULL;
  m_pTempBuf = NULL;
  m_lUnusedSize = 0;
}
//---------------------------------------------------------------------------
RandomPool* RandomPool::GetInstance(void)
{
  static RandomPool inst;
  return &inst;
}
//---------------------------------------------------------------------------
word8* RandomPool::AllocPoolPage(void)
{
  word8* pPoolPage =
    (word8*) VirtualAlloc(NULL, POOLPAGE_SIZE, MEM_COMMIT, PAGE_READWRITE);
  if (pPoolPage != NULL) {
    VirtualLock(pPoolPage, POOLPAGE_SIZE);
    clearPoolBuf(pPoolPage, POOLPAGE_SIZE);
  }
  return pPoolPage;
}
//---------------------------------------------------------------------------
void RandomPool::FreePoolPage(void)
{
  if (m_pPoolPage != NULL) {
    clearPoolBuf(m_pPoolPage, POOLPAGE_SIZE);
    VirtualUnlock(m_pPoolPage, POOLPAGE_SIZE);
    VirtualFree(m_pPoolPage, 0, MEM_RELEASE);
  }
}
//---------------------------------------------------------------------------
void RandomPool::SetPoolPointers(void)
{
  m_pPool      = m_pPoolPage + m_lUnusedSize + POOL_OFFSET;
  m_pHashCtx   = (sha256_context*) (m_pPoolPage + m_lUnusedSize + HASHCTX_OFFSET);
  m_pAddBuf    = m_pPoolPage + m_lUnusedSize + ADDBUF_OFFSET;
  m_pCipherKey = m_pPoolPage + m_lUnusedSize + CIPHERKEY_OFFSET;
  m_pSecCtr    = m_pPoolPage + m_lUnusedSize + SECCTR_OFFSET;
  m_pCipherCtx = (aes_context*) (m_pPoolPage + m_lUnusedSize + CIPHERCTX_OFFSET);
  m_pGetBuf    = m_pPoolPage + m_lUnusedSize + GETBUF_OFFSET;
  m_pTempBuf   = m_pPoolPage + m_lUnusedSize + TEMPBUF_OFFSET;
}
//---------------------------------------------------------------------------
void RandomPool::TouchPool(void)
{
  static word32 lIndex = 0;

  if (lIndex == m_lUnusedSize)
    lIndex = 0;
  m_pPoolPage[lIndex++]--;
}
//---------------------------------------------------------------------------
bool RandomPool::MovePool(void)
{
  word8* pNewPoolPage = AllocPoolPage();
  if (pNewPoolPage == NULL)
    return false;

  // only copy the relevant portion of the pool page
  memcpy(pNewPoolPage + m_lUnusedSize, m_pPoolPage + m_lUnusedSize,
    POOLPAGE_SIZE - m_lUnusedSize);

  FreePoolPage();
  m_pPoolPage = pNewPoolPage;
  pNewPoolPage = NULL;
  SetPoolPointers();

  // IMPORTANT: The AES context contains a pointer to its
  // internal key buffer. We have to change this pointer to
  // the new address to avoid an access violation!!
  if (m_blKeySet)
    m_pCipherCtx->rk = m_pCipherCtx->buf;

  return true;
}
//---------------------------------------------------------------------------
void RandomPool::UpdatePool(void)
{
  // update the pool by hashing the pool, the add buffer and a time-stamp
  sha256_hmac_starts(m_pHashCtx, m_pPool, POOL_SIZE, 0);

  if (m_lAddBufPos != 0) {
    sha256_hmac_update(m_pHashCtx, m_pAddBuf, m_lAddBufPos);
    clearPoolBuf(m_pAddBuf, m_lAddBufPos);
    m_lAddBufPos = 0;
  }

  if (m_blKeySet) {
    // the counter has accumulated some entropy, which we should incorporate
    // into the pool now
    sha256_hmac_update(m_pHashCtx, m_pSecCtr, BLOCK_SIZE);
  }

  // ALWAYS add some entropy (independent of the add buffer)
  HighResTimer(m_pTempBuf);
  sha256_hmac_update(m_pHashCtx, m_pTempBuf, sizeof(word64));

  // get new pool
  sha256_hmac_finish(m_pHashCtx, m_pPool);

  // clear sensitive data
  clearPoolBuf(m_pHashCtx, sizeof(sha256_context));
  clearPoolBuf(m_pTempBuf, sizeof(word64));

  if (m_blKeySet) {
    // destroy sensitive data used for generating random numbers
    clearPoolBuf(m_pSecCtr, BLOCK_SIZE);
    clearPoolBuf(m_pCipherCtx, sizeof(aes_context));
    clearPoolBuf(m_pGetBuf, GETBUF_SIZE);
    m_lGetBufPos = 0;
    m_blKeySet = false;
  }
}
//---------------------------------------------------------------------------
void RandomPool::SetKey(void)
{
  // always update the pool before generating a new key
  UpdatePool();

  // don't use the pool directly as a key, but derive a new key from the pool
  // using a time stamp as a "key" for HMAC-SHA-256
  HighResTimer(m_pTempBuf);
  sha256_hmac_starts(m_pHashCtx, m_pTempBuf, TEMPBUF_SIZE, 0); // we simply use
    // the full buffer contents here instead of only 8 bytes; it doesn't cost
    // anything, and the rest of the buffer contains some useful pseudorandom data
  sha256_hmac_update(m_pHashCtx, m_pPool, POOL_SIZE);
  sha256_hmac_finish(m_pHashCtx, m_pCipherKey);

  clearPoolBuf(m_pTempBuf, TEMPBUF_SIZE);

  // perform the AES key setup
  aes_setkey_enc(m_pCipherCtx, m_pCipherKey, KEY_SIZE*8);

  // destroy the key
  clearPoolBuf(m_pCipherKey, KEY_SIZE);

  // is it necessary to update the pool again to ensure that the pool contents
  // can't be derived from the AES key and vice versa...?
  // The AES key has been derived from the pool AND a time stamp, which should
  // provide sufficient protection against key recovery from the pool
  // ... so the answer is "no" (for the moment)
//  UpdatePool();

  GetNewCounter(m_pSecCtr);

  m_lGetBufPos = GETBUF_SIZE; // get buffer is yet to be filled
  m_blKeySet = true;
}
//---------------------------------------------------------------------------
void RandomPool::GetNewCounter(word8* pCounter)
{
  // get a new counter by encrypting timer values
  HighResTimer(pCounter);
  GetSystemTimeAsFileTime((FILETIME*) (pCounter+8));
  aes_crypt_ecb(m_pCipherCtx, AES_ENCRYPT, pCounter, pCounter);
}
//---------------------------------------------------------------------------
void RandomPool::GeneratorGate(void)
{
  // get a new key from the output of AES-CTR
  FillBuf(m_pCipherKey, KEY_SIZE);

  // set key and destroy it
  aes_setkey_enc(m_pCipherCtx, m_pCipherKey, KEY_SIZE*8);
  clearPoolBuf(m_pCipherKey, KEY_SIZE);

  // get an encrypted timestamp using AES with the new key
  GetNewCounter(m_pTempBuf);

  // xor the old counter with the encrypted timestamp
  for (int nI = 0; nI < BLOCK_SIZE; nI++)
    m_pSecCtr[nI] ^= m_pTempBuf[nI];

  clearPoolBuf(m_pTempBuf, BLOCK_SIZE);

  // encrypt the xor'ed counter
  aes_crypt_ecb(m_pCipherCtx, AES_ENCRYPT, m_pSecCtr, m_pSecCtr);
}
//---------------------------------------------------------------------------
word32 RandomPool::FillBuf(word8* pBuf,
                           word32 lNumOfBytes)
{
  bool blGetBuf = pBuf == NULL;

  if (blGetBuf) {
    pBuf = m_pGetBuf;
    lNumOfBytes = GETBUF_SIZE;
  }

  // fill the buffer by encrypting multiple counter values
  word32 lBytesGen = 0, lNumOfBlocks = 0;
  while (lNumOfBytes >= BLOCK_SIZE) {
    aes_crypt_ecb(m_pCipherCtx, AES_ENCRYPT, m_pSecCtr, pBuf);
    incrementCounter128(m_pSecCtr);

    pBuf += BLOCK_SIZE;
    lBytesGen += BLOCK_SIZE;
    lNumOfBytes -= BLOCK_SIZE;

    if (++lNumOfBlocks == MAX_BLOCKS) {
      GeneratorGate();
      lNumOfBlocks = 0;
    }
  }

  if (blGetBuf) {
    GeneratorGate();
    m_lGetBufPos = 0;
  }

  return lBytesGen;
}
//---------------------------------------------------------------------------
void RandomPool::AddData(const void* pBuf,
                         word32 lNumOfBytes)
{
  const word8* pSrcBuf = (word8*) pBuf;

  while (lNumOfBytes-- != 0) {
    if (m_lAddBufPos == ADDBUF_SIZE)
      UpdatePool();

    m_pAddBuf[m_lAddBufPos++] ^= *pSrcBuf++;
  }
}
//---------------------------------------------------------------------------
void RandomPool::GetData(void* pBuf,
                         word32 lNumOfBytes)
{
  if (!m_blKeySet)
    SetKey();

  word8* pDestBuf = (word8*) pBuf;
  bool blGetBufFilled = false;

  while (lNumOfBytes != 0) {
    if (m_lGetBufPos == GETBUF_SIZE) {
      if (lNumOfBytes >= GETBUF_SIZE) {
        // fill the buffer directly without using memcpy()
        word32 lBytesGen = FillBuf(pDestBuf, lNumOfBytes);

        // already finished?
        if (lBytesGen == lNumOfBytes) {
          // perform generator gate before leaving
          GeneratorGate();

          // destroy old random data and say goodbye
          if (blGetBufFilled)
            clearPoolBuf(m_pGetBuf, GETBUF_SIZE);

          return;
        }

        pDestBuf += lBytesGen;
        lNumOfBytes -= lBytesGen;
      }

      // refill get buffer
      FillBuf();
    }

    word32 lToCopy = std::min(lNumOfBytes, GETBUF_SIZE - m_lGetBufPos);
    memcpy(pDestBuf, m_pGetBuf + m_lGetBufPos, lToCopy);

    pDestBuf += lToCopy;
    m_lGetBufPos += lToCopy;
    lNumOfBytes -= lToCopy;

    blGetBufFilled = true;
  }
}
//---------------------------------------------------------------------------
word8 RandomPool::GetByte(void)
{
  if (!m_blKeySet)
    SetKey();

  if (m_lGetBufPos == GETBUF_SIZE)
    FillBuf();

  return m_pGetBuf[m_lGetBufPos++];
}
//---------------------------------------------------------------------------
void RandomPool::Randomize(void)
{
  // the following code is based on Random.cpp from Sami Tolvanen's "Eraser"
  // and rndw32.c from "libgcrypt"
#define addEntropy(source, size)  AddData(source, size)
#define addEntropyValue(value) \
                lEntropyValue = word32(value); \
                addEntropy(&lEntropyValue, sizeof(lEntropyValue))

  static bool blFixedItemsAdded = false;
  word32 lEntropyValue;

  word64 qTimer;
  HighResTimer(&qTimer);
  addEntropy(&qTimer, sizeof(word64));

  FILETIME ft;
  GetSystemTimeAsFileTime(&ft);
  addEntropy(&ft, sizeof(FILETIME));

  __int64 qFreeSpace;
  qFreeSpace = DiskFree(0); // 0 = current drive
  if (qFreeSpace != -1)
    addEntropy(&qFreeSpace, sizeof(__int64));

  POINT pt;
  GetCaretPos(&pt);
  addEntropy(&pt, sizeof(POINT));
  GetCursorPos(&pt);
  addEntropy(&pt, sizeof(POINT));

  MEMORYSTATUS ms;
  ms.dwLength = sizeof(MEMORYSTATUS);
  GlobalMemoryStatus(&ms);
  addEntropy(&ms, sizeof(MEMORYSTATUS));

  addEntropyValue(GetActiveWindow());
  addEntropyValue(GetCapture());
  addEntropyValue(GetClipboardOwner());
  addEntropyValue(GetClipboardViewer());
  addEntropyValue(GetCurrentProcess());
  addEntropyValue(GetCurrentProcessId());
  addEntropyValue(GetCurrentThread());
  addEntropyValue(GetCurrentThreadId());
  addEntropyValue(GetDesktopWindow());
  addEntropyValue(GetFocus());
  addEntropyValue(GetForegroundWindow());
  addEntropyValue(GetInputState());
  addEntropyValue(GetMessagePos());
  addEntropyValue(GetMessageTime());
  addEntropyValue(GetOpenClipboardWindow());
  addEntropyValue(GetProcessHeap());
  addEntropyValue(GetProcessWindowStation());
  addEntropyValue(GetQueueStatus(QS_ALLEVENTS));
  addEntropyValue(GetTickCount());

  // these exist on NT
  FILETIME ftCreationTime;
  FILETIME ftExitTime;
  FILETIME ftKernelTime;
  FILETIME ftUserTime;
  ULARGE_INTEGER uSpace;
  if (GetThreadTimes(GetCurrentThread(), &ftCreationTime, &ftExitTime,
           &ftKernelTime, &ftUserTime)) {
       addEntropy(&ftCreationTime, sizeof(FILETIME));
       addEntropy(&ftExitTime,     sizeof(FILETIME));
       addEntropy(&ftKernelTime,   sizeof(FILETIME));
       addEntropy(&ftUserTime,     sizeof(FILETIME));
  }
  if (GetProcessTimes(GetCurrentProcess(), &ftCreationTime, &ftExitTime,
          &ftKernelTime, &ftUserTime)) {
      addEntropy(&ftCreationTime, sizeof(FILETIME));
      addEntropy(&ftExitTime,     sizeof(FILETIME));
      addEntropy(&ftKernelTime,   sizeof(FILETIME));
      addEntropy(&ftUserTime,     sizeof(FILETIME));
  }
  if (GetProcessWorkingSetSize(GetCurrentProcess(), &uSpace.LowPart,
          &uSpace.HighPart)) {
      addEntropy(&uSpace, sizeof(ULARGE_INTEGER));
  }

  if (!blFixedItemsAdded) {
    STARTUPINFO startupInfo;
    TIME_ZONE_INFORMATION tzi;
    SYSTEM_INFO systemInfo;
    OSVERSIONINFO versionInfo;

    addEntropyValue(GetUserDefaultLangID());
    addEntropyValue(GetUserDefaultLCID());

    // desktop geometry and colours
    addEntropyValue(GetSystemMetrics(SM_CXSCREEN));
    addEntropyValue(GetSystemMetrics(SM_CYSCREEN));
    addEntropyValue(GetSystemMetrics(SM_CXHSCROLL));
    addEntropyValue(GetSystemMetrics(SM_CYHSCROLL));
    addEntropyValue(GetSystemMetrics(SM_CXMAXIMIZED));
    addEntropyValue(GetSystemMetrics(SM_CYMAXIMIZED));
    addEntropyValue(GetSysColor(COLOR_3DFACE));
    addEntropyValue(GetSysColor(COLOR_DESKTOP));
    addEntropyValue(GetSysColor(COLOR_INFOBK));
    addEntropyValue(GetSysColor(COLOR_WINDOW));
    addEntropyValue(GetDialogBaseUnits());

    // System information
    if (GetTimeZoneInformation(&tzi) != TIME_ZONE_ID_INVALID) {
        addEntropy(&tzi, sizeof(TIME_ZONE_INFORMATION));
    }
    addEntropyValue(GetSystemDefaultLangID());
    addEntropyValue(GetSystemDefaultLCID());
    addEntropyValue(GetOEMCP());
    addEntropyValue(GetACP());
    addEntropyValue(GetKeyboardLayout(0));
    addEntropyValue(GetKeyboardType(0));
    addEntropyValue(GetKeyboardType(1));
    addEntropyValue(GetKeyboardType(2));
    addEntropyValue(GetDoubleClickTime());
    addEntropyValue(GetCaretBlinkTime());
    addEntropyValue(GetLogicalDrives());

    versionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    if (GetVersionEx(&versionInfo)) {
        addEntropy(&versionInfo, sizeof(OSVERSIONINFO));
    }

    GetSystemInfo(&systemInfo);
    addEntropy(&systemInfo, sizeof(SYSTEM_INFO));

    // Process startup info
    startupInfo.cb = sizeof(STARTUPINFO);
    GetStartupInfo(&startupInfo);
    addEntropy(&startupInfo, sizeof(STARTUPINFO));

    memzero(&startupInfo, sizeof(STARTUPINFO));
    memzero(&tzi,         sizeof(TIME_ZONE_INFORMATION));
    memzero(&systemInfo,  sizeof(SYSTEM_INFO));
    memzero(&versionInfo, sizeof(OSVERSIONINFO));

    blFixedItemsAdded = true;
  }

  // get some random data from the Windows API...
  SecureMem<word8> mswinRand(POOL_SIZE);
  if (m_blCryptProv &&
      CryptGenRandom(m_cryptProv, POOL_SIZE, mswinRand))
    addEntropy(mswinRand, POOL_SIZE);

  // finally, add Windows' QPC high-resolution counter
  // (not necessarily identical to the RDTSC value)
  LARGE_INTEGER qpc;
  if (QueryPerformanceCounter(&qpc))
    addEntropy(&qpc, sizeof(LARGE_INTEGER));

  // the notorious cleanup ...
  memzero(&qTimer,         sizeof(word64));
  memzero(&ft,             sizeof(FILETIME));
  memzero(&qFreeSpace,     sizeof(word64));
  memzero(&pt,             sizeof(POINT));
  memzero(&ms,             sizeof(MEMORYSTATUS));
  memzero(&ftCreationTime, sizeof(FILETIME));
  memzero(&ftExitTime,     sizeof(FILETIME));
  memzero(&ftKernelTime,   sizeof(FILETIME));
  memzero(&ftUserTime,     sizeof(FILETIME));
  memzero(&uSpace,         sizeof(ULARGE_INTEGER));
  memzero(&qpc,            sizeof(LARGE_INTEGER));
  memzero(&lEntropyValue,  sizeof(word32));
}
//---------------------------------------------------------------------------
bool RandomPool::WriteSeedFile(const WString& sFileName)
{
  // use the Windows API directly here, because we want to overwrite the
  // data in the random seed file (if it exists)
  HANDLE hFile;

  if (Win32PlatformIsUnicode)
    hFile = CreateFileW(sFileName.c_bstr(), GENERIC_WRITE, 0, NULL,
      OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, NULL);
  else {
    AnsiString asFileName = sFileName;
    hFile = CreateFileA(asFileName.c_str(), GENERIC_WRITE, 0, NULL,
      OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, NULL);
  }

  if (hFile == INVALID_HANDLE_VALUE)
    return false;

  // initialize the PRNG
  SetKey();

  // get enough entropy and flush the pool afterwards
  SecureMem<word8> buf(POOL_SIZE);
  FillBuf(buf, POOL_SIZE);
  Flush();

  // write the data to the file
  DWORD dwBytesWritten;
  bool blSuccess = WriteFile(hFile, buf, POOL_SIZE, &dwBytesWritten, NULL);

  CloseHandle(hFile);

  return blSuccess && dwBytesWritten == POOL_SIZE;
}
//---------------------------------------------------------------------------
bool RandomPool::ReadSeedFile(const WString& sFileName)
{
  HANDLE hFile;

  if (Win32PlatformIsUnicode)
    hFile = CreateFileW(sFileName.c_bstr(), GENERIC_READ, 0, NULL,
      OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  else {
    AnsiString asFileName = sFileName;
    hFile = CreateFileA(asFileName.c_str(), GENERIC_READ, 0, NULL,
      OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  }

  if (hFile == INVALID_HANDLE_VALUE)
    return false;

  SecureMem<word8> buf(POOL_SIZE);

  DWORD dwBytesRead;
  bool blSuccess = ReadFile(hFile, buf, POOL_SIZE, &dwBytesRead, NULL);

  if (blSuccess && dwBytesRead != 0)
    AddData(buf, dwBytesRead);

  CloseHandle(hFile);

  return blSuccess && dwBytesRead == POOL_SIZE;
}
//---------------------------------------------------------------------------
