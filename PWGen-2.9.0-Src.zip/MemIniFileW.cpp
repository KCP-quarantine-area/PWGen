// MemIniFileW.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#include <TntSysUtils.hpp>
#pragma hdrstop

#include "MemIniFileW.h"
#include "StringFileStreamW.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)


//---------------------------------------------------------------------------
__fastcall TMemIniFileW::TMemIniFileW(const WString& sFileName)
  : TMemIniFile(""), m_sFileName(sFileName)
{
  if (WideFileExists(sFileName)) {
    std::auto_ptr<TTntFileStream> pFile(new TStringFileStreamW(m_sFileName, fmOpenRead));
    std::auto_ptr<TStringList> pList(new TStringList);
    pList->LoadFromStream(pFile.get());
    SetStrings(pList.get());
  }
}
//---------------------------------------------------------------------------
void __fastcall TMemIniFileW::UpdateFile(void)
{
  std::auto_ptr<TStringList> pList(new TStringList);
  GetStrings(pList.get());
  std::auto_ptr<TTntFileStream> pFile(new TStringFileStreamW(m_sFileName, fmCreate, ceUtf8));
  pList->SaveToStream(pFile.get());
}
//---------------------------------------------------------------------------

