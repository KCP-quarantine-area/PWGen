// FastPRNG.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "FastPRNG.h"
#include "SecureMem.h"
#include "sha256.h"
#include "aes.h"
#include "hrtimer.h"
#include "MemUtil.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)


// Implementation of the IA (Indirection, Addition) random number generator
// by R.J. Jenkins.
// It can be considered as a "predecessor" of the cryptographically secure
// generator ISAAC:
// http://burtleburtle.net/bob/rand/isaac.html
// IA is inspired by RC4, but seems to be faster (since operating on 32-bit
// words instead of 8-bit bytes as in RC4) and more secure, although
// its output is, like RC4, to a certain degree biased, according to Jenkins.
// The bias can be detected in the correlated gap test.
// Nevertheless, IA seems to be an excellent choice for the purpose of a
// fast PRNG here, because it is very simple and additionally offers a
// certain degree of security against state recovery attacks (unlike other
// popular PRNGs).

// Note that we do NOT expect this generator to have cryptographic security,
// and PWGen does NOT rely on its security in critical situations (i.e., when
// generating random numbers for passwords).
// But a certain degree of security is certainly nice to protect the random
// pool from being located in RAM.

static word32 m[256];
static word32 x; // x and y are temporarily assigned to values in m
static word32 y;
static word32 r; // output 32-bit random number
static word8 c;  // 8-bit counter (0..255) for indexing m

#define NEXT_RAND x=m[c]; m[c]=y=m[x&0xFF]+r; r=m[(y>>8)&0xFF]+x; c++

//---------------------------------------------------------------------------
void fprng_randomize(void)
{
  // we have to ensure that the m array is filled with good pseudorandom data;
  // otherwise, we can't really expect good results...
  // first, hash some timers to generate a nice 128-bit key & IV
  sha256_context hashCtx;

  sha256_starts(&hashCtx, 0);

  word64 qTimer;
  HighResTimer(&qTimer);
  sha256_update(&hashCtx, (word8*) &qTimer, sizeof(word64));

  FILETIME ft;
  GetSystemTimeAsFileTime(&ft);
  sha256_update(&hashCtx, (word8*) &ft, sizeof(FILETIME));

  word32 lCounter = GetTickCount();
  sha256_update(&hashCtx, (word8*) &lCounter, sizeof(word32));

  LARGE_INTEGER qpc;
  if (QueryPerformanceCounter(&qpc))
    sha256_update(&hashCtx, (word8*) &qpc, sizeof(LARGE_INTEGER));

  SecureMem<word8> hash(32);
  sha256_finish(&hashCtx, hash);

  // use one half of the hash as 128-bit key for AES
  aes_context cryptCtx;
  aes_setkey_enc(&cryptCtx, hash, 128);

  // use the other half as the IV for CBC mode
  word8* pIV = hash + 16;

  // generate random data by using AES in CBC mode
  aes_crypt_cbc(&cryptCtx, AES_ENCRYPT, sizeof(m), pIV, (word8*) m, (word8*) m);

  // initialize the counter c
  c = 0;

  // clean up...
  memzero(&hashCtx,  sizeof(sha256_context));
  memzero(&qTimer,   sizeof(word64));
  memzero(&ft,       sizeof(FILETIME));
  memzero(&lCounter, sizeof(word32));
  memzero(&qpc,      sizeof(LARGE_INTEGER));
  memzero(&cryptCtx, sizeof(aes_context));
}
//---------------------------------------------------------------------------
word32 fprng_rand(void)
{
  NEXT_RAND;

  return r;
}
//---------------------------------------------------------------------------
void fprng_fillbuf(void* pMem,
                   word32 lSize)
{
  word32* pBuf = (word32*) pMem;

  for ( ; lSize >= sizeof(word32); lSize -= sizeof(word32)) {
    NEXT_RAND;
    *pBuf++ = r;
  }

  if (lSize != 0) {
    word32 lRand = fprng_rand();
    memcpy(pBuf, &lRand, lSize);
  }
}
//---------------------------------------------------------------------------
void fprng_reset(void)
{
  memzero(m, sizeof(m));
  x = y = r = 0;
  c = 0;
}
//---------------------------------------------------------------------------
