// Main.cpp
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#include <vcl.h>
#include <clipbrd.hpp>
#include <Math.hpp>
#include <DateUtils.hpp>
#include <stdio.h>
#include <shellapi.h>
#include <algorithm>
#include <set>
#pragma hdrstop

#include "Main.h"
#include "TntSystem.hpp"
#include "ProgramDef.h"
#include "StringFileStreamW.h"
#include "EntropyManager.h"
#include "Language.h"
#include "hrtimer.h"
#include "MemIniFileW.h"
#include "PasswList.h"
#include "CryptText.h"
#include "Util.h"
#include "PasswEnter.h"
#include "base64.h"
#include "Callback.h"
#include "About.h"
#include "CreateRandDataFile.h"
#include "QuickHelp.h"
#include "FastPRNG.h"
#include "ProfileEditor.h"
#include "CreateTrigramFile.h"
#include "MPPasswGen.h"
#include "Configuration.h"
#include "ProvideEntropy.h"
#include "dragdrop.h"
#include "TopMostManager.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CGAUGES"
#pragma link "TntButtons"
#pragma link "TntComCtrls"
#pragma link "TntDialogs"
#pragma link "TntExtCtrls"
#pragma link "TntMenus"
#pragma link "TntStdCtrls"
#pragma resource "*.dfm"
#pragma resource "PWGen.manifest.res"
TMainForm *MainForm;

std::auto_ptr<TMemIniFileW> g_pIni;
std::auto_ptr<TList> g_pProfileList;
RandomGenerator* g_pRandSrc = NULL;
std::auto_ptr<RandomGenerator> g_pKeySeededPRNG;
WString g_sExePath;
CharacterEncoding g_fileEncoding = ceAnsi;
WString g_sAppDataPath;
int g_nAppState = 0;

extern HANDLE g_hAppMutex;

static const AnsiString
  CONFIG_ID             = "Main",
  CONFIG_PROFILE_ID     = "PWGenProfile";

static const int
  ENTROPY_TIMER_MAX     = 8,
  ENTROPY_SYSTEM        = 24,
  ENTROPY_MOUSECLICK    = 2,
  ENTROPY_MOUSEMOVE     = 2,
  ENTROPY_MOUSEWHEEL    = 0,
  ENTROPY_KEYBOARD      = 1,

  LANGUAGE_MAX_ITEMS    = 32,

  TIMER_TOUCHPOOL       = 2,
  TIMER_RANDOMIZE       = 10,
  TIMER_MOVEPOOL        = 300,
  TIMER_WRITESEEDFILE   = 457,
        // the prime 457 was chosen so that there is a sufficient delay
        // between moving the pool and writing a new seed file, and that
        // both events will coincide quite late (after ~38 hours)

  PASSW_MAX_NUM         = 2000000000,
  PASSW_MAX_CHARS       = 10000,
  PASSW_MAX_WORDS       = 100,
  PASSWFORMAT_MAX_CHARS = 16000,
  PASSWLIST_MAX_BYTES   = 500000000,

  LISTS_MAX_ENTRIES     = 50;


static const int CHARSETLIST_DEFAULTENTRIES_NUM = 9;
static const char* CHARSETLIST_DEFAULTENTRIES[CHARSETLIST_DEFAULTENTRIES_NUM] =
        { "<AZ><az><09>",
          "<AZ><az><09><symbols>",
          "<AZ><az><09><symbols><high>",
          "<easytoread>",
          "<Hex>",
          "<hex>",
          "<base64>",
          "<phonetic>",
          "<phoneticx>" };

static const int FORMATLIST_DEFAULTENTRIES_NUM = 10;
static const char* FORMATLIST_DEFAULTENTRIES[FORMATLIST_DEFAULTENTRIES_NUM] =
        { "%{%4u%4l%2d%s%}",
          "%{%6A%L%d%}",
          "%3[%8q %]",
          "%*d",
          "%*10-20A",
          "%6q%2d%s%6q%2d%s",
          "%5[%w-%2d %]",
          "%U%9A",
          "%32h",
          "%5[%2h-%]%2h"
        };

static const char WLFNLIST_DEFAULT[] = "<default>";

static const char PASSWORD_CHAR = '*';

static const wchar_t
  CMDLINE_INI[]      = L"ini=",
  CMDLINE_READONLY[] = L"readonly";

static const char
  PROFILES_MENU_SHORTCUTS[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

static const int MAINFORM_TAG_DISABLETRAYPOPUP  = 1,
                 MAINFORM_TAG_REPAINTCOMBOBOXES = 2,

                 PASSWBOX_TAG_PASSWTEST = 1;


static int stringToPasswOptions(const AnsiString& asSrc,
                                const AnsiString& asVersion)
{
  static int nVerLT250 = -1, nVerLT220 = 0;

  if (asSrc.IsEmpty())
    return 0;

  if (nVerLT250 < 0) {
     if ((nVerLT250 = CompareVersions(asVersion, "2.5.0") < 0))
       nVerLT220 = CompareVersions(asVersion, "2.2.0") < 0;
  }

  const char* pszSrc = asSrc.c_str();
  int nSrcLen = asSrc.Length();

  int nFlags = 0;
  for (int nI = 0, nJ = 0; nI < nSrcLen && nJ < PASSWOPTIONS_NUM; nJ++) {
    if ((nVerLT220 && nJ == 4) || (nVerLT250 && nJ == 9))
      continue;
    nFlags |= (pszSrc[nI++] - '0') ? 1 << nJ : 0;
  }

  return nFlags;
}


//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TTntForm(Owner), m_pRandPool(RandomPool::GetInstance()),
          m_blStartup(true), m_blHotKeySet(false), m_blRestart(false),
          m_blConfigReadOnly(false), m_nNumStartupErrors(0), m_passwGen(NULL),
          m_nAutoClearClipCnt(0), m_pUpdCheckThread(NULL)
{
//  SetSecureMemoryManager();

  Application->OnMessage = AppMessage;
  Application->OnException = AppException;
  Application->OnMinimize = AppMinimize;
  Application->OnRestore = AppRestore;
  Application->OnDeactivate = AppDeactivate;

  Application->Title = PROGRAM_NAME;
  Caption = PROGRAM_NAME;

  Constraints->MinHeight = Height;
  Constraints->MinWidth = Width;

  // test crypto modules before further initializing...
  if (aes_self_test(0) != 0)
    throw Exception("AES self test failed.");
  if (sha256_self_test(0) != 0)
    throw Exception("SHA-256 self test failed.");
  if (base64_self_test(0) != 0)
    throw Exception("Base64 self test failed.");

  OSVERSIONINFO osvi;
  osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  GetVersionEx(&osvi);

  // set up PRNGs and related stuff
  HighResTimerCheck(osvi.dwMajorVersion >= 5);
  fprng_reset();
  fprng_randomize();
  //g_pRandPool = new RandomPool;
  m_passwGen.RandGen = m_pRandPool;
  g_pRandSrc = m_pRandPool;
  g_pEntropyMng.reset(new EntropyManager(ENTROPY_TIMER_MAX, ENTROPY_SYSTEM));
  g_pProfileList.reset(new TList);
  g_pEntropyMng->AddSystemEntropy();

  // initialize the OLE library
  OleInitialize(NULL);

  RegisterDropWindow(PasswBox->Handle, Win32PlatformIsUnicode, &m_pPasswBoxDropTarget);

  // set up basic appearance of the program
  WString sLogo = PROGRAM_NAME;
  if (Win32PlatformIsUnicode) {
    sLogo[2] = L'\x3a8';
    sLogo[4] = L'\x3b5';
//    sLogo[5] = L'\x3b7';
  }
  LogoLbl->Caption = sLogo + WString(" ") + WString(PROGRAM_VERSION[0]);
  MainMenu_Options_Language_English->Hint = PROGRAM_VERSION;
//  Logo->Picture->Assign(Application->Icon);
  Logo->Top = (ToolBar->Height - Logo->Picture->Height) / 2;

  EntropyProgress->MaxValue = RandomPool::MAX_ENTROPY;
  CharsLengthSpinBtn->Max = PASSW_MAX_CHARS;
  WordsNumSpinBtn->Max = PASSW_MAX_WORDS;

  g_sExePath = WideExtractFilePath(TntApplication->ExeName);

  WString sIniFileName = g_sExePath + WString(PROGRAM_INIFILE);
  bool blCustomIniFile = false;

  // evaluate command line parameters
  WString sUnknownSwitches;
  int nI;
  for (nI = 1; nI <= WideParamCount(); nI++) {
    WString sParam = WideParamStr(nI);
    int nParamLen = sParam.Length();
    int nParamStart = 2;

    if (nParamLen < 2 || (sParam[1] != '/' && sParam[1] != '-'))
      continue;
    if (sParam[2] == '-') {
      if (nParamLen < 3)
        continue;
      nParamStart++;
    }

    int nSwitchLen = wcslen(CMDLINE_INI);
    if (nParamLen - nParamStart > nSwitchLen &&
        _wcsnicmp(&sParam[nParamStart], CMDLINE_INI, nSwitchLen) == 0) {
      sIniFileName = sParam.SubString(nParamStart + nSwitchLen,
        nParamLen - nParamStart - nSwitchLen + 1);
      if (WideExtractFilePath(sIniFileName).IsEmpty())
        sIniFileName = g_sExePath + sIniFileName;
      blCustomIniFile = true;
    }
    else if (_wcsicmp(&sParam[nParamStart], CMDLINE_READONLY) == 0)
      m_blConfigReadOnly = true;
    else
      sUnknownSwitches += WString("\"") + sParam + WString("\"; ");
  }

  // load the configuration file
  g_pIni.reset(new TMemIniFileW(sIniFileName));

  if (!blCustomIniFile && g_pIni->ReadBool(CONFIG_ID, "UseAppDataPath", false) &&
      !(g_sAppDataPath = GetAppDataPath()).IsEmpty()) {
    g_sAppDataPath += WString(PROGRAM_NAME) + WString("\\");
    WString sIniFileName2 = g_sAppDataPath + WString(PROGRAM_INIFILE);

    if (WideFileExists(sIniFileName2)) {
      g_pIni.reset(new TMemIniFileW(sIniFileName2));
    }
    else
      g_pIni->FileName = sIniFileName2;

    if (!m_blConfigReadOnly && !WideDirectoryExists(g_sAppDataPath))
      WideCreateDir(g_sAppDataPath);
  }
  else
    g_sAppDataPath = g_sExePath;

  LoadLangConfig();

  // read the seed file and incorporate contents into the random pool
  // (do this directly after LoadLangConfig() because we can translate
  // error messages now)
  m_sRandSeedFileName = g_sAppDataPath + WString(PROGRAM_RANDSEEDFILE);
  if (WideFileExists(m_sRandSeedFileName)) {
    if (!m_pRandPool->ReadSeedFile(m_sRandSeedFileName))
      MsgBox(TRLFormat("Could not read random seed file\n\"%s\".",
        m_sRandSeedFileName), MB_ICONERROR);
  }

  // create a seed file NOW or overwrite the existing one
  WriteRandSeedFile();

  // process errors in the command line arguments
  if (!sUnknownSwitches.IsEmpty()) {
    sUnknownSwitches[sUnknownSwitches.Length()-1] = '.';
    DelayStartupError(TRLFormat("Unknown command line switch(es):\n%s",
      sUnknownSwitches));
  }

  MainMenu_Help_About->Caption = TRLFormat("About %s...", PROGRAM_NAME);
  TrayMenu_About->Caption = MainMenu_Help_About->Caption;
  m_sEntropyBitsLbl = TRL("Entropy bits:");

  m_sCharSetHelp = ConvertCr2Crlf(FormatW(
    "%s\n"
    "<AZ> = A..Z\t<base64>,<b64> = <AZ><az><09>, +, /\n"
    "<az> = a..z\t<easytoread>,<etr> = <AZ><az><09> %s\n"
    "<09> = 0..9\t<symbols>,<sym> = %s (!\"#$%%...)\n"
    "<Hex> = 0..9, A..F\t<brackets>,<brac> = %s (()[]{}<>)\n"
    "<hex> = 0..9, a..f\t<punctuation>,<punct> = %s (,.;:)\n"
    "<highansi>,<high> = %s\n"
    "<phonetic> = %s\n"
    "<phoneticx> = %s\n\n"
    "%s",
    TRL("You can use the following placeholders:"),
    TRL("without ambiguous characters"),
    TRL("special symbols"),
    TRL("brackets"),
    TRL("punctuation marks"),
    TRL("higher ANSI characters"),
    TRL("generate phonetic password (only lower-case letters)"),
    TRL("generate phonetic password (mixed-case letters)"),
    TRL("Comments may be provided in square brackets \"[...]\"\n"
      "at the beginning of the sequence.")
  ));

  m_sFormatPasswHelp = ConvertCr2Crlf(FormatW(
     "%s\n\n"
     "%s\n\n"
     "%%x = %s\t%%v = %s (aeiou)\n"
     "%%a = a..z, 0..9\t%%V = %s\n"
     "%%A = A..Z, a..z, 0..9\t%%Z = %s\n"
     "%%U = A..Z, 0..9\t%%c = %s (bcdf...)\n"
     "%%d = 0..9\t%%C = %s\n"
     "%%h = 0..9, a..f\t%%z = %s\n"
     "%%H = 0..9, A..F\t%%p = %s (,.;:)\n"
     "%%l = a..z\t%%b = %s (()[]{}<>)\n"
     "%%L = A..Z, a..z\t%%s = %s (!\"#$%%...)\n"
     "%%u = A..Z\t%%S = %%A + %s\n"
     "%%y = %s\t%%E = %%A %s\n"
     "%%q = %s\n"
     "%%Q = %s\n\n",
    TRL("Format specifiers have the form \"%[*][N]x\" or \"%[*][M-N]x\", where the\n"
        "optional argument \"N\" specifies the number of repetitions (between 1 and\n"
        "99999), \"M-N\" specifies a random number of repetitions in the range\n"
        "from M to N, and \"x\" is the actual format specifier/placeholder. The\n"
        "optional asterisk (*) means that each character must occur only once in\n"
        "the sequence. Example: \"%16u\" means \"Insert 16 random upper-case letters\n"
        "into the password\"."),
    TRL("List of placeholders with optional argument \"N\":"),
    TRL("custom character set"),
    TRL("vowels, lower-case"),
    TRL("vowels, mixed-case"),
    TRL("vowels, upper-case"),
    TRL("consonants, lower-case"),
    TRL("consonants, mixed-case"),
    TRL("consonants, upper-case"),
    TRL("punctuation marks"),
    TRL("brackets"),
    TRL("special symbols"),
    TRL("special symbols"),
    TRL("higher ANSI characters"),
    TRL("without ambiguous characters"),
    TRL("generate phonetic password (only lower-case letters)"),
    TRL("generate phonetic password (mixed-case letters)")
  ));

  m_sFormatPasswHelp += ConvertCr2Crlf(FormatW(
    "%s\n\n"
    "%%P = %s\n"
    "%%{N}w = %s\n"
    "%%{N}W = %s\n"
    "%%{N}[...%%] = %s\n"
    "%%{N}{...%%} = %s\n"
    "%%{N}<...%%> = %s\n\n"
    "%s\n"
    "* %s\n"
    "* %s\n",
    TRL("List of special format specifiers\n(possible usage of argument \"N\" "
        "is indicated by \"{N}\"):"),
    TRL("insert password generated via \"Include characters/words\""),
    TRL("words from word list, multiple words are separated by spaces"),
    TRL("words, multiple words are not separated at all"),
    TRL("repeat input sequence in brackets N times"),
    TRL("randomly permute formatted sequence in brackets, keep N characters"),
    TRL("treat sequence as character set and insert N characters"),
    TRL("Additional notes:"),
    TRL("Use the sequence \"%%\" to insert a percent sign."),
    TRL("Comments may be provided in square brackets \"[...]\"\n"
        "at the beginning of the sequence.")
    ));

  // unfortunately, TMenuItem's RethinkHotkeys() doesn't work properly,
  // so we have to use a self-written function to add accelerator keys
/*  if (AddMenuShortcuts(MainMenu->Items)) {
    for (nI = 0; nI < MainMenu->Items->Count; nI++)
      AddMenuShortcuts(MainMenu->Items->Items[nI]);
    AddMenuShortcuts(MainMenu->Items->Items[2]->Items[2]);
  }*/

  PasswSecurityBarPanel->Width = 0;

  SaveDlg->Filter = OpenDlg->Filter;

  // load configuration from INI file
  LoadConfig();
}
//---------------------------------------------------------------------------
__fastcall TMainForm::~TMainForm()
{
  //if (m_pUpdCheckThread != NULL)
  //  delete m_pUpdCheckThread;

  if (g_nAppState & APPSTATE_SYSTEMTRAY)
    TrayMessage(NIM_DELETE);
  DeactivateHotKey();

  PasswBox->Tag = 0;
  ClearEditBoxTextBuf(PasswBox, 256);

  if (g_pLangSupp != NULL)
    delete g_pLangSupp;

  //delete g_pIni;

  for (int nI = 0; nI < g_pProfileList->Count; nI++)
    delete (PWGenProfile*) g_pProfileList->Items[nI];

  //delete g_pProfileList;
  //delete g_pEntropyMng;
  //delete g_pRandPool;
  //if (g_pKeySeededPRNG != NULL)
  //  delete g_pKeySeededPRNG;
  fprng_reset();

  // remove the PasswBox from the list of drop targets
  UnregisterDropWindow(PasswBox->Handle, m_pPasswBoxDropTarget);

  // uninitialize the OLE library
  OleUninitialize();

  CloseHandle(g_hAppMutex);

  // restart the program
  if (m_blRestart)
    ExecuteShellOp(TntApplication->ExeName, false);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormClose(TObject *Sender, TCloseAction &Action)
{
  if (MainMenu_Options_SaveSettingsOnExit->Checked && !m_blConfigReadOnly || m_blRestart)
    SaveConfig();
  WriteRandSeedFile();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormPaint(TObject *Sender)
{
  if (Tag == MAINFORM_TAG_REPAINTCOMBOBOXES) {
    Tag = 0;
    if (ActiveControl != CharSetList)
      CharSetList->SelLength = 0;
    if (ActiveControl != WLFNList)
      WLFNList->SelLength = 0;
    if (ActiveControl != FormatList)
      FormatList->SelLength = 0;
  }

  if (m_blStartup) {
    m_blStartup = false;

    AnsiString asGUIFont = g_pIni->ReadWString(CONFIG_ID, "GUIFont", "");
    int nPos = asGUIFont.Pos(";");
    if (nPos >= 2) {
      m_config.GUIFontName = asGUIFont.SubString(1, nPos - 1);
      m_config.GUIFontSize = StrToIntDef(
        asGUIFont.SubString(nPos + 1, asGUIFont.Length() - nPos), 0);
    }

    if ((!m_config.GUIFontName.IsEmpty() && m_config.GUIFontSize > 0) &&
        (AnsiCompareText(m_config.GUIFontName, Font->Name) != 0 ||
         m_config.GUIFontSize != Font->Size))
      ChangeGUIFont(m_config.GUIFontName, m_config.GUIFontSize);
    else {
      m_config.GUIFontName = Font->Name;
      m_config.GUIFontSize = Font->Size;
    }

    PasswOptionsDlg->MaxWordLenSpinBtn->Max = WORDLIST_MAX_WORDLEN;
    PasswOptionsDlg->SetOptions(m_passwOptions);
    SetAdvancedBtnCaption();

    Application->BringToFront();

    if (m_nNumStartupErrors != 0) {
      MsgBox(TRLFormat("PWGen encountered %d error(s) during startup:",
        m_nNumStartupErrors) + m_sStartupErrors, MB_ICONWARNING);
      m_sStartupErrors = "";
    }

    m_config.AutoCheckUpdates = TAutoCheckUpdates(
      g_pIni->ReadInteger(CONFIG_ID, "AutoCheckUpdates", acuWeekly));
    if (m_config.AutoCheckUpdates < acuDaily ||
        m_config.AutoCheckUpdates > acuDisabled)
      m_config.AutoCheckUpdates = acuWeekly;

    if (m_config.AutoCheckUpdates != acuDisabled) {
      TDateTime now = TDateTime::CurrentDate();
      TDateTime lastCheck =
        g_pIni->ReadDate(CONFIG_ID, "LastUpdateCheck", TDateTime());

      bool blNeedCheck = false;
      switch (m_config.AutoCheckUpdates) {
      case acuDaily:
        blNeedCheck = DaysBetween(now, lastCheck) > 0; break;
      case acuWeekly:
        blNeedCheck = WeeksBetween(now, lastCheck) > 0; break;
      case acuMonthly:
        blNeedCheck = MonthsBetween(now, lastCheck) > 0;
      }

      if (blNeedCheck) {
        MainMenu_Help_CheckForUpdates->Enabled = false;
        m_pUpdCheckThread.reset(new TUpdateCheckThread());
        m_pUpdCheckThread->OnTerminate = OnUpdCheckThreadTerminate;
      }
    }

    ConfigurationDlg->SetOptions(m_config);
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::OnUpdCheckThreadTerminate(TObject* Sender)
{
  if (m_pUpdCheckThread->Result >= 0)
    g_pIni->WriteDate(CONFIG_ID, "LastUpdateCheck", TDateTime::CurrentDate());

  m_pUpdCheckThread.release();

  MainMenu_Help_CheckForUpdates->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::DelayStartupError(const WString& sMsg)
{
  m_nNumStartupErrors++;
  m_sStartupErrors += FormatW("\n\n%d) %s", m_nNumStartupErrors, sMsg);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::LoadLangConfig(void)
{
  // which language do we have to set?
  WString sLangName = g_pIni->ReadWString(CONFIG_ID, "Language", "");
  if (sLangName.IsEmpty())
    sLangName = WString(LANGUAGE_DEFAULT);

  WString sLangFileName;
  int nLangIndex = 0;
  int nLangEntries = 1;

  // look for language files in the program directory
  WString sFindFile = g_sExePath + WString("*.lng");
  TSearchRecW srw;
  if (WideFindFirst(sFindFile, faAnyFile, srw) == 0) {
    //TStringFileStreamW* pFile = NULL;
    const WString sLangNameEntry = WString(LANGUAGE_NAME),
                  sLangVerEntry = WString(LANGUAGE_VERSION);
    do {
      WString sFileName = g_sExePath + WideExtractFileName(srw.Name);

      /*if (pFile != NULL) {
        delete pFile;
        pFile = NULL;
      }*/

      try {
        std::auto_ptr<TStringFileStreamW> pFile(new TStringFileStreamW(sFileName, fmOpenRead, ceAnsi, true, 1024));

        const int BUFSIZE = 64;
        wchar_t wszBuf[BUFSIZE];
        if (pFile->ReadString(wszBuf, BUFSIZE) == 0)
          continue;

        WString sStr = Trim(WString(wszBuf));
        if (sStr != sLangNameEntry)
          continue;

        if (pFile->ReadString(wszBuf, BUFSIZE) == 0)
          continue;

        WString sName = Trim(WString(wszBuf));

        while (1) {
          if (pFile->ReadString(wszBuf, BUFSIZE) == 0) {
            sStr = "";
            break;
          }
          sStr = Trim(WString(wszBuf));
          if (!sStr.IsEmpty())
            break;
        }

        if (sStr != sLangVerEntry)
          continue;

        if (pFile->ReadString(wszBuf, BUFSIZE) == 0)
          continue;

        WString sVersion = Trim(WString(wszBuf));
        if (sVersion.Length() == 0 || sVersion.Length() > 10)
          continue;

        sName = FormatW("%s (v%s)", sName, sVersion);

        if (MainMenu_Options_Language->Find(sName) != NULL)
          continue;
        /*for (int nI = 0; nI < MainMenu_Options_Language->Count; nI++) {
          if (WideCompareText(sName,
              MainMenu_Options_Language->Items[nI]->Caption) == 0) {
            blDuplicate = true;
            break;
          }
        }
        if (blDuplicate)
          continue;*/

        TTntMenuItem* pItem = new TTntMenuItem(MainMenu_Options_Language);
        pItem->Caption = sName;
        pItem->Hint = sVersion;
        pItem->RadioItem = true;
        pItem->OnClick = MainMenu_Options_LanguageItemClick;
        MainMenu_Options_Language->Add(pItem);

        if (nLangIndex == 0 && WideSameText(sName, sLangName)) {
          sLangFileName = sFileName;
          nLangIndex = nLangEntries;
        }

        nLangEntries++;
      }
      catch (...) {
      }
    }
    while (WideFindNext(srw) == 0 &&
           nLangEntries < LANGUAGE_MAX_ITEMS);

   //if (pFile != NULL)
   //   delete pFile;

    WideFindClose(srw);
  }

  // nothing found?
  if (!WideSameText(sLangName, WString(LANGUAGE_DEFAULT)) && nLangIndex == 0)
    DelayStartupError(FormatW("Could not find language \"%s\".", sLangName));

  // change language if necessary
  if (nLangIndex != 0 && !ChangeLanguage(sLangFileName))
      nLangIndex = 0;

  m_sHelpFileName = g_sExePath + TRLDEF(LANGUAGE_HELPFILE, PROGRAM_HELPFILE);

  MainMenu_Options_Language->Items[nLangIndex]->Checked = true;
}
//---------------------------------------------------------------------------
bool __fastcall TMainForm::ChangeLanguage(const WString& sLangFileName)
{
  try {
    g_pLangSupp = new LanguageSupport(sLangFileName);

    int nI;
    for (nI = 0; nI < 4; nI++)
      TRLS(g_msgBoxCaptionList[nI]);

    TRLCaption(SettingsGroup);
    TRLCaption(IncludeCharsCheck);
    TRLCaption(CharsLengthLbl);
    TRLCaption(CharSetLbl);
    TRLCaption(IncludeWordsCheck);
    TRLCaption(WordsNumLbl);
    TRLCaption(WordListFileLbl);
    TRLCaption(CombineWordsCharsCheck);
    TRLCaption(SpecifyLengthCheck);
    TRLCaption(FormatPasswCheck);
    TRLCaption(MultiplePasswLbl);
    TRLCaption(GenerateBtn2);
//    TRLCaption(AdvancedBtn);
    TRLCaption(PasswGroup);
    TRLCaption(GenerateBtn);
    TRLCaption(PasswInfoLbl);
    TRLCaption(RandomPoolGroup);

    for (nI = 0; nI < MainMenu->Items->Count; nI++) {
      TTntMenuItem* pItem = (TTntMenuItem*) MainMenu->Items->Items[nI];
      TRLMenuItem(pItem);
      for (int nJ = 0; nJ < pItem->Count; nJ++) {
        TTntMenuItem* pSubItem = (TTntMenuItem*) pItem->Items[nJ];
        if (pSubItem->Caption != WString("-"))
          TRLCaption(pSubItem);
      }
    }

    TRLCaption(MainMenu_File_Profile_ProfileEditor);
    TRLCaption(MainMenu_Tools_DetermRandGen_Reset);
    TRLCaption(MainMenu_Tools_DetermRandGen_Deactivate);
    TRLCaption(MainMenu_Tools_ProvideAddEntropy_AsText);
    TRLCaption(MainMenu_Tools_ProvideAddEntropy_FromFile);

    for (nI = 0; nI < ListMenu->Items->Count; nI++)
      TRLCaption((TTntMenuItem*) ListMenu->Items->Items[nI]);

    for (nI = 0; nI < TrayMenu->Items->Count; nI++)
      TRLCaption((TTntMenuItem*) TrayMenu->Items->Items[nI]);
    TRLCaption(TrayMenu_Profile_ProfileEditor);

    for (nI = 0; nI < PasswBoxMenu->Items->Count; nI++)
      TRLCaption((TTntMenuItem*) PasswBoxMenu->Items->Items[nI]);

    TRLCaption<TTntMenuItem>(EntropyProgressMenu_ResetCounters);
    TRLHint(HelpBtn);
    TRLHint(ClearClipBtn);
    TRLHint(ConfigBtn);
    TRLHint(CryptTextBtn);
    TRLHint(ProfileEditorBtn);
    TRLHint(MPPasswGenBtn);
    TRLHint(CharSetHelpBtn);
    TRLHint(CharSetInfoBtn);
    TRLHint(BrowseBtn);
    TRLHint(WordListInfoBtn);
    TRLHint(FormatPasswHelpBtn);
    TRLHint(GenerateBtn3);
    TRLHint(TogglePasswBtn);
    TRLHint(ToggleRandPoolBtn);
    TRLHint(PasswSecurityBar);

    SaveDlg->Filter = TRL(SaveDlg->Filter);
    OpenDlg->Filter = TRL(OpenDlg->Filter);
  }
  catch (Exception& e) {
    DelayStartupError(FormatW("Error while loading language file\n\"%s\":\n%s.",
      sLangFileName, UTF8Decode(e.Message)));
    if (g_pLangSupp != NULL) {
      delete g_pLangSupp;
      g_pLangSupp = NULL;
    }
    return false;
  }
  return true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::WriteRandSeedFile(bool blShowError)
{
  if (!m_blConfigReadOnly) {
    if (!m_pRandPool->WriteSeedFile(m_sRandSeedFileName) && blShowError) {
      WString sMsg = TRLFormat("Could not write to random seed file\n\"%s\".",
        m_sRandSeedFileName);
      if (m_blStartup)
        DelayStartupError(sMsg);
      else
        MsgBox(sMsg, MB_ICONERROR);
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::LoadConfig(void)
{
  AnsiString asLastVersion = g_pIni->ReadString(CONFIG_ID, "LastVersion", "");

  int nTop = g_pIni->ReadInteger(CONFIG_ID, "WindowTop", INT_MAX);
  int nLeft = g_pIni->ReadInteger(CONFIG_ID, "WindowLeft", INT_MAX);
  if (nTop == INT_MAX || nLeft == INT_MAX)
    Position = poScreenCenter;
  else {
    Top = nTop;
    Left = nLeft;
  }

  Height = g_pIni->ReadInteger(CONFIG_ID, "WindowHeight", Height);
  Width = g_pIni->ReadInteger(CONFIG_ID, "WindowWidth", Width);

  MainMenu_Options_AlwaysOnTop->Checked =
    g_pIni->ReadBool(CONFIG_ID, "AlwaysOnTop", false);
  MainMenu_Options_AlwaysOnTopClick(this);

  IncludeCharsCheck->Checked = g_pIni->ReadBool(CONFIG_ID, "IncludeChars", true);

  CharsLengthSpinBtn->Position = short(g_pIni->ReadInteger(CONFIG_ID, "CharsLength", 12));

  // load the advanced password options before loading the character set!
  AnsiString asPasswOptions = g_pIni->ReadString(CONFIG_ID, "AdvancedPasswOptions", "");
  bool blOldPasswOptions = CompareVersions(asLastVersion, "2.5.3") < 0;
  m_passwOptions.Flags = (blOldPasswOptions) ?
    stringToPasswOptions(asPasswOptions, asLastVersion) :
    StrToIntDef(asPasswOptions, 0);

  m_passwOptions.AmbigChars = g_pIni->ReadWString(CONFIG_ID, "AmbigChars", "");
  m_passwOptions.SpecialSymbols = g_pIni->ReadWString(CONFIG_ID, "SpecialSym", "");
  m_passwOptions.TrigramFileName = g_pIni->ReadWString(CONFIG_ID, "TrigramFile", "");
  if (LoadTrigramFile(m_passwOptions.TrigramFileName) <= 0)
    m_passwOptions.TrigramFileName = "";

  CharSetList->Items->CommaText = g_pIni->ReadWString(CONFIG_ID, "CharSetListEntries", "");

  int nI;
  if (CharSetList->Items->Count == 0) {
    for (nI = 0; nI < CHARSETLIST_DEFAULTENTRIES_NUM; nI++)
      CharSetList->Items->Add(CHARSETLIST_DEFAULTENTRIES[nI]);
  }
  else {
    while (CharSetList->Items->Count > LISTS_MAX_ENTRIES)
      CharSetList->Items->Delete(CharSetList->Items->Count - 1);
  }

  if (LoadCharSet(CharSetList->Items->Strings[0]) == 0) {
    DelayStartupError(TRLFormat("Character set \"%s\" is invalid.",
      CharSetList->Items->Strings[0]));
    CharSetList->Items->Strings[0] = CHARSETLIST_DEFAULTENTRIES[0];
    LoadCharSet(CHARSETLIST_DEFAULTENTRIES[0]);
  }
  CharSetList->ItemIndex = 0;

  int nMaxWordLen = g_pIni->ReadInteger(CONFIG_ID, "MaxWordLen", WORDLIST_MAX_WORDLEN);
  if (nMaxWordLen < 1 || nMaxWordLen > WORDLIST_MAX_WORDLEN)
    nMaxWordLen = WORDLIST_MAX_WORDLEN;
  m_passwOptions.MaxWordLen = nMaxWordLen;

  IncludeWordsCheck->Checked = g_pIni->ReadBool(CONFIG_ID, "IncludeWords", false);

  WordsNumSpinBtn->Position = short(g_pIni->ReadInteger(CONFIG_ID, "WordsNum", 5));

  WLFNList->Items->CommaText = g_pIni->ReadWString(CONFIG_ID, "WLFNListEntries", "");

  if (WLFNList->Items->Count == 0) {
    WLFNList->Items->Add(WLFNLIST_DEFAULT);
    LoadWordListFile();
  }
  else if (WLFNList->Items->Strings[0] == WString(WLFNLIST_DEFAULT))
    LoadWordListFile();
  else {
    WString sFileName = WLFNList->Items->Strings[0];
    if (LoadWordListFile(sFileName) <= 0) {
      DelayStartupError(TRLFormat("Error while loading word list file\n\"%s\".",
        sFileName));
      WLFNList->Items->Strings[0] = WLFNLIST_DEFAULT;
      LoadWordListFile();
    }
  }

  while (WLFNList->Items->Count > LISTS_MAX_ENTRIES)
    WLFNList->Items->Delete(WLFNList->Items->Count - 1);

  WLFNList->ItemIndex = 0;

  CombineWordsCharsCheck->Checked = g_pIni->ReadBool(CONFIG_ID,
    "CombineWordsChars", false);

  SpecifyLengthCheck->Checked = g_pIni->ReadBool(CONFIG_ID, "PassphrSpecLen", false);
  SpecifyLengthBox->Text = g_pIni->ReadString(CONFIG_ID, "PassphrSpecLenString", "");

  FormatPasswCheck->Checked = g_pIni->ReadBool(CONFIG_ID, "FormatPassw", false);

  FormatList->Items->CommaText = g_pIni->ReadWString(CONFIG_ID, "FormatListEntries", "");

  if (FormatList->Items->Count == 0) {
    for (nI = 0; nI < FORMATLIST_DEFAULTENTRIES_NUM; nI++)
      FormatList->Items->Add(FORMATLIST_DEFAULTENTRIES[nI]);
  }
  else {
    while (FormatList->Items->Count > LISTS_MAX_ENTRIES)
      FormatList->Items->Delete(FormatList->Items->Count - 1);
  }

  FormatList->ItemIndex = 0;

  PasswNumBox->Text = WString(g_pIni->ReadInteger(CONFIG_ID, "PasswNum", 100));
  PasswNumBoxExit(this);

  TogglePasswBtn->Down = g_pIni->ReadBool(CONFIG_ID, "HidePassw", false);
  TogglePasswBtnClick(this);

  ToggleRandPoolBtn->Down = g_pIni->ReadBool(CONFIG_ID, "HideEntropyProgress",
    false);
  ToggleRandPoolBtnClick(this);

  m_config.AutoClearClip = g_pIni->ReadBool(CONFIG_ID, "AutoClearClipboard", true);
  m_config.AutoClearClipTime = g_pIni->ReadInteger(CONFIG_ID,
    "AutoClearClipboardTime", AUTOCLEARCLIPTIME_DEFAULT);

  if (m_config.AutoClearClipTime < AUTOCLEARCLIPTIME_MIN ||
      m_config.AutoClearClipTime > AUTOCLEARCLIPTIME_MAX)
    m_config.AutoClearClipTime = AUTOCLEARCLIPTIME_DEFAULT;

  if ((m_config.ShowSysTrayIconConst =
      g_pIni->ReadBool(CONFIG_ID, "SystemTrayIconShowConst", true)))
  {
    TrayMessage(NIM_ADD);
    TrayMessage(NIM_MODIFY);
    g_nAppState |= APPSTATE_SYSTEMTRAY;
    //m_blSystemTray = true;
  }

  m_config.MinimizeToSysTray = g_pIni->ReadBool(CONFIG_ID,
    "SystemTrayIconMinimize", true);

  MainMenu_Options_SaveSettingsOnExit->Checked = g_pIni->ReadBool(CONFIG_ID,
    "SaveSettingsOnExit", true);

  PasswBoxMenu_Editable->Checked = g_pIni->ReadBool(CONFIG_ID,
    "PasswEditable", true);
  PasswBoxMenu_EnablePasswTest->Checked = g_pIni->ReadBool(CONFIG_ID,
    "EnablePasswTest", true);
  PasswBoxMenu_EditableClick(this);
  PasswBoxMenu_EnablePasswTestClick(this);

  StringToFont(g_pIni->ReadString(CONFIG_ID, "PasswBoxFont", ""), PasswBox->Font);
  FontDlg->Font = PasswBox->Font;

  IncludeCharsCheckClick(this);

  TShortCut hotKeyDefault = ShortCut('P', TShiftState() << ssShift << ssCtrl);
  m_config.HotKey = g_pIni->ReadInteger(CONFIG_ID, "HotKey", hotKeyDefault);
  m_config.HotKeyActivated = g_pIni->ReadBool(CONFIG_ID, "HotKeyActivate", false);
  m_config.HotKeyActShowMainWin = g_pIni->ReadBool(CONFIG_ID, "HotKeyActShowMainWin", false);
  m_config.HotKeyAction = THotKeyAction(
    g_pIni->ReadInteger(CONFIG_ID, "HotKeyAction", hkaPasswMsgBox));
  if (m_config.HotKeyAction < hkaNone || m_config.HotKeyAction > hkaOpenMPPG)
    m_config.HotKeyAction = hkaPasswMsgBox;

  if (m_config.HotKeyActivated) {
    if (m_config.HotKey == 0)
      m_config.HotKey = hotKeyDefault;
    ActivateHotKey(m_config.HotKey);
  }

  g_fileEncoding = CharacterEncoding(
    g_pIni->ReadInteger(CONFIG_ID, "FileEncoding", ceAnsi));
  if (g_fileEncoding < ceAnsi || g_fileEncoding > ceUtf8)
    g_fileEncoding = ceAnsi;

  m_config.FileEncoding = g_fileEncoding;

  // read the profiles and delete all profile entries afterwards
  for (nI = 0; g_pProfileList->Count < PROFILES_MAX_NUM; nI++) {
    AnsiString asProfileId = CONFIG_PROFILE_ID + IntToStr(nI);
    if (!g_pIni->SectionExists(asProfileId))
      break;

    WString sProfileName = g_pIni->ReadWString(asProfileId, "ProfileName", "");
    if (sProfileName.IsEmpty())
      continue;

    bool blNameExists = false;
    for (int nJ = 0; nJ < g_pProfileList->Count; nJ++) {
      if (WideSameText(((PWGenProfile*) g_pProfileList->Items[nJ])->ProfileName,
          sProfileName)) {
        blNameExists = true;
        break;
      }
    }

    if (blNameExists)
      continue;

    PWGenProfile* pProfile = new PWGenProfile;
    pProfile->ProfileName = sProfileName;
    pProfile->IncludeChars = g_pIni->ReadBool(asProfileId, "IncludeChars", false);
    pProfile->CharsLength = g_pIni->ReadInteger(asProfileId, "CharsLength", 1);
    pProfile->CharSet = g_pIni->ReadWString(asProfileId, "CharSet", "");
    pProfile->IncludeWords = g_pIni->ReadBool(asProfileId, "IncludeWords", false);
    pProfile->WordsNum = g_pIni->ReadInteger(asProfileId, "WordsNum", 1);
    pProfile->WordListFileName = g_pIni->ReadWString(asProfileId, "WordListFileName", "");
    pProfile->CombineWordsChars = g_pIni->ReadBool(asProfileId, "CombineWordsChars", false);
    pProfile->SpecifyLength = g_pIni->ReadBool(asProfileId, "PassphrSpecLen", false);
    pProfile->SpecifyLengthString = g_pIni->ReadString(asProfileId,
      "PassphrSpecLenString", "");
    pProfile->FormatPassw = g_pIni->ReadBool(asProfileId, "FormatPassw", false);
    pProfile->FormatString = g_pIni->ReadWString(asProfileId, "FormatString", "");
    pProfile->PasswNum = g_pIni->ReadInteger(asProfileId, "PasswNum", 2);

    asPasswOptions = g_pIni->ReadString(asProfileId, "AdvancedPasswOptions", "");
    pProfile->AdvancedOptionsUsed = !asPasswOptions.IsEmpty();

    if (pProfile->AdvancedOptionsUsed) {
      pProfile->AdvancedPasswOptions.Flags = (blOldPasswOptions) ?
        stringToPasswOptions(asPasswOptions, asLastVersion) :
        StrToIntDef(asPasswOptions, 0);
      pProfile->AdvancedPasswOptions.AmbigChars =
        g_pIni->ReadWString(asProfileId, "AmbigChars", "");
      pProfile->AdvancedPasswOptions.SpecialSymbols =
        g_pIni->ReadWString(asProfileId, "SpecialSym", "");
      pProfile->AdvancedPasswOptions.MaxWordLen =
        g_pIni->ReadInteger(asProfileId, "MaxWordLen", WORDLIST_MAX_WORDLEN);
      pProfile->AdvancedPasswOptions.TrigramFileName =
        g_pIni->ReadString(asProfileId, "TrigramFile", "");
    }

    g_pProfileList->Add(pProfile);

    //g_pIni->EraseSection(asProfileId);
  }

  RecreateProfileMenus();
}
//---------------------------------------------------------------------------
bool __fastcall TMainForm::SaveConfig(void)
{
  try {
    g_pIni->WriteString(CONFIG_ID, "LastVersion", PROGRAM_VERSION);

    WString sLangName;
    int nI;
    for (nI = 0; nI < MainMenu_Options_Language->Count; nI++) {
      TTntMenuItem* pItem = (TTntMenuItem*) MainMenu_Options_Language->Items[nI];
      if (pItem->Checked) {
        sLangName = pItem->Caption;
        break;
      }
    }
    g_pIni->WriteWString(CONFIG_ID, "Language", sLangName);
    g_pIni->WriteWString(CONFIG_ID, "GUIFont", Font->Name + ";" +
      IntToStr(Font->Size));
    g_pIni->WriteInteger(CONFIG_ID, "WindowTop", Top);
    g_pIni->WriteInteger(CONFIG_ID, "WindowLeft", Left);
    g_pIni->WriteInteger(CONFIG_ID, "WindowHeight", Height);
    g_pIni->WriteInteger(CONFIG_ID, "WindowWidth", Width);
    g_pIni->WriteBool(CONFIG_ID, "AlwaysOnTop", MainMenu_Options_AlwaysOnTop->Checked);
    g_pIni->WriteBool(CONFIG_ID, "IncludeChars", IncludeCharsCheck->Checked);
    g_pIni->WriteInteger(CONFIG_ID, "CharsLength", CharsLengthSpinBtn->Position);
    g_pIni->WriteWString(CONFIG_ID, "CharSetListEntries", CharSetList->Items->CommaText);
    g_pIni->WriteBool(CONFIG_ID, "IncludeWords", IncludeWordsCheck->Checked);
    g_pIni->WriteInteger(CONFIG_ID, "WordsNum", WordsNumSpinBtn->Position);
    g_pIni->WriteWString(CONFIG_ID, "WLFNListEntries", WLFNList->Items->CommaText);
    g_pIni->WriteBool(CONFIG_ID, "CombineWordsChars", CombineWordsCharsCheck->Checked);
    g_pIni->WriteBool(CONFIG_ID, "PassphrSpecLen", SpecifyLengthCheck->Checked);
    g_pIni->WriteString(CONFIG_ID, "PassphrSpecLenString", SpecifyLengthBox->Text);
    g_pIni->WriteBool(CONFIG_ID, "FormatPassw", FormatPasswCheck->Checked);
    g_pIni->WriteWString(CONFIG_ID, "FormatListEntries", FormatList->Items->CommaText);
    g_pIni->WriteInteger(CONFIG_ID, "PasswNum", StrToIntDef(PasswNumBox->Text, 0));
    g_pIni->WriteBool(CONFIG_ID, "HidePassw", TogglePasswBtn->Down);
    g_pIni->WriteBool(CONFIG_ID, "HideEntropyProgress", ToggleRandPoolBtn->Down);
    g_pIni->WriteInteger(CONFIG_ID, "AdvancedPasswOptions", m_passwOptions.Flags);
    g_pIni->WriteWString(CONFIG_ID, "AmbigChars", m_passwOptions.AmbigChars);
    g_pIni->WriteWString(CONFIG_ID, "SpecialSym", m_passwOptions.SpecialSymbols);
    g_pIni->WriteInteger(CONFIG_ID, "MaxWordLen", m_passwOptions.MaxWordLen);
    g_pIni->WriteString(CONFIG_ID, "TrigramFile", m_passwOptions.TrigramFileName);
    g_pIni->WriteBool(CONFIG_ID, "AutoClearClipboard", m_config.AutoClearClip);
    g_pIni->WriteInteger(CONFIG_ID, "AutoClearClipboardTime", m_config.AutoClearClipTime);
    g_pIni->WriteBool(CONFIG_ID, "SystemTrayIconShowConst",
      m_config.ShowSysTrayIconConst);
    g_pIni->WriteBool(CONFIG_ID, "SystemTrayIconMinimize",
      m_config.MinimizeToSysTray);

    g_pIni->WriteInteger(CONFIG_ID, "AutoCheckUpdates", m_config.AutoCheckUpdates);
    g_pIni->WriteBool(CONFIG_ID, "SaveSettingsOnExit",
      MainMenu_Options_SaveSettingsOnExit->Checked);
    g_pIni->WriteBool(CONFIG_ID ,"PasswEditable", PasswBoxMenu_Editable->Checked);
    g_pIni->WriteBool(CONFIG_ID, "EnablePasswTest",
      PasswBoxMenu_EnablePasswTest->Checked);

    g_pIni->WriteString(CONFIG_ID, "PasswBoxFont", FontToString(PasswBox->Font));

    g_pIni->WriteInteger(CONFIG_ID, "HotKey", m_config.HotKey);
    g_pIni->WriteBool(CONFIG_ID, "HotKeyActivate", m_config.HotKeyActivated);
    g_pIni->WriteBool(CONFIG_ID, "HotKeyActShowMainWin", m_config.HotKeyActShowMainWin);
    g_pIni->WriteInteger(CONFIG_ID, "HotKeyAction", m_config.HotKeyAction);

    g_pIni->WriteInteger(CONFIG_ID, "FileEncoding", int(g_fileEncoding));

    ConfigurationDlg->SaveConfig();
    PasswOptionsDlg->SaveConfig();
    PasswListForm->SaveConfig();
    PasswEnterDlg->SaveConfig();
    CreateRandDataFileDlg->SaveConfig();
    CreateTrigramFileDlg->SaveConfig();
    MPPasswGenDlg->SaveConfig();
    QuickHelpForm->SaveConfig();
    ProvideEntropyDlg->SaveConfig();
    ProfileEditDlg->SaveConfig();

    // now save the profiles
    for (nI = 0; /*nI < g_pProfileList->Count*/; nI++) {
      AnsiString asProfileId = CONFIG_PROFILE_ID + IntToStr(nI);

      if (nI >= g_pProfileList->Count) {
        if (g_pIni->SectionExists(asProfileId)) {
          g_pIni->EraseSection(asProfileId);
          continue;
        }
        else
          break;
      }

      PWGenProfile* pProfile = (PWGenProfile*) g_pProfileList->Items[nI];

      g_pIni->WriteWString(asProfileId, "ProfileName", pProfile->ProfileName);
      g_pIni->WriteBool(asProfileId, "IncludeChars", pProfile->IncludeChars);
      g_pIni->WriteInteger(asProfileId, "CharsLength", pProfile->CharsLength);
      g_pIni->WriteWString(asProfileId, "CharSet", pProfile->CharSet);
      g_pIni->WriteBool(asProfileId, "IncludeWords", pProfile->IncludeWords);
      g_pIni->WriteInteger(asProfileId, "WordsNum", pProfile->WordsNum);
      g_pIni->WriteWString(asProfileId, "WordListFileName", pProfile->WordListFileName);
      g_pIni->WriteBool(asProfileId, "CombineWordsChars", pProfile->CombineWordsChars);
      g_pIni->WriteBool(asProfileId, "PassphrSpecLen", pProfile->SpecifyLength);
      g_pIni->WriteString(asProfileId, "PassphrSpecLenString",
        pProfile->SpecifyLengthString);
      g_pIni->WriteBool(asProfileId, "FormatPassw", pProfile->FormatPassw);
      g_pIni->WriteWString(asProfileId, "FormatString", pProfile->FormatString);
      g_pIni->WriteInteger(asProfileId, "PasswNum", pProfile->PasswNum);

      if (pProfile->AdvancedOptionsUsed) {
        g_pIni->WriteInteger(asProfileId, "AdvancedPasswOptions",
          pProfile->AdvancedPasswOptions.Flags);
        g_pIni->WriteWString(asProfileId, "AmbigChars", pProfile->AdvancedPasswOptions.AmbigChars);
        g_pIni->WriteWString(asProfileId, "SpecialSym", pProfile->AdvancedPasswOptions.SpecialSymbols);
        g_pIni->WriteInteger(asProfileId, "MaxWordLen", pProfile->AdvancedPasswOptions.MaxWordLen);
        g_pIni->WriteString(asProfileId, "TrigramFile", pProfile->AdvancedPasswOptions.TrigramFileName);
      }
      else {
        g_pIni->DeleteKey(asProfileId, "AdvancedPasswOptions");
        g_pIni->DeleteKey(asProfileId, "AmbigChars");
        g_pIni->DeleteKey(asProfileId, "SpecialSym");
        g_pIni->DeleteKey(asProfileId, "MaxWordLen");
        g_pIni->DeleteKey(asProfileId, "TrigramFile");
      }
    }

    g_pIni->UpdateFile();
  }
  catch (Exception& e) {
    MsgBox(TRLFormat("Error while writing to configuration file:\n%s.",
      UTF8Decode(e.Message)), MB_ICONERROR);
    return false;
  }
  return true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::UpdateEntropyProgress(void)
{
  static const WString MAX_ENTROPY_STRING = "/" + IntToStr(RandomPool::MAX_ENTROPY);
  static bool blReachedMaxLast = false;
  
  bool blReachedMax = g_pEntropyMng->EntropyBits == EntropyManager::ENTROPYBITS_MAX;

  if (m_blShowEntProgress && !blReachedMax || !blReachedMaxLast)
  {
    EntropyProgress->Progress = g_pEntropyMng->EntropyBitsMax;

    WString sMask = (blReachedMax) ? " >%d/%d" : " %d/%d";
    WString sReachedMax = (blReachedMax) ? " >" : " ";

    EntropyBitsLbl->Caption = m_sEntropyBitsLbl + sReachedMax +
      IntToStr(g_pEntropyMng->EntropyBits) + MAX_ENTROPY_STRING;
    FormatW(sMask, g_pEntropyMng->EntropyBits, RandomPool::MAX_ENTROPY);
    blReachedMaxLast = blReachedMax;
  }
}
//---------------------------------------------------------------------------
int __fastcall TMainForm::LoadCharSet(const WString& sInput,
                                      bool blShowError)
{
  m_sCharSetInput = sInput;
  WString sResult = sInput;
  m_passwGen.SetupCharSets(sResult, m_passwOptions.AmbigChars,
    m_passwOptions.SpecialSymbols, m_passwOptions.Flags & PASSWOPTION_EXCLUDEAMBIG,
    m_passwOptions.Flags & PASSWOPTION_INCLUDESUBSET);
  int nSetSize = sResult.Length();

  if (nSetSize == 0) {
    if (blShowError) {
      m_blCharSetError = true;
      CharSetInfoLbl->Caption = TRL("Invalid character set.");
      CharSetInfoLbl->Font->Color = clRed;
    }

    return 0;
  }

  m_blCharSetError = false;

  AddEntryToList(CharSetList, sInput, true);

  m_sCharSetInfo = TRLFormat("%d characters / %.1f bits per character",
    nSetSize, m_passwGen.CustomCharSetEntropy);

  CharSetInfoLbl->Caption = m_sCharSetInfo;
  CharSetInfoLbl->Font->Color = clNavy;

  return nSetSize;
}
//---------------------------------------------------------------------------
int __fastcall TMainForm::LoadWordListFile(const WString& sInput,
                                           bool blShowError,
                                           bool blResetInfoOnly)
{
  if (!blResetInfoOnly || m_sWordListInfo.IsEmpty()) {
    WString sFileName;

    if (!sInput.IsEmpty() && !WideSameText(sInput, WLFNLIST_DEFAULT))
      sFileName = sInput;

    int nNumOfWords = m_passwGen.LoadWordListFile(sFileName,
      m_passwOptions.MaxWordLen,
      m_passwOptions.Flags & PASSWOPTION_LOWERCASEWORDS);

    if (nNumOfWords <= 0) {
      if (blShowError) {
        m_sWLFileNameErr = sFileName;
        if (nNumOfWords < 0)
          WordListInfoLbl->Caption = TRL("Could not open file.");
        else
          WordListInfoLbl->Caption = TRL("Not enough valid words.");
        WordListInfoLbl->Font->Color = clRed;
      }

      return nNumOfWords;
    }

    m_sWLFileName = sFileName;

    if (sFileName.IsEmpty())
      AddEntryToList(WLFNList, WLFNLIST_DEFAULT, false);
    else
      AddEntryToList(WLFNList, sFileName, false);
  
    m_sWordListInfo = TRLFormat("%d words / %.1f bits per word",
      m_passwGen.WordListSize, m_passwGen.WordListEntropy);
  }

  m_sWLFileNameErr = "";

  WordListInfoLbl->Caption = m_sWordListInfo;
  WordListInfoLbl->Font->Color = clNavy;

  return m_passwGen.WordListSize;
}
//---------------------------------------------------------------------------
int __fastcall TMainForm::LoadTrigramFile(const WString& sInput)
{
  WString sFileName = sInput;

  int nResult = m_passwGen.LoadTrigramFile(sFileName);

  if (nResult <= 0) {
    WString sMsg;
    if (nResult < 0)
      sMsg = TRL("Could not open trigram file.");
    else
      sMsg = TRL("Invalid trigram file.");
    if (m_blStartup)
      DelayStartupError(sMsg);
    else
      MsgBox(sMsg, MB_ICONERROR);
  }

  return nResult;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CryptText(bool blEncrypt,
                                     const SecureWString* psText)
{
  SecureWString sPassw;
  bool blSuccess = PasswEnterDlg->Execute(
    blEncrypt ? PASSWENTER_FLAG_ENCRYPT | PASSWENTER_FLAG_CONFIRMPASSW :
    PASSWENTER_FLAG_DECRYPT | PASSWENTER_FLAG_ENABLEOLDVER) == mrOk;
  if (blSuccess)
    PasswEnterDlg->GetPassw(sPassw);

  PasswEnterDlg->Clear();
  m_pRandPool->Flush();

  if (!blSuccess)
    return;

  Refresh();
  Screen->Cursor = crHourGlass;

  int nPasswBytes = (sPassw.Size() - 1) * sizeof(wchar_t);
  int nResult;

  if (blEncrypt) {
    nResult = EncryptText(psText, sPassw, nPasswBytes, m_pRandPool);

    // flush the pool to make sure we're back in the "add entropy" state
    m_pRandPool->Flush();
  }
  else {
    int nTryVersion = (PasswEnterDlg->OldVersionCheck->Checked) ? 0 :
      CRYPTTEXT_VERSION;

    SecureAnsiString asPassw;
    if (nTryVersion == 0) {
      int nAnsiLen = WideCharToMultiByte(CP_ACP, 0, sPassw, -1, NULL, 0,
        NULL, NULL);

      asPassw.New(nAnsiLen);

      WideCharToMultiByte(CP_ACP, 0, sPassw, -1, asPassw, nAnsiLen, NULL, NULL);
    }

    do {
      const word8* pTryPassw;
      int nTryPasswBytes;

      if (nTryVersion < 2) {
        pTryPassw = asPassw;
        nTryPasswBytes = asPassw.Size() - 1;
      }
      else {
        pTryPassw = sPassw;
        nTryPasswBytes = nPasswBytes;
      }

      nResult = DecryptText(psText, pTryPassw, nTryPasswBytes, nTryVersion);
    } while ((nResult == CRYPTTEXT_ERROR_TEXTCORRUPTED ||
             nResult == CRYPTTEXT_ERROR_BADKEY) &&
             ++nTryVersion < CRYPTTEXT_VERSION);
  }

  Screen->Cursor = crDefault;

  WString sMsg;
  switch (nResult) {
  case CRYPTTEXT_OK:
    if (blEncrypt)
      sMsg = TRL("Text successfully encrypted.");
    else
      sMsg = TRL("Text successfully decrypted.");
    break;
  case CRYPTTEXT_ERROR_CLIPBOARD:
    sMsg = TRL("Could not open clipboard.");
    break;
  case CRYPTTEXT_ERROR_NOTEXT:
    sMsg = TRL("No text available to process.");
    break;
  case CRYPTTEXT_ERROR_TEXTTOOLONG:
    sMsg = TRL("The text to be encrypted is too long.");
    break;
  case CRYPTTEXT_ERROR_OUTOFMEMORY:
    sMsg = TRL("Not enough memory available to perform\nthe operation. "
      "Try to use a shorter text.");
    break;
  case CRYPTTEXT_ERROR_TEXTCORRUPTED:
  case CRYPTTEXT_ERROR_BADKEY:
    sMsg = TRL("Decryption failed. This may be attributed\nto the following reasons:")
      + WString("\n");
    if (nResult == CRYPTTEXT_ERROR_BADKEY)
      sMsg += TRL("- You entered a wrong password.") + WString("\n");
    sMsg += TRL("- The text is corrupted.\n"
                "- The text is not encrypted.");
    break;
  case CRYPTTEXT_ERROR_DECOMPRFAILED:
   sMsg = TRL("This should not have happened:\nDecryption successful, but "
      "decompression\nfailed.");
  }

  if (nResult == CRYPTTEXT_OK)
    ShowInfoBox(sMsg);
  else
    MsgBox(sMsg, MB_ICONERROR);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CopiedSensitiveDataToClipboard(void)
{
  if (m_config.AutoClearClip)
    m_nAutoClearClipCnt = m_config.AutoClearClipTime;
}
//---------------------------------------------------------------------------
int __fastcall TMainForm::AddEntryToList(TTntComboBox* pComboBox,
                                         const WString& sEntry,
                                         bool blCaseSensitive)
{
  TTntStrings* pStrList = pComboBox->Items;

  int nPos = -1;
  if (blCaseSensitive) {
    for (int nI = 0; nI < pStrList->Count; nI++) {
      if (pStrList->Strings[nI] == sEntry) {
        nPos = nI;
        break;
      }
    }
  }
  else
    nPos = pStrList->IndexOf(sEntry); // IndexOf() is case-insensitive for TStrings

  if (nPos < 0) {
    if (pStrList->Count == LISTS_MAX_ENTRIES)
      pStrList->Delete(LISTS_MAX_ENTRIES - 1);
    pStrList->Insert(0, sEntry);
    nPos = 0;
  }
  else {
    pStrList->Move(nPos, 0);
    pComboBox->ItemIndex = 0;
  }
  return nPos;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ShowPasswInfo(int nPasswLen,
                                         int nPasswBits,
                                         bool blEstimated)
{
  PasswSecurityBarPanel->Width = std::max((std::min(nPasswBits / 128.0, 1.0) *
    PasswSecurityBar->Width), 4);
  WString sCaption;
  if (blEstimated)
    sCaption = "*";
  sCaption += TRLFormat("%d bits / %d characters", nPasswBits, nPasswLen);
  PasswInfoLbl->Caption = sCaption;
}
//---------------------------------------------------------------------------
bool __fastcall TMainForm::ApplyConfig(const Configuration& config)
{
  if (config.HotKeyActivated) {
    if (config.HotKey != m_config.HotKey && !ActivateHotKey(config.HotKey))
      return false;
  }
  else
    DeactivateHotKey();

  if (AnsiCompareText(config.GUIFontName, m_config.GUIFontName) != 0 ||
      config.GUIFontSize != m_config.GUIFontSize)
    ChangeGUIFont(config.GUIFontName, config.GUIFontSize);

  if (config.ShowSysTrayIconConst) {
    if (!(g_nAppState & APPSTATE_SYSTEMTRAY)) {
      TrayMessage(NIM_ADD);
      TrayMessage(NIM_MODIFY);
      g_nAppState |= APPSTATE_SYSTEMTRAY;
      //m_blSystemTray = true;
    }
  }
  else {
    if (g_nAppState & APPSTATE_SYSTEMTRAY) {
      TrayMessage(NIM_DELETE);
      g_nAppState &= ~APPSTATE_SYSTEMTRAY;
      //m_blSystemTray = false;
    }
  }

  m_config = config;
  return true;
}
//---------------------------------------------------------------------------
bool __fastcall TMainForm::ActivateHotKey(TShortCut hotKey)
{
  Word wKey;
  TShiftState ss;
  ShortCutToKey(hotKey, wKey, ss);

  word32 lMod = 0;
  if (ss.Contains(ssAlt))
    lMod |= MOD_ALT;
  if (ss.Contains(ssCtrl))
    lMod |= MOD_CONTROL;
  if (ss.Contains(ssShift))
    lMod |= MOD_SHIFT;

  if (!RegisterHotKey(Handle, 0, lMod, wKey)) {
    WString sMsg = TRLFormat("Could not register hot key %s.\nPlease try "
      "another key combination.", WString(ShortCutToText(hotKey)));
    if (m_blStartup)
      DelayStartupError(sMsg);
    else
      MsgBox(sMsg, MB_ICONERROR);
    return false;
  }

  m_blHotKeySet = true;
  return true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::DeactivateHotKey(void)
{
  if (m_blHotKeySet) {
    UnregisterHotKey(Handle, 0);
    m_blHotKeySet = false;
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CreateProfile(const WString& sProfileName,
                                         bool blSaveAdvancedOptions,
                                         int nCreateIdx)
{
  PWGenProfile* pProfile;

  if (nCreateIdx < 0)
    pProfile = new PWGenProfile;
  else
    pProfile = (PWGenProfile*) g_pProfileList->Items[nCreateIdx];

  pProfile->ProfileName = sProfileName;
  pProfile->IncludeChars = IncludeCharsCheck->Checked;
  pProfile->CharsLength = CharsLengthSpinBtn->Position;
  pProfile->CharSet = CharSetList->Text;
  pProfile->IncludeWords = IncludeWordsCheck->Checked;
  pProfile->WordsNum = WordsNumSpinBtn->Position;
  pProfile->WordListFileName = WLFNList->Text;
  pProfile->CombineWordsChars = CombineWordsCharsCheck->Checked;
  pProfile->SpecifyLength = SpecifyLengthCheck->Checked;
  pProfile->SpecifyLengthString = SpecifyLengthBox->Text;
  pProfile->FormatPassw = FormatPasswCheck->Checked;
  pProfile->FormatString = FormatList->Text;
  pProfile->PasswNum = StrToIntDef(PasswNumBox->Text, 0);
  pProfile->AdvancedOptionsUsed = blSaveAdvancedOptions;

  if (blSaveAdvancedOptions)
    pProfile->AdvancedPasswOptions = m_passwOptions;

  if (nCreateIdx < 0)
    g_pProfileList->Add(pProfile);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::LoadProfile(int nIndex)
{
  PWGenProfile* pProfile = (PWGenProfile*) g_pProfileList->Items[nIndex];

  IncludeCharsCheck->Checked = pProfile->IncludeChars;
  CharsLengthSpinBtn->Position = pProfile->CharsLength;
  CharSetList->Text = pProfile->CharSet;
  IncludeWordsCheck->Checked = pProfile->IncludeWords;
  WordsNumSpinBtn->Position = pProfile->WordsNum;
  WLFNList->Text = pProfile->WordListFileName;
  CombineWordsCharsCheck->Checked = pProfile->CombineWordsChars;
  SpecifyLengthCheck->Checked = pProfile->SpecifyLength;
  SpecifyLengthBox->Text = pProfile->SpecifyLengthString;
  FormatPasswCheck->Checked = pProfile->FormatPassw;
  FormatList->Text = pProfile->FormatString;
  FormatPasswInfoLbl->Caption = "";
  PasswNumBox->Text = WString(pProfile->PasswNum);
  //PasswNumBoxExit(this);

  if (pProfile->AdvancedOptionsUsed) {
    m_passwOptions = pProfile->AdvancedPasswOptions;
    PasswOptionsDlg->SetOptions(m_passwOptions);
    SetAdvancedBtnCaption();
    if (LoadTrigramFile(m_passwOptions.TrigramFileName) <= 0)
      m_passwOptions.TrigramFileName = "";
  }

  LoadCharSet(CharSetList->Text, true);
  LoadWordListFile(WLFNList->Text, true);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::DeleteProfile(int nIndex)
{
  delete (PWGenProfile*) g_pProfileList->Items[nIndex];
  g_pProfileList->Delete(nIndex);
}              
//---------------------------------------------------------------------------
void __fastcall TMainForm::RecreateProfileMenus(void)
{
  while (MainMenu_File_Profile->Count > 2) {
    delete MainMenu_File_Profile->Items[0];
    delete TrayMenu_Profile->Items[0];
  }

  for (int nI = 0; nI < g_pProfileList->Count; nI++) {
    TTntMenuItem* pMenuItem1 = new TTntMenuItem(MainMenu_File_Profile);
    pMenuItem1->Caption = FormatW("&%s %s", WString(PROFILES_MENU_SHORTCUTS[nI]),
      ((PWGenProfile*) g_pProfileList->Items[nI])->ProfileName);
    if (nI < sizeof(PROFILES_MENU_SHORTCUTS) - 1)
      pMenuItem1->ShortCut = ShortCut(PROFILES_MENU_SHORTCUTS[nI],
        TShiftState() << ssAlt << ssShift);
//    pMenuItem1->RadioItem = true;
    pMenuItem1->OnClick = MainMenu_File_ProfileClick;
    pMenuItem1->Tag = nI;

    MainMenu_File_Profile->Insert(nI, pMenuItem1);

    TTntMenuItem* pMenuItem2 = new TTntMenuItem(TrayMenu_Profile);
    pMenuItem2->Caption = pMenuItem1->Caption;
//    pMenuItem2->RadioItem = true;
    pMenuItem2->OnClick = MainMenu_File_ProfileClick;
    pMenuItem2->Tag = nI;

    TrayMenu_Profile->Insert(nI, pMenuItem2);
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ChangeGUIFont(const AnsiString& asFontName,
                                         int nFontSize)
{
  Tag = MAINFORM_TAG_REPAINTCOMBOBOXES;

  Font->Name = asFontName;
  Font->Size = nFontSize;

  SettingsGroup->Font->Name = asFontName;
  SettingsGroup->Font->Size = nFontSize;

  IncludeCharsCheck->Font->Name = asFontName;
  IncludeCharsCheck->Font->Size = nFontSize;

  CharsLengthLbl->Font = Font;
  CharsLengthBox->Font = Font;

  CharSetLbl->Font = Font;
  CharSetList->Font = Font;

  CharSetInfoLbl->Font->Name = asFontName;
  CharSetInfoLbl->Font->Size = nFontSize;

  IncludeWordsCheck->Font->Name = asFontName;
  IncludeWordsCheck->Font->Size = nFontSize;

  WordsNumLbl->Font = Font;

  WordsNumBox->Font = Font;

  WordListFileLbl->Font = Font;

  WLFNList->Font = Font;

  CombineWordsCharsCheck->Font = Font;

  SpecifyLengthCheck->Font = Font;
  SpecifyLengthBox->Font = Font;

  WordListInfoLbl->Font->Name = asFontName;
  WordListInfoLbl->Font->Size = nFontSize;

  FormatPasswCheck->Font->Name = asFontName;
  FormatPasswCheck->Font->Size = nFontSize;

  FormatList->Font = Font;

  MultiplePasswLbl->Font->Name = asFontName;
  MultiplePasswLbl->Font->Size = nFontSize;

  PasswNumBox->Font = Font;

  GenerateBtn2->Font = Font;

  AdvancedBtn->Font = Font;

  PasswGroup->Font->Name = asFontName;
  PasswGroup->Font->Size = nFontSize;

  GenerateBtn->Font->Name = asFontName;
  GenerateBtn->Font->Size = nFontSize;

  PasswInfoLbl->Font->Name = asFontName;
  PasswInfoLbl->Font->Size = nFontSize;

  RandomPoolGroup->Font->Name = asFontName;
  RandomPoolGroup->Font->Size = nFontSize;

  EntropyBitsLbl->Font = Font;

  // AboutForm
  AboutForm->Font = Font;

  AboutForm->CopyrightLbl->Font->Name = asFontName;
  AboutForm->CopyrightLbl->Font->Size = nFontSize;

  AboutForm->AuthorLbl->Font->Name = asFontName;
  AboutForm->AuthorLbl->Font->Size = nFontSize;

  AboutForm->WWWLbl->Font->Name = asFontName;
  AboutForm->WWWLbl->Font->Size = nFontSize;

  AboutForm->LanguageInfoLbl->Font->Name = asFontName;
  AboutForm->LanguageInfoLbl->Font->Size = nFontSize;

  AboutForm->ViewLicenseLbl->Font->Name = asFontName;
  AboutForm->ViewLicenseLbl->Font->Size = nFontSize;

  // CallbackForm
  CallbackForm->Font = Font;

  // ConfigurationDlg
  ConfigurationDlg->Font = Font;

  // CreateRandDataFileDlg
  CreateRandDataFileDlg->Font = Font;

  // CreateTrigramFileDlg
  CreateTrigramFileDlg->Font = Font;

  // PasswEnterDlg
  PasswEnterDlg->Font = Font;

  // PasswOptionsDlg
  PasswOptionsDlg->Font = Font;

  PasswOptionsDlg->InfoLbl->Font->Name = asFontName;
  PasswOptionsDlg->InfoLbl->Font->Size = nFontSize;

  // ProfileEditDlg
  ProfileEditDlg->Font = Font;

  // MPPasswGenDlg
  MPPasswGenDlg->Font = Font;

  MPPasswGenDlg->MasterPasswGroup->Font->Name = asFontName;
  MPPasswGenDlg->MasterPasswGroup->Font->Size = nFontSize;

  MPPasswGenDlg->EnterPasswBtn->Font->Name = asFontName;
  MPPasswGenDlg->EnterPasswBtn->Font->Size = nFontSize;

  MPPasswGenDlg->ClearKeyBtn->Font = Font;
  MPPasswGenDlg->PasswStatusLbl->Font = Font;
  MPPasswGenDlg->PasswStatusBox->Font = Font;
  MPPasswGenDlg->KeyExpiryInfoLbl->Font = Font;
  MPPasswGenDlg->KeyExpiryCountdownLbl->Font = Font;
  MPPasswGenDlg->ConfirmPasswCheck->Font = Font;
  MPPasswGenDlg->ShowPasswHashCheck->Font = Font;
  MPPasswGenDlg->KeyExpiryCheck->Font = Font;
  MPPasswGenDlg->KeyExpiryTimeBox->Font = Font;
  MPPasswGenDlg->HashapassCompatCheck->Font = Font;
  MPPasswGenDlg->ConfirmPasswCheck->Font = Font;

  MPPasswGenDlg->PasswGeneratorGroup->Font->Name = asFontName;
  MPPasswGenDlg->PasswGeneratorGroup->Font->Size = nFontSize;

  MPPasswGenDlg->ParameterLbl->Font = Font;
  MPPasswGenDlg->ParameterBox->Font = Font;
  MPPasswGenDlg->ClearParameterBtn->Font = Font;
  MPPasswGenDlg->CharSetLbl->Font = Font;

  MPPasswGenDlg->CharSetInfoLbl->Font->Name = asFontName;
  MPPasswGenDlg->CharSetInfoLbl->Font->Size = nFontSize;

  MPPasswGenDlg->CharSetList->Font = Font;
  MPPasswGenDlg->LengthLbl->Font = Font;
  MPPasswGenDlg->PasswLengthBox->Font = Font;

  MPPasswGenDlg->ResultingPasswLbl->Font->Name = asFontName;
  MPPasswGenDlg->ResultingPasswLbl->Font->Size = nFontSize;

  MPPasswGenDlg->GenerateBtn->Font->Name = asFontName;
  MPPasswGenDlg->GenerateBtn->Font->Size = nFontSize;

  // ProvideEntropyDlg
  ProvideEntropyDlg->Font = Font;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ShowInfoBox(const WString& sInfo)
{
  TTntHintWindow* pInfoBox = NULL;

  try {
    pInfoBox = new TTntHintWindow(this);

    TRect r = pInfoBox->CalcHintRect(Width, sInfo, NULL);
    int nBoxWidth = r.Width();
    int nBoxHeight = r.Height();

    r.left = Left + (Width - nBoxWidth) / 2;
    r.top = Top + Height / 2;
    r.right = r.left + nBoxWidth;
    r.bottom = r.top + nBoxHeight;

    pInfoBox->ActivateHint(r, sInfo);
    Sleep(std::min(400 + sInfo.Length() * 17, 1500));
  }
  __finally {
    if (pInfoBox != NULL) {
      pInfoBox->ReleaseHandle();
      delete pInfoBox;
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::UseKeySeededPRNG(void)
{
  g_pRandSrc = g_pKeySeededPRNG.get();
  m_passwGen.RandGen = g_pRandSrc;
  Caption = FormatW("%s (%s)", PROGRAM_NAME,
    TRL("WARNING: Random generator is deterministic (press F7 to deactivate)!"));
  TntApplication->Title = Caption;
  if (g_nAppState & APPSTATE_SYSTEMTRAY)
    TrayMessage(NIM_MODIFY);
  MainMenu_Tools_DetermRandGen->Enabled = true;

  ShowInfoBox(TRL("Deterministic random generator has been ACTIVATED."));
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::GeneratePassw(GeneratePasswDest dest)
{
  int nNumOfPassw = 1;
  WString sFileName;
  Word wFileOpenMode = fmCreate;

  if (dest == gpdGUIList || dest == gpdFileList) {
    nNumOfPassw = StrToIntDef(PasswNumBox->Text, 0);
    if (nNumOfPassw < 2 || nNumOfPassw > PASSW_MAX_NUM) {
//      PasswNumBox->SetFocus();
      return;
    }

    if (dest == gpdFileList) {
      SaveDlg->FilterIndex = 1;
      SaveDlg->Options >> ofOverwritePrompt;
      Tag = MAINFORM_TAG_DISABLETRAYPOPUP;
      bool blSuccess = SaveDlg->Execute();
      Tag = 0;
      SaveDlg->Options << ofOverwritePrompt;

      if (!blSuccess)
        return;

      sFileName = SaveDlg->FileName;

      if (WideFileExists(sFileName)) {
        switch (MsgBox(TRL("The selected file already exists. Do you\n"
          "want to append passwords to this file\n"
          "(existing passwords will be preserved),\n"
          "or do you want to completely overwrite it?\n\n"
          "Yes\t-> append passwords,\n"
          "No\t-> overwrite file,\n"
          "Cancel\t-> cancel process."), MB_ICONQUESTION + MB_YESNOCANCEL))
        {
        case IDYES:
          wFileOpenMode = fmOpenReadWrite; break;
        case IDCANCEL:
          return;
        }
      }
    }
  }

  int nCharsLen = 0, nNumOfWords = 0;
  int nCharSetSize;
  int nPassphrMinLength = -1, nPassphrMaxLength = -1;
  double dPasswSec = 0;

  if (IncludeCharsCheck->Checked) {
    nCharSetSize = m_passwGen.CustomCharSetW32.length();
    nCharsLen = CharsLengthSpinBtn->Position;
    if (m_passwOptions.Flags & PASSWOPTION_EACHCHARONLYONCE &&
          nCharsLen > nCharSetSize)
    {
      MsgBox(TRLFormat("If the option \"Each character must occur\nonly once\" is "
        "activated, the password length\nis limited to the size of the character set (%d).",
        nCharSetSize), MB_ICONWARNING);
      CharsLengthSpinBtn->Position = nCharSetSize;
      nCharsLen = nCharSetSize;
    }
    if (m_passwGen.CustomCharSetType == cstNormal &&
          (m_passwOptions.Flags & PASSWOPTION_EACHCHARONLYONCE))
      dPasswSec = m_passwGen.CalcPermSetEntropy(nCharSetSize, nCharsLen);
    else
      dPasswSec = m_passwGen.CustomCharSetEntropy * nCharsLen;
  }

  if (IncludeWordsCheck->Checked) {
    nNumOfWords = WordsNumSpinBtn->Position;
    if (SpecifyLengthCheck->Checked && !SpecifyLengthBox->Text.IsEmpty()) {
      AnsiString asText = SpecifyLengthBox->Text;
      int nLen = asText.Length();

      int nSepPos;
      if (nLen >= 2 && asText[1] == '>') {
        bool blGtEq = nLen >= 3 && asText[2] == '=';
        if (blGtEq)
          nPassphrMinLength = asText.SubString(3, nLen - 2).ToIntDef(-1);
        else
          nPassphrMinLength = asText.SubString(2, nLen - 1).ToIntDef(-2) + 1;
        nPassphrMaxLength = INT_MAX;
      }
      else if (nLen >= 2 && asText[1] == '<') {
        bool blLtEq = nLen >= 3 && asText[2] == '=';
        if (blLtEq)
          nPassphrMaxLength = asText.SubString(3, nLen - 2).ToIntDef(-1);
        else
          nPassphrMaxLength = asText.SubString(2, nLen - 1).ToIntDef(-1) - 1;
        nPassphrMinLength = 0;
      }
      else if ((nSepPos = asText.Pos("-")) >= 2) {
        nPassphrMinLength = asText.SubString(1, nSepPos - 1).ToIntDef(-1);
        nPassphrMaxLength = asText.SubString(nSepPos + 1, nLen - nSepPos).ToIntDef(-1);
      }
      else {
        nPassphrMinLength = nPassphrMaxLength = asText.ToIntDef(-1);
      }

      if (nPassphrMaxLength < nPassphrMinLength)
        std::swap(nPassphrMaxLength, nPassphrMinLength);

      if (nPassphrMinLength < 0 || nPassphrMaxLength < 0 ||
          nPassphrMaxLength + nPassphrMinLength == 0) {
        MsgBox(TRL("Passphrase: Invalid length range."), MB_ICONERROR);
        return;
        //nPassphrMinLength = -1;
      }
    }

    if (m_passwOptions.Flags & PASSWOPTION_EACHWORDONLYONCE &&
          nNumOfWords > m_passwGen.WordListSize)
    {
      MsgBox(TRLFormat("If the option \"Each word must occur only\nonce\" is "
        "activated, the number of words\nis limited to the size of the word list (%d).",
        m_passwGen.WordListSize), MB_ICONWARNING);
      WordsNumSpinBtn->Position = m_passwGen.WordListSize;
      nNumOfWords = m_passwGen.WordListSize;
    }
    if (m_passwOptions.Flags & PASSWOPTION_EACHWORDONLYONCE)
      dPasswSec += m_passwGen.CalcPermSetEntropy(m_passwGen.WordListSize, nNumOfWords);
    else
      dPasswSec += m_passwGen.WordListEntropy * nNumOfWords;
  }

  w32string sFormatPassw;
  if (FormatPasswCheck->Checked)
    sFormatPassw = WStringToW32String(FormatList->Text);

  if (nCharsLen == 0 && nNumOfWords == 0 && sFormatPassw.empty())
    return;

  SecureWString sPasswList;
  //TStringFileStreamW* pFile = NULL;

  //enum CallbackType { cbtNone, cbtPasswList, cbtRestrPassphr };

  //CallbackType callback;
  bool blCallback = false;
  int nPasswCnt = 0;
  int nPasswSec;

  try {
    try {
      int nFlags = m_passwOptions.Flags;
      bool blExcludeDuplicates = nFlags & PASSWOPTION_EXCLUDEDUPLICATES;
      int nCallbackFreq;

      if (nNumOfPassw > 1) {
        if (dest == gpdGUIList)
          PasswListForm->Close();

        if (blExcludeDuplicates || nPassphrMinLength >= 0 || nNumOfPassw > 5000)
        {
          blCallback = true;
          //callback = cbtPasswList;
          CallbackForm->Init(this, TRL("Generating password list ..."), TRL("%d of %d "
            "passwords generated."), nNumOfPassw);
          nCallbackFreq = (blExcludeDuplicates) ? 100 : 1000;
        }
        else
          Refresh();

        Screen->Cursor = (blCallback) ? crAppStart : crHourGlass;
      }

      int nPasswFlags = 0, nPassphrFlags = 0, nFormatFlags = 0;
      bool blFirstCharNotLC = nFlags & PASSWOPTION_FIRSTCHARNOTLC;

      SecureW32String sChars;
      if (nCharsLen != 0) {
        if (blFirstCharNotLC)
          nPasswFlags |= PASSW_FLAG_FIRSTCHARNOTLC;
        if (nFlags & PASSWOPTION_EXCLUDEREPCHARS)
          nPasswFlags |= PASSW_FLAG_EXCLUDEREPCHARS;
        if (nFlags & PASSWOPTION_INCLUDESUBSET)
          nPasswFlags |= PASSW_FLAG_INCLUDESUBSET;
        if (nFlags & PASSWOPTION_EACHCHARONLYONCE)
          nPasswFlags |= PASSW_FLAG_EACHCHARONLYONCE;
        if (nCharSetSize >= 128 && nCharsLen >= 128)
          nPasswFlags |= PASSW_FLAG_CHECKDUPLICATESBYSET;
        for (int nI = 0; nI < PASSWGEN_NUMINCLUDECHARSETS; nI++) {
          if (nFlags & (PASSWOPTION_INCLUDEUCL << nI))
            nPasswFlags |= PASSW_FLAG_INCLUDEUCL << nI;
        }
        if (m_passwGen.CustomCharSetType == cstPhoneticMixedCase)
          nPasswFlags |= PASSW_FLAG_PHONETICMIXEDCASE;

        sChars.New(nCharsLen + 1);
      }

      SecureW32String sWords;
      if (nNumOfWords != 0) {
        if (CombineWordsCharsCheck->Checked)
          nPassphrFlags |= PASSPHR_FLAG_COMBINEWCH;
        if (nFlags & PASSWOPTION_DONTSEPWORDS)
          nPassphrFlags |= PASSPHR_FLAG_DONTSEPWORDS;
        if (nFlags & PASSWOPTION_DONTSEPWORDSCHARS)
          nPassphrFlags |= PASSPHR_FLAG_DONTSEPWCH;
        if (nFlags & PASSWOPTION_REVERSEWCHORDER)
          nPassphrFlags |= PASSPHR_FLAG_REVERSEWCHORDER;
        if (nFlags & PASSWOPTION_EACHWORDONLYONCE)
          nPassphrFlags |= PASSPHR_FLAG_EACHWORDONLYONCE;

        if (nPassphrFlags & PASSPHR_FLAG_COMBINEWCH)
          nPasswFlags &= ~PASSW_FLAG_FIRSTCHARNOTLC;

        sWords.New(nCharsLen + nNumOfWords * (WORDLIST_MAX_WORDLEN + 2) + 1);
      }

      SecureW32String sFormatted;
      if (!sFormatPassw.empty()) {
        if (nFlags & PASSWOPTION_EXCLUDEREPCHARS)
          nFormatFlags |= PASSFORMAT_FLAG_EXCLUDEREPCHARS;

        sFormatted.New(PASSWFORMAT_MAX_CHARS + 1);
      }

      word32 lMaxPasswListBytes = (blExcludeDuplicates) ?
        PASSWLIST_MAX_BYTES / 2 : PASSWLIST_MAX_BYTES;
      word32 lPasswListWChars = 0;

      static const AnsiString asPasswListHeader = "%d passwords generated.\r\nSecurity of each "
        "password: %d bits.\r\nMaximum security of the entire list: %d bits.";
      int nPasswListHeaderLen;
      int nTotalPasswSec;

      // add system entropy and initialize the PRNG
      if (g_pRandSrc == m_pRandPool) {
        g_pEntropyMng->AddSystemEntropy();
        m_pRandPool->RandReady();
      }

      try {
        bool blFirstGen = true;
        int nCallbackCnt = 0;
        int nPassphrFailCnt = 0;
        std::set<SecureWString> uniquePasswList;
        std::auto_ptr<TStringFileStreamW> pFile;

        while (nPasswCnt < nNumOfPassw) {

          if (blCallback && nCallbackCnt++ == nCallbackFreq) {
            CallbackForm->Callback(nPasswCnt);
            nCallbackCnt = 1;
          }

          int nPasswLen;

          if (nCharsLen != 0) {
            switch (m_passwGen.CustomCharSetType) {
            case cstNormal:
              nPasswLen = m_passwGen.GetPassword(sChars, nCharsLen, nPasswFlags);
              break;
            case cstPhonetic:
            case cstPhoneticMixedCase:
              nPasswLen = m_passwGen.GetPhoneticPassw(sChars, nCharsLen,
                nPasswFlags);
            }
          }

          if (nNumOfWords != 0) {
            nPasswLen = m_passwGen.GetPassphrase(sWords, nNumOfWords, sChars, nPassphrFlags);
            if (nPassphrMinLength >= 0 && (nPasswLen < nPassphrMinLength ||
                nPasswLen > nPassphrMaxLength)) {
              if (!blCallback && ++nPassphrFailCnt == 1000) {
                //callback = cbtRestrPassphr;
                blCallback = true;
                CallbackForm->Init(this, TRL("Generating passphrase ..."),
                  TRL("%d of %d passphrases generated."), nNumOfPassw);
                nCallbackFreq = 1000;
                Screen->Cursor = crAppStart;
              }
              continue;
            }
          }

          word32* pPassw = (nNumOfWords != 0) ? sWords : sChars;

          if (pPassw != NULL && blFirstCharNotLC && pPassw[0] >= 'a' && pPassw[0] <= 'z')
            pPassw[0] = toupper(pPassw[0]);

          if (!sFormatPassw.empty()) {
            double dFormatSec = 0;
            double* pdSec = (blFirstGen) ? &dFormatSec : NULL;
            word32 lInvalidSpec;
            int nPasswPhUsed, nFormattedLen;
            nFormattedLen = m_passwGen.GetFormatPassw(sFormatted,
              PASSWFORMAT_MAX_CHARS, sFormatPassw.c_str(), nFormatFlags, pPassw,
              &nPasswPhUsed, &lInvalidSpec, pdSec);

            if (blFirstGen) {
              if (nFormattedLen == 0)
                throw Exception(ETRL("Format string produces empty password"));

              dPasswSec += dFormatSec;
              FormatPasswInfoLbl->Caption = "";

              if (nPasswPhUsed == PASSFORMAT_PWUSED_NOTUSED && pPassw != NULL) {
                dPasswSec = dFormatSec;
                sChars.Empty();
                sWords.Empty();
                nCharsLen = nNumOfWords = 0;
                FormatPasswInfoLbl->Caption = TRL("\"%P\" is not specified.");
              }
              else if (nPasswPhUsed == PASSFORMAT_PWUSED_EMPTYPW)
                FormatPasswInfoLbl->Caption = WString("\"%P\": ") +
                  TRL("Password not available.");
              else if (nPasswPhUsed > 0 && nPasswPhUsed < nPasswLen)
                FormatPasswInfoLbl->Caption = WString("\"%P\": ") +
                  TRL("Password too long.");
              else if (lInvalidSpec != 0) {
                w32string sW32Char(1, lInvalidSpec);
                WString sWChar = W32StringToWString(sW32Char);
                FormatPasswInfoLbl->Caption = TRLFormat("Invalid format specifier "
                  "\"%%%s\".", sWChar);
              }
            }
            pPassw = sFormatted;
            nPasswLen = nFormattedLen;
          }

          if (blFirstGen) {
            nPasswSec = std::min(Floor(dPasswSec), int(RandomPool::MAX_ENTROPY));

            if (dest == gpdGUIList) {
              nTotalPasswSec = Floor(std::min<double>(dPasswSec * nNumOfPassw,
                RandomPool::MAX_ENTROPY));

              WString sHeader = TRLFormat(asPasswListHeader,
                nNumOfPassw, nPasswSec, nTotalPasswSec) + WString("\r\n\r\n");
              nPasswListHeaderLen = sHeader.Length();

              word32 lEstSizeWChars = nPasswListHeaderLen +
                (GetNumOfUtf16Chars(pPassw) + 2) * nNumOfPassw + 1;
              if (lEstSizeWChars * sizeof(wchar_t) > lMaxPasswListBytes)
                throw Exception(ETRL("The estimated list size will probably exceed\n"
                  "the internal memory limit.\nPlease reduce the number of passwords"));

              sPasswList.New(lEstSizeWChars);

              wcscpy(sPasswList, sHeader.c_bstr());
              lPasswListWChars = nPasswListHeaderLen;
            }
            else if (dest == gpdFileList) {
              pFile.reset(new TStringFileStreamW(sFileName, wFileOpenMode,
                g_fileEncoding, PASSW_MAX_BYTES));
              if (wFileOpenMode == fmOpenReadWrite) {
                pFile->FileEnd();
              }
            }

            blFirstGen = false;
          }

          wchar_t* pwszPassw = (wchar_t*) pPassw;
          W32CharToWCharInternal(pwszPassw);
          int nPasswLenWChars = wcslen(pwszPassw);
          int nBytesWritten;

          /*SecureWString sPasswListEntry;
          if (dest == gpdGUIList || dest == gpdFileList) {
            sPasswListEntry.New(nPasswLenWChars + 3);
            wcscpy(sPasswListEntry, pwszPassw);
            wcscat(sPasswListEntry, CRLF);
          }*/

          if (nNumOfPassw > 1 && blExcludeDuplicates) {
            std::pair<std::set<SecureWString>::iterator, bool> ret =
              uniquePasswList.insert(SecureWString(pwszPassw, nPasswLenWChars));
            if (!ret.second)
              continue;
          }
          else if (nNumOfPassw == 1 && blCallback) {
            CallbackForm->Terminate();
            blCallback = false;
            Screen->Cursor = crDefault;
            nPassphrFailCnt = 0;
            nCallbackCnt = 0;
          }

          bool blBreakLoop = false;
          switch (dest) {
          int nTemp;
          case gpdGUISingle:
            nTemp = PasswBox->Tag;
            PasswBox->Tag = 0;
            ClearEditBoxTextBuf(PasswBox);
            SetEditBoxTextBuf(PasswBox, (wchar_t*) pwszPassw);
            PasswBox->Tag = nTemp;
            ShowPasswInfo(nPasswLen, nPasswSec);
            PasswInfoLbl->Font->Color = clNavy;
            PasswBox->SetFocus();
            break;

          case gpdGUIList:
            if (lPasswListWChars + nPasswLenWChars + 2 >= sPasswList.Size()) {
              word32 lNewSizeWChars = double(lPasswListWChars) / nPasswCnt * nNumOfPassw +
                nPasswLenWChars + 3;
              if (lNewSizeWChars * sizeof(wchar_t) > lMaxPasswListBytes) {
                PasswNumBox->Text = WString(nPasswCnt);
                MsgBox(TRLFormat("The memory limit of the password list has\nbeen "
                  "reached.\n\nThe number of passwords has been\n"
                  "reduced to %d.", nPasswCnt), MB_ICONWARNING);
                blBreakLoop = true;
                break;
              }
              sPasswList.Grow(lNewSizeWChars);
            }

            wcscpy(sPasswList + lPasswListWChars, pwszPassw);
            lPasswListWChars += nPasswLenWChars;
            wcscpy(sPasswList + lPasswListWChars, CRLF);
            lPasswListWChars += 2;

            break;

          case gpdFileList:

            if (!pFile->WriteString(pwszPassw, nPasswLenWChars, nBytesWritten))
  //              blExcludeDuplicates))
              OutOfDiskSpaceError();

            /*if (nBytesWritten < 0)
              continue;*/

            if (!pFile->WriteString(CRLF, 2, nBytesWritten))
              OutOfDiskSpaceError();

            break;

          case gpdMsgBox:

            if (nPasswLen > 1000)
              MsgBox(TRL("Password is too long to show it in a\nmessage box like this.\n\n"
                "It has been copied to the clipboard."),
                MB_ICONWARNING);
            else {
              SecureWString sPasswMsg;
              FormatW_Secure(sPasswMsg,
                TRL("The generated password is:\n\n%s\n\nThe estimated "
                "security is %d bits.\n\nYes\t-> copy password to clipboard,\n"
                "No\t-> generate new password,\nCancel\t-> cancel process."),
                pwszPassw, nPasswSec);

              switch (MessageBoxW(Application->Handle, sPasswMsg, PROGRAM_NAME,
                MB_ICONINFORMATION + MB_YESNOCANCEL)) {
              case IDCANCEL:
                blBreakLoop = true;
                break;
              case IDNO:
                continue;
              }
            }
            // no break here!

          case gpdClipboard:

            Clipboard()->Clear();
            SetClipboardTextBuf(pwszPassw, NULL);
            CopiedSensitiveDataToClipboard();
          }

          if (blBreakLoop)
            break;

          nPasswCnt++;
        }
      }
      catch (ECallback& e) {
        if (nNumOfPassw > 1)
          MsgBox(UTF8Decode(e.Message) + WString(".\n\n") + TRLFormat(
            "%d passwords generated.", nPasswCnt), MB_ICONWARNING);
      }

      if (g_pRandSrc == m_pRandPool) {
        m_pRandPool->Flush();

        nTotalPasswSec = Floor(std::min<double>(dPasswSec * nPasswCnt,
          RandomPool::MAX_ENTROPY));

        g_pEntropyMng->ConsumeEntropyBits(nTotalPasswSec);
        UpdateEntropyProgress();
      }

      Refresh();

      //if (pFile != NULL)
      //  delete pFile;

      if (nNumOfPassw > 1 && nPasswCnt > 0) {
        if (blCallback)
          CallbackForm->Callback(nPasswCnt);

        if (dest == gpdGUIList) {
          if (blCallback) {
            CallbackForm->ProgressLbl->Caption = TRL("Copying password list ...");
            CallbackForm->Refresh();
          }

          int nStrOffset = 0;

          if (nPasswCnt < nNumOfPassw) {
            WString sNewHeader = TRLFormat(asPasswListHeader,
              nPasswCnt, nPasswSec, nTotalPasswSec) + WString("\r\n\r\n");
            int nNewHeaderLen = sNewHeader.Length();
            nStrOffset = nPasswListHeaderLen - nNewHeaderLen;

            wcsncpy(sPasswList + nStrOffset, sNewHeader.c_bstr(), nNewHeaderLen);
          }

          sPasswList[lPasswListWChars - 2] = '\0';

          SetEditBoxTextBuf(PasswListForm->PasswList, sPasswList + nStrOffset);
          sPasswList.Empty();
        }
        else {
          MsgBox(TRLFormat("File \"%s\" successfully created.\n\n%d passwords "
            "written.", WideExtractFileName(SaveDlg->FileName), nPasswCnt),
            MB_ICONINFORMATION);
        }

        if (blCallback) {
          CallbackForm->Terminate();
          blCallback = false;
        }

        Screen->Cursor = crDefault;

        if (dest == gpdGUIList)
          PasswListForm->Execute();
      }
      else if (blCallback) {
        CallbackForm->Terminate();
        blCallback = false;
        Screen->Cursor = crDefault;
      }
    }
    catch (std::exception& e) {
      throw Exception(CppStdExceptionToString(&e));
    }
  }
  catch (Exception& e) {
    WString sMsg = TRLFormat("An error has occurred during password generation:\n%s.",
      UTF8Decode(e.Message));
    //if (pFile != NULL) {
    if (dest == gpdFileList) {
      //delete pFile;
      sMsg += WString("\n\n") + TRLFormat("%d passwords written to file \"%s\".",
        nPasswCnt, WideExtractFileName(SaveDlg->FileName));
    }
    MsgBox(sMsg, MB_ICONERROR);
    m_pRandPool->Flush();
    if (blCallback)
      CallbackForm->Terminate();
    Screen->Cursor = crDefault;
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::GenerateBtnClick(TObject *Sender)
{
  GeneratePasswDest dest;

  if (Sender == GenerateBtn)
    dest = gpdGUISingle;
  else if (Sender == GenerateBtn2)
    dest = gpdGUIList;
  else if (Sender == GenerateBtn3)
    dest = gpdFileList;
  else if (Sender == TrayMenu_GenPassw)
    dest = gpdClipboard;
  else
    dest = gpdMsgBox;

  GeneratePassw(dest);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::IncludeCharsCheckClick(TObject *Sender)
{
  bool blChecked1 = IncludeCharsCheck->Checked;
  bool blChecked2 = IncludeWordsCheck->Checked;
  bool blChecked3 = FormatPasswCheck->Checked;

  CharsLengthLbl->Enabled = blChecked1;
  CharsLengthBox->Enabled = blChecked1;
  CharsLengthSpinBtn->Enabled = blChecked1;
  CombineWordsCharsCheck->Enabled = blChecked1 && blChecked2;

  WordsNumLbl->Enabled = blChecked2;
  WordsNumBox->Enabled = blChecked2;
  WordsNumSpinBtn->Enabled = blChecked2;
  SpecifyLengthCheck->Enabled = blChecked2;
  SpecifyLengthBox->Enabled = blChecked2 && SpecifyLengthCheck->Checked;

  FormatList->Enabled = blChecked3;
  FormatPasswInfoLbl->Enabled = blChecked3;
//  FormatPasswHelpBtn->Visible = blChecked3;

  bool blEnableGen = blChecked1 || blChecked2 || blChecked3;
  PasswNumBox->Enabled = blEnableGen;
  GenerateBtn->Enabled = blEnableGen;
  GenerateBtn2->Enabled = blEnableGen;
  GenerateBtn3->Visible = blEnableGen;
  PasswNumBox->Enabled = blEnableGen;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CharSetInfoBtnClick(TObject *Sender)
{
  CharSetListExit(this);

  // insert line breaks
  w32string sCharsW32 = m_passwGen.CustomCharSetW32;
  int nLineBreaks = (sCharsW32.length() - 1) / 40;
  for (int nI = 0; nI < nLineBreaks; nI++)
    sCharsW32.insert((nI + 1) * 40 + nI, 1, '\n');

  WString sCharsW16 = W32StringToWString(sCharsW32);
  if (m_passwGen.CustomCharSetType == cstPhonetic ||
      m_passwGen.CustomCharSetType == cstPhoneticMixedCase) {
    WString sSource;
    if (m_passwOptions.TrigramFileName.IsEmpty())
      sSource = TRL("default (English) trigrams");
    else
      sSource = TRLFormat("File \"%s\"", m_passwOptions.TrigramFileName);
    sCharsW16 += WString("\n\n") + TRLFormat("(phonetic, based on trigram frequencies\n"
      "from the following source:\n<%s>)", sSource);
  }

  WString sMsg;
  if (m_blCharSetError)
    sMsg = TRL("The character set you entered is invalid.\nIt must contain at least "
      "2 different characters.") + WString("\n\n");
  sMsg += FormatW("%s\n\n%s\n\n%s.",
    TRL("Currently loaded character set:"), sCharsW16, m_sCharSetInfo);
  MsgBox(sMsg, MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ToggleRandPoolBtnClick(TObject *Sender)
{
  m_blShowEntProgress = !ToggleRandPoolBtn->Down;
  EntropyProgress->Visible = m_blShowEntProgress;
  EntropyBitsLbl->Visible = m_blShowEntProgress;
  UpdateEntropyProgress();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::BrowseBtnClick(TObject *Sender)
{
  BrowseBtn->Refresh();
  OpenDlg->FilterIndex = 1;
  OpenDlg->Title = TRL("Select word list file");
  Tag = MAINFORM_TAG_DISABLETRAYPOPUP;
  if (OpenDlg->Execute())
    WLFNList->Text = OpenDlg->FileName;
  Tag = 0;
  WLFNListExit(this);
  WLFNList->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ClearClipBtnClick(TObject *Sender)
{
  Clipboard()->Clear();

  ShowInfoBox(TRL("Clipboard cleared."));
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MPPasswGenBtnClick(TObject *Sender)
{
  if (g_nAppState & APPSTATE_HIDDEN)
    ShowWindow(Application->Handle, SW_SHOW);
  if (MPPasswGenDlg->Visible)
    ShowWindow(MPPasswGenDlg->Handle, SW_SHOW);
  else
    MPPasswGenDlg->Show();
  MPPasswGenDlg->WindowState = wsNormal;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CryptTextBtnMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
  if (Button == mbRight)
    CryptText(false);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CryptTextBtnClick(TObject *Sender)
{
  CryptText(true);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::EntropyProgressMenu_ResetCountersClick(TObject *Sender)
{
  g_pEntropyMng->ResetCounters();
  UpdateEntropyProgress();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Help_AboutClick(TObject *Sender)
{
  AboutForm->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Options_LanguageItemClick(TObject *Sender)
{
  TTntMenuItem* pLangItem = (TTntMenuItem*) Sender;

  if (pLangItem->Checked)
    return;

  if (CompareVersions(pLangItem->Hint, PROGRAM_LANGVER_MIN) < 0) {
    if (MsgBox(TRLFormat("The version of this language (%s) is not\ncompatible "
        "with this program version.\nThis version of PWGen requires a language\n"
        "version of at least %s.\n\nDo you want to use it anyway?",
        WString(pLangItem->Hint), PROGRAM_LANGVER_MIN), MB_ICONWARNING +
        MB_YESNO + MB_DEFBUTTON2) == IDNO)
      return;
  }
  else if (CompareVersions(pLangItem->Hint, PROGRAM_VERSION) > 0) {
    if (MsgBox(TRLFormat("The version of this language (%s) is higher\nthan "
        "the version of this program (%s).\nTherefore, version incompatibilities "
        "may occur.\n\nDo you want to use it anyway?",
        WString(pLangItem->Hint), PROGRAM_VERSION), MB_ICONWARNING +
        MB_YESNO + MB_DEFBUTTON2) == IDNO)
      return;
  }

  pLangItem->Checked = true;

  if (MsgBox(TRL("The language file will be loaded when you\nrestart the program.\n\n"
      "Do you want to save the settings and\nrestart the program now?"),
      MB_ICONQUESTION + MB_YESNO) == IDYES)
  {
    m_blRestart = true;
    Close();
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Options_SaveSettingsNowClick(TObject *Sender)
{
  SaveConfig();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MyNotify(TMessage& msg)
{
  POINT pos;
  int nEntBits = 0;

  switch (msg.LParam) {
  case WM_LBUTTONDBLCLK:
    nEntBits = g_pEntropyMng->AddEvent(msg, entMouseClick, ENTROPY_MOUSECLICK / 2);
    if (g_nAppState & APPSTATE_MINIMIZED)
      Application->Restore();
    else
      Application->BringToFront();
    break;

  case WM_RBUTTONDOWN:
    GetCursorPos(&pos);
    nEntBits = g_pEntropyMng->AddEvent(msg, entMouseClick, ENTROPY_MOUSECLICK / 2);
    TrayMenu->PopupComponent = this;
    TrayMenu->Popup(pos.x, pos.y);
  }

  if (nEntBits != 0)
    UpdateEntropyProgress();
}
//---------------------------------------------------------------------------
bool __fastcall TMainForm::TrayMessage(DWORD dwMessage)
{
  if (Win32PlatformIsUnicode) {
    NOTIFYICONDATAW tnd;

    tnd.cbSize = sizeof(tnd);
    tnd.hWnd = Handle;
    tnd.uID = IDC_MYICON;
    tnd.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
    tnd.uCallbackMessage = MYWM_NOTIFY;

    if (dwMessage == NIM_MODIFY) {
      tnd.hIcon = (HICON) LoadImage(HInstance, "MAINICON", IMAGE_ICON, 16, 16, 0);
      wcsncpy(tnd.szTip, Caption.c_bstr(), sizeof(tnd.szTip) / sizeof(wchar_t));
    }
    else {
      tnd.hIcon = NULL;
      tnd.szTip[0] = '\0';
    }

    return Shell_NotifyIconW(dwMessage, &tnd);
  }
  else {
    NOTIFYICONDATAA tnd;

    tnd.cbSize = sizeof(tnd);
    tnd.hWnd = Handle;
    tnd.uID = IDC_MYICON;
    tnd.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
    tnd.uCallbackMessage = MYWM_NOTIFY;

    if (dwMessage == NIM_MODIFY) {
      tnd.hIcon = (HICON) LoadImage(HInstance, "MAINICON", IMAGE_ICON, 16, 16, 0);

      AnsiString asTitle = Caption;
      strncpy(tnd.szTip, asTitle.c_str(), sizeof(tnd.szTip));
    }
    else {
      tnd.hIcon = NULL;
      tnd.szTip[0] = '\0';
    }

    return Shell_NotifyIconA(dwMessage, &tnd);
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::AppMessage(MSG& msg,
                                      bool& blHandled)
{
  static int nMouseMoveCnt = 60, nMouseWheelCnt = 0;
  int nEntBits = 0;

  switch (msg.message) {
  case WM_LBUTTONDBLCLK:
  case WM_LBUTTONDOWN:
  case WM_MBUTTONDBLCLK:
  case WM_MBUTTONDOWN:
  case WM_RBUTTONDBLCLK:
  case WM_RBUTTONDOWN:
    nEntBits = g_pEntropyMng->AddEvent(msg, entMouseClick, ENTROPY_MOUSECLICK);
    break;

  case WM_MOUSEMOVE:
    if (nMouseMoveCnt-- == 0) {
      nEntBits = g_pEntropyMng->AddEvent(msg, entMouseMove, ENTROPY_MOUSEMOVE);
      nMouseMoveCnt = 50 + fprng_rand() % 50;
    }
    break;

  case WM_MOUSEWHEEL:
    if (nMouseWheelCnt-- == 0) {
      nEntBits = g_pEntropyMng->AddEvent(msg, entMouseWheel, ENTROPY_MOUSEWHEEL);
      nMouseWheelCnt = fprng_rand() % 10;
    }
    break;

  case WM_KEYDOWN:
    nEntBits = g_pEntropyMng->AddEvent(msg, entKeyboard, ENTROPY_KEYBOARD);
  }

  if (nEntBits != 0)
    UpdateEntropyProgress();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::AppException(TObject* Sender, Sysutils::Exception* E)
{
  // this should not happen...
  // maybe it's better not to translate this message to avoid further errors...?
  MessageBoxW(Application->Handle, FormatW("Sorry, this should not have happened.\n"
    "The following error has not been handled\nproperly by the application:\n\n\"%s\"\n\n"
    "It is recommended to restart the program\nto avoid an undefined behavior.\n\n"
    "Please report this error to %s.\nThank you!", UTF8Decode(E->Message),
    PROGRAM_AUTHOR_EMAIL), L"Unhandled exception", MB_ICONERROR);

  // is it really necessary to terminate the program? No...
//  Application->Terminate();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::AppMinimize(TObject* Sender)
{
  if (m_config.MinimizeToSysTray) {
    if (!(g_nAppState & APPSTATE_SYSTEMTRAY)) {
      TrayMessage(NIM_ADD);
      TrayMessage(NIM_MODIFY);
      g_nAppState |= APPSTATE_SYSTEMTRAY;
    }
    ShowWindow(Application->Handle, SW_HIDE);
    g_nAppState |= APPSTATE_HIDDEN;
  }

  //m_blMinimized = true;
  g_nAppState |= APPSTATE_MINIMIZED;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::AppRestore(TObject* Sender)
{
  if (m_config.MinimizeToSysTray) {
    if (!m_config.ShowSysTrayIconConst) {
      TrayMessage(NIM_DELETE);
      g_nAppState &= ~APPSTATE_SYSTEMTRAY;
      //m_blSystemTray = false;
    }
    ShowWindow(Application->Handle, SW_SHOW);
    if (!MPPasswGenDlg->Visible)
      ShowWindow(MPPasswGenDlg->Handle, SW_HIDE);
    Application->BringToFront();
    g_nAppState &= ~APPSTATE_HIDDEN;
  }

  //m_blMinimized = false;
  g_nAppState &= ~APPSTATE_MINIMIZED;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::AppDeactivate(TObject* Sender)
{
  TopMostManager::GetInstance()->OnAppDeactivate();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TrayMenu_RestoreClick(TObject *Sender)
{
  Application->Restore();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TrayMenu_EncryptClipClick(TObject *Sender)
{
  CryptText(true);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TrayMenu_DecryptClipClick(TObject *Sender)
{
  CryptText(false);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TrayMenu_ExitClick(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TimerTick(TObject *Sender)
{
  static int nTouchPoolCnt = 0, nRandomizeCnt = 0, nMovePoolCnt = 0,
             nWriteSeedFileCnt = 0;

  if (++nTouchPoolCnt == TIMER_TOUCHPOOL) {
    m_pRandPool->TouchPool();
    nTouchPoolCnt = 0;
  }

  if (++nRandomizeCnt == TIMER_RANDOMIZE) {
    g_pEntropyMng->AddSystemEntropy();
    UpdateEntropyProgress();
    nRandomizeCnt = 0;
  }

  if (++nMovePoolCnt == TIMER_MOVEPOOL) {
    // take the opportunity to reseed the fast PRNG
    fprng_randomize();

    m_pRandPool->MovePool();
    nMovePoolCnt = 0;
  }

  if (++nWriteSeedFileCnt == TIMER_WRITESEEDFILE) {
    WriteRandSeedFile(false);
    nWriteSeedFileCnt = 0;
  }

  if (m_nAutoClearClipCnt > 0 && --m_nAutoClearClipCnt == 0)
    Clipboard()->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::HelpBtnClick(TObject *Sender)
{
  ExecuteShellOp(m_sHelpFileName);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::SetAdvancedBtnCaption(void)
{
  static WString sAdvanced;
  WString sCaption;

  if (sAdvanced.IsEmpty())
    sAdvanced = TRL("Advanced");

  int nI;
  for (nI = 0; nI < PASSWOPTIONS_NUM; nI++) {
    if (PASSWOPTIONS_STARRED[nI] && m_passwOptions.Flags & (1 << nI))
      break;
  }

  sCaption = sAdvanced;

  if (nI < PASSWOPTIONS_NUM)
    sCaption += WString("(!)");

  AdvancedBtn->Caption = sCaption;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::AdvancedBtnClick(TObject *Sender)
{
  if (PasswOptionsDlg->ShowModal() == mrOk) {
    PasswOptions old = m_passwOptions;

    PasswOptionsDlg->GetOptions(m_passwOptions);

    if (m_passwOptions.MaxWordLen != old.MaxWordLen ||
        (m_passwOptions.Flags & PASSWOPTION_LOWERCASEWORDS) !=
        (old.Flags & PASSWOPTION_LOWERCASEWORDS))
      LoadWordListFile(WLFNList->Text, true);

    if (!WideSameText(m_passwOptions.TrigramFileName, old.TrigramFileName)) {
      if (LoadTrigramFile(m_passwOptions.TrigramFileName) <= 0)
        m_passwOptions.TrigramFileName = old.TrigramFileName;
    }

    LoadCharSet(CharSetList->Text, true);
    SetAdvancedBtnCaption();
  }
  else
    PasswOptionsDlg->SetOptions(m_passwOptions);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ListMenuPopup(TObject *Sender)
{
  TTntComboBox* pBox = (TTntComboBox*) ListMenu->PopupComponent;
  HWND hChild = GetWindow(pBox->Handle, GW_CHILD);

  bool blSelected = pBox->SelLength > 0;

  if (Win32PlatformIsUnicode) {
    ListMenu_Undo->Enabled = SendMessageW(hChild, EM_CANUNDO, 0, 0);
    ListMenu_SelectAll->Enabled = SendMessageW(hChild, WM_GETTEXTLENGTH, 0, 0) > 0;
  }
  else {
    ListMenu_Undo->Enabled = SendMessageA(hChild, EM_CANUNDO, 0, 0);
    ListMenu_SelectAll->Enabled = SendMessageA(hChild, WM_GETTEXTLENGTH, 0, 0) > 0;
  }
  ListMenu_Cut->Enabled = blSelected;
  ListMenu_Copy->Enabled = blSelected;
  ListMenu_Paste->Enabled = Clipboard()->HasFormat(CF_TEXT);
  ListMenu_Delete->Enabled = blSelected;
  ListMenu_ClearList->Enabled = pBox->Items->Count > 0;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ListMenu_UndoClick(TObject *Sender)
{
  if (Win32PlatformIsUnicode)
    SendMessageW(GetWindow(((TTntComboBox*) ListMenu->PopupComponent)->Handle,
      GW_CHILD), WM_UNDO, 0, 0);
  else
    SendMessageA(GetWindow(((TTntComboBox*) ListMenu->PopupComponent)->Handle,
      GW_CHILD), WM_UNDO, 0, 0);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ListMenu_CutClick(TObject *Sender)
{
  if (Win32PlatformIsUnicode)
    SendMessageW(((TTntComboBox*) ListMenu->PopupComponent)->Handle, WM_CUT, 0, 0);
  else
    SendMessageA(((TTntComboBox*) ListMenu->PopupComponent)->Handle, WM_CUT, 0, 0);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ListMenu_CopyClick(TObject *Sender)
{
  if (Win32PlatformIsUnicode)
    SendMessageW(((TTntComboBox*) ListMenu->PopupComponent)->Handle, WM_COPY, 0, 0);
  else
    SendMessageA(((TTntComboBox*) ListMenu->PopupComponent)->Handle, WM_COPY, 0, 0);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ListMenu_PasteClick(TObject *Sender)
{
  if (Win32PlatformIsUnicode)
    SendMessageW(((TTntComboBox*) ListMenu->PopupComponent)->Handle, WM_PASTE, 0, 0);
  else
    SendMessageA(((TTntComboBox*) ListMenu->PopupComponent)->Handle, WM_PASTE, 0, 0);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ListMenu_DeleteClick(TObject *Sender)
{
  ((TTntComboBox*) ListMenu->PopupComponent)->SelText = "";
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ListMenu_SelectAllClick(TObject *Sender)
{
  ((TTntComboBox*) ListMenu->PopupComponent)->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ListMenu_ClearListClick(TObject *Sender)
{
  if (((TTntComboBox*) ListMenu->PopupComponent)->Items->Count > 0) {
    if (MsgBox(TRL("All entries will be removed from the list.\nAre you sure?"),
        MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDYES)
      ((TTntComboBox*) ListMenu->PopupComponent)->Clear();
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CharSetListEnter(TObject *Sender)
{
  ListMenu->PopupComponent = CharSetList;
  ListMenuPopup(this);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::WLFNListEnter(TObject *Sender)
{
  ListMenu->PopupComponent = WLFNList;
  ListMenuPopup(this);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CharSetListKeyPress(TObject *Sender, char &Key)
{
  if (Key == VK_RETURN) {
    CharSetInfoBtnClick(this);
    Key = 0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswNumBoxKeyPress(TObject *Sender, char &Key)
{
  if (Key == VK_RETURN) {
    GeneratePassw(gpdGUIList);
    Key = 0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxKeyPress(TObject *Sender, char &Key)
{
  if (Key == VK_RETURN) {
    GeneratePassw(gpdGUISingle);
    Key = 0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CharSetListExit(TObject *Sender)
{
  if (CharSetList->Text != m_sCharSetInput)
    LoadCharSet(CharSetList->Text, true);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenu_CopyClick(TObject *Sender)
{
  PasswBox->CopyToClipboard();
  CopiedSensitiveDataToClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenu_SelectAllClick(TObject *Sender)
{
  PasswBox->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenu_ChangeFontClick(TObject *Sender)
{
  FontDlg->Font = PasswBox->Font;
  Tag = MAINFORM_TAG_DISABLETRAYPOPUP;
  if (FontDlg->Execute()) {
    PasswBox->Font = FontDlg->Font;
    MPPasswGenDlg->PasswBox->Font = FontDlg->Font;
  }
  Tag = 0;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TogglePasswBtnClick(TObject *Sender)
{
  int nTemp = PasswBox->Tag;
  PasswBox->Tag = 0;
  PasswBox->PasswordChar = (TogglePasswBtn->Down) ? PASSWORD_CHAR : '\0';
  PasswBox->Tag = nTemp;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CharsLengthBoxExit(TObject *Sender)
{
  int nValue = StrToIntDef(CharsLengthBox->Text, 0);

  if (nValue < CharsLengthSpinBtn->Min || nValue > CharsLengthSpinBtn->Max)
    CharsLengthBox->Text = WString(CharsLengthSpinBtn->Position);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::WordsNumBoxExit(TObject *Sender)
{
  int nValue = StrToIntDef(WordsNumBox->Text, 0);

  if (nValue < WordsNumSpinBtn->Min || nValue > WordsNumSpinBtn->Max)
    WordsNumBox->Text = WString(WordsNumSpinBtn->Position);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Help_VisitWebsiteClick(TObject *Sender)
{
  ExecuteShellOp(PROGRAM_URL_WEBSITE);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Help_DonateClick(TObject *Sender)
{
  ExecuteShellOp(PROGRAM_URL_DONATE);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswNumBoxExit(TObject *Sender)
{
  int nValue = StrToIntDef(PasswNumBox->Text, 0);

  if (nValue < 2)
    PasswNumBox->Text = WString("2");
  else if (nValue > PASSW_MAX_NUM)
    PasswNumBox->Text = WString(PASSW_MAX_NUM);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormatListExit(TObject *Sender)
{
  WString sInput = FormatList->Text;
  if (!sInput.IsEmpty())
    AddEntryToList(FormatList, sInput, true);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::WLFNListExit(TObject *Sender)
{
  WString sFileName = WLFNList->Text;

  if (sFileName.IsEmpty() || WideSameText(sFileName, WLFNLIST_DEFAULT))
    LoadWordListFile("", true, m_sWLFileName.IsEmpty());
  else
    LoadWordListFile(sFileName, true, WideSameText(sFileName, m_sWLFileName));
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::WordListInfoBtnClick(TObject *Sender)
{
  WLFNListExit(this);

  WString sMsg;

  if (!m_sWLFileNameErr.IsEmpty())
    sMsg = TRLFormat("Error while loading the file\n\"%s\":\n%s",
      m_sWLFileNameErr, WordListInfoLbl->Caption) + WString("\n\n");

  WString sWordList = m_sWLFileName;
  if (m_sWLFileName.IsEmpty())
    sWordList = WString("<") + TRL("default (English) word list") + WString(">");
  else
    sWordList = WString("\"") + m_sWLFileName + WString("\"");

  sMsg += FormatW("%s\n%s.\n\n%s.\n\n%s %s\n%s %s\n%s %s",
    TRL("Currently loaded word list:"),
    sWordList, m_sWordListInfo,
    TRL("First word:"),
    m_passwGen.GetWord(0),
    TRL("Random word:"),
    m_passwGen.GetWord(fprng_rand() % m_passwGen.WordListSize),
    TRL("Last word:"),
    m_passwGen.GetWord(m_passwGen.WordListSize - 1));

  MsgBox(sMsg, MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::WLFNListKeyPress(TObject *Sender, char &Key)
{
  if (Key == VK_RETURN) {
    WordListInfoBtnClick(this);
    Key = 0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormatListEnter(TObject *Sender)
{
  ListMenu->PopupComponent = FormatList;
  ListMenuPopup(this);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::EntropyProgressMenuPopup(TObject *Sender)
{
  EntropyProgressMenu_TotalEntropyBits->Caption = TRLFormat("Total entropy bits: %d",
    g_pEntropyMng->TotalEntropyBits);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CharSetHelpBtnClick(TObject *Sender)
{
  QuickHelpForm->Execute(
    m_sCharSetHelp, 1,
    SettingsGroup->ClientOrigin.x,
    CharSetList->ClientOrigin.y + CharSetList->Height + 8);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormatPasswHelpBtnClick(TObject *Sender)
{
  QuickHelpForm->Execute(
    m_sFormatPasswHelp, 2,
    SettingsGroup->ClientOrigin.x,
    FormatList->ClientOrigin.y + CharSetList->Height + 8);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxChange(TObject *Sender)
{
  if (PasswBox->Tag & PASSWBOX_TAG_PASSWTEST) {
    int nPasswLen = GetEditBoxTextLen(PasswBox);
    int nPasswBits = 0;

    if (nPasswLen != 0) {
      SecureWString sPassw;
      GetEditBoxTextBuf(PasswBox, sPassw);

      nPasswBits = m_passwGen.EstimatePasswSecurity(sPassw);
    }

    ShowPasswInfo(nPasswLen, nPasswBits, true);
    //PasswInfoLbl->Font->Color = clTeal;
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenuPopup(TObject *Sender)
{
  bool blManip = !PasswBox->ReadOnly;
  bool blSelected = PasswBox->SelLength != 0;

  PasswBoxMenu_Undo->Enabled = blManip && PasswBox->CanUndo;
  PasswBoxMenu_Cut->Enabled = blManip && blSelected;
  PasswBoxMenu_Copy->Enabled = blSelected;
  PasswBoxMenu_EncryptCopy->Enabled = blSelected;
  PasswBoxMenu_Paste->Enabled = blManip && Clipboard()->HasFormat(CF_TEXT);
  PasswBoxMenu_Delete->Enabled = blManip && blSelected;
  PasswBoxMenu_SelectAll->Enabled = GetEditBoxTextLen(PasswBox) > 0;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenu_UndoClick(TObject *Sender)
{
  PasswBox->Undo();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenu_CutClick(TObject *Sender)
{
  PasswBox->CutToClipboard();
  CopiedSensitiveDataToClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenu_PasteClick(TObject *Sender)
{
  PasswBox->PasteFromClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenu_DeleteClick(TObject *Sender)
{
  PasswBox->SelText = "";
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenu_EditableClick(TObject *Sender)
{
  PasswBox->ReadOnly = !PasswBoxMenu_Editable->Checked;
  PasswBoxMenu_EnablePasswTest->Enabled = PasswBoxMenu_Editable->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Help_TimerInfoClick(TObject *Sender)
{
  WString sTimer;
  switch (g_highResTimer) {
  case hrtNone:
    sTimer = "N/A.";
//    TRL("Please note that a high-resolution timer\n"
//    "(like the time stamp counter on x86\nprocessors) can "
//    "substantially increase\nthe security of the random number\n"
//    "generator by providing high entropy\nwith every call.");
    break;
  case hrtRDTSC:
    sTimer = "Time stamp counter (RDTSC instruction).";
    break;
  case hrtQPC:
    sTimer = "QueryPerformanceCounter (Windows API).";
  }

  __int64 qValue;
  HighResTimer(&qValue);
  WString sValue = IntToStr(qValue);

  MsgBox(TRLFormat("High-resolution timer used:\n%s\n\nCurrent value: %s.",
    sTimer, sValue), MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ProfileEditorBtnClick(TObject *Sender)
{
  if (ProfileEditDlg->Execute())
    RecreateProfileMenus();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_File_ProfileClick(TObject *Sender)
{
  TTntMenuItem* pMenuItem = (TTntMenuItem*) Sender;

  LoadProfile(pMenuItem->Tag);

  Refresh();
  ShowInfoBox(TRLFormat("Profile \"%s\" activated.",
    ((PWGenProfile*) g_pProfileList->Items[pMenuItem->Tag])->ProfileName));
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::OnHotKey(TMessage& msg)
{
  if (m_blHotKeySet && Screen->ActiveForm != CallbackForm) {
    bool blWasMinimized = g_nAppState & APPSTATE_MINIMIZED;//m_blMinimized;

    if (m_config.HotKeyActShowMainWin || m_config.HotKeyAction == hkaPasswMsgBox
        || m_config.HotKeyAction == hkaOpenMPPG) {
      if (g_nAppState & APPSTATE_MINIMIZED)
        Application->Restore();
      Application->BringToFront();
    }

    if (m_config.HotKeyAction == hkaNone)
      return;
    else if (m_config.HotKeyAction == hkaOpenMPPG)
      MPPasswGenBtnClick(this);
    else {
      GeneratePasswDest dest;

      switch (m_config.HotKeyAction) {
      case hkaSinglePassw:
        dest = gpdGUISingle;
        break;
      case hkaPasswList:
        dest = gpdGUIList;
        break;
      case hkaPasswClipboard:
        dest = gpdClipboard;
        break;
      case hkaPasswMsgBox:
        dest = gpdMsgBox;
      }

      if (dest == gpdGUIList && Screen->ActiveForm != NULL &&
          Screen->ActiveForm->FormState.Contains(fsModal))
        return;

      GeneratePassw(dest);
    }

    if (m_config.HotKeyAction == hkaPasswMsgBox &&
        !m_config.HotKeyActShowMainWin && blWasMinimized)
      Application->Minimize();
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TrayMenuPopup(TObject *Sender)
{
  bool blEnable = true;
  if (Tag == MAINFORM_TAG_DISABLETRAYPOPUP)
    blEnable = false;
  else if (Screen->ActiveForm != NULL)
    blEnable = !(Screen->ActiveForm->FormState.Contains(fsModal) ||
      (Screen->ActiveForm == CallbackForm && CallbackForm->IsRunning()));

  for (int nI = 0; nI < TrayMenu->Items->Count; nI++)
    TrayMenu->Items->Items[nI]->Enabled = blEnable;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Tools_CreateTrigramFileClick(
      TObject *Sender)
{
  CreateTrigramFileDlg->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Help_CheckForUpdatesClick(
      TObject *Sender)
{
  Screen->Cursor = crHourGlass;

  switch (TUpdateCheckThread::CheckForUpdates(true)) {
  case 0:
    MsgBox(TRL("Your version of PWGen is up-to-date."), MB_ICONINFORMATION);
    // no break here!
  case 1:
    g_pIni->WriteDate(CONFIG_ID, "LastUpdateCheck", TDateTime::CurrentDate());
  }

  Screen->Cursor = crDefault;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Tools_MPPasswGenClick(TObject *Sender)
{
  MPPasswGenBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Tools_DetermRandGen_ResetClick(
      TObject *Sender)
{
  if (g_pKeySeededPRNG.get() != NULL) {
    g_pKeySeededPRNG->Reset();
    ShowInfoBox(TRL("Deterministic random generator has been RESET."));
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Tools_DetermRandGen_DeactivateClick(
      TObject *Sender)
{
  if (g_pKeySeededPRNG.get() != NULL) {
    g_pKeySeededPRNG.reset();
    g_pRandSrc = m_pRandPool;
    m_passwGen.RandGen = g_pRandSrc;

    Caption = PROGRAM_NAME;
    TntApplication->Title = PROGRAM_NAME;
    if (g_nAppState & APPSTATE_SYSTEMTRAY)
      TrayMessage(NIM_MODIFY);

    MainMenu_Tools_DetermRandGen->Enabled = false;

    ShowInfoBox(TRL("Deterministic random generator has been DEACTIVATED."));
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenu_EnablePasswTestClick(
      TObject *Sender)
{
  if (PasswBoxMenu_EnablePasswTest->Checked)
    PasswBox->Tag |= PASSWBOX_TAG_PASSWTEST;
  else
    PasswBox->Tag &= ~PASSWBOX_TAG_PASSWTEST;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_File_ExitClick(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswBoxMenu_EncryptCopyClick(TObject *Sender)
{
  SecureWString sText;
  GetEditBoxSelTextBuf(PasswBox, sText);
  CryptText(true, &sText);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Options_ConfigClick(TObject *Sender)
{
  if (ConfigurationDlg->ShowModal() != mrOk)
    ConfigurationDlg->SetOptions(m_config);
  g_fileEncoding = m_config.FileEncoding;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Tools_CreateRandDataFileClick(
      TObject *Sender)
{
  CreateRandDataFileDlg->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TntFormResize(TObject *Sender)
{
  Tag = MAINFORM_TAG_REPAINTCOMBOBOXES;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Options_AlwaysOnTopClick(
      TObject *Sender)
{
  TopMostManager* pMng = TopMostManager::GetInstance();
  pMng->AlwaysOnTop = MainMenu_Options_AlwaysOnTop->Checked;
  pMng->SetForm(this);
  if (!m_blStartup) {
    if (PasswListForm->Visible)
      pMng->SetForm(PasswListForm);
    if (MPPasswGenDlg->Visible)
      pMng->SetForm(MPPasswGenDlg);
    if (QuickHelpForm->Visible)
      pMng->SetForm(QuickHelpForm);
    if (!pMng->AlwaysOnTop) {
        QuickHelpForm->FormStyle = fsNormal;
        QuickHelpForm->FormStyle = fsStayOnTop;
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Tools_ProvideAddEntropy_AsTextClick(TObject *Sender)
{
  if (ProvideEntropyDlg->ShowModal() == mrOk)
    UpdateEntropyProgress();
  ClearEditBoxTextBuf(ProvideEntropyDlg->TextBox);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MainMenu_Tools_ProvideAddEntropy_FromFileClick(
      TObject *Sender)
{
  OpenDlg->FilterIndex = 0;
  OpenDlg->Title = TRL("Select high-entropy file");

  Tag = MAINFORM_TAG_DISABLETRAYPOPUP;

  if (OpenDlg->Execute()) {
    //TTntFileStream* pFile = NULL;
    WString sMsg;
    bool blSuccess = false;

    Screen->Cursor = crHourGlass;

    try {
      std::auto_ptr<TTntFileStream> pFile(new TTntFileStream(OpenDlg->FileName, fmOpenRead));

      static const int IO_BUFSIZE = 65536;
      SecureMem<word8> buf(IO_BUFSIZE);
      word32 lEntBits = 0;
      int nBytesRead;

      while ((nBytesRead = pFile->Read(buf, IO_BUFSIZE)) != 0) {
        lEntBits += g_pEntropyMng->AddData(buf, nBytesRead, 4, 4);
      }

      sMsg = TRLFormat("%d bits of entropy have been added to the random pool.",
        lEntBits);
      blSuccess = true;
    }
    catch (Exception& e) {
      sMsg = TRL("Could not open file.");
    }

    //if (pFile != NULL)
    //  delete pFile;
    m_pRandPool->Flush();
    UpdateEntropyProgress();

    Screen->Cursor = crDefault;

    MsgBox(sMsg, (blSuccess) ? MB_ICONINFORMATION : MB_ICONERROR);
  }

  Tag = 0;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PasswGroupMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
  if (Shift.Contains(ssLeft))
    StartEditBoxDragDrop(PasswBox);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::SpecifyLengthCheckClick(TObject *Sender)
{
  SpecifyLengthBox->Enabled = SpecifyLengthCheck->Checked;
  if (SpecifyLengthCheck->Checked && !m_blStartup)
    SpecifyLengthBox->SetFocus();
}
//---------------------------------------------------------------------------

