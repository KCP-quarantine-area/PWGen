// Configuration.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------

#ifndef ConfigurationH
#define ConfigurationH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "TntForms.hpp"
#include "TntComCtrls.hpp"
#include <ComCtrls.hpp>
#include "TntStdCtrls.hpp"
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
#include "UnicodeUtil.h"

enum TAutoCheckUpdates
  { acuDaily, acuWeekly, acuMonthly, acuDisabled };

enum THotKeyAction
  { hkaNone, hkaSinglePassw, hkaPasswList, hkaPasswClipboard,
    hkaPasswMsgBox, hkaOpenMPPG };

const int
  AUTOCLEARCLIPTIME_MIN     = 3,
  AUTOCLEARCLIPTIME_MAX     = 32767,
  AUTOCLEARCLIPTIME_DEFAULT = 10;


struct Configuration {
  AnsiString GUIFontName;
  int GUIFontSize;
  bool AutoClearClip;
  int AutoClearClipTime;
  bool ShowSysTrayIconConst;
  bool MinimizeToSysTray;
  TAutoCheckUpdates AutoCheckUpdates;
  bool HotKeyActivated;
  TShortCut HotKey;
  bool HotKeyActShowMainWin;
  THotKeyAction HotKeyAction;
  CharacterEncoding FileEncoding;
};


class TConfigurationDlg : public TTntForm
{
__published:	// IDE-managed Components
        TTntPageControl *ConfigPages;
        TTntTabSheet *GeneralSheet;
        TTntTabSheet *UpdatesSheet;
        TTntLabel *ChangeFontLbl;
        TTntButton *SelectFontBtn;
        TTntCheckBox *ShowSysTrayIconConstCheck;
        TTntCheckBox *MinimizeToSysTrayCheck;
        TTntLabel *AutoCheckUpdatesLbl;
        TTntComboBox *AutoCheckUpdatesList;
        TTntTabSheet *HotKeySheet;
        TTntCheckBox *ActivateHotKeyCheck;
        THotKey *HotKeyBox;
        TTntGroupBox *HotKeyActionsGroup;
        TTntCheckBox *HotKeyShowMainWinCheck;
        TTntComboBox *HotKeyActionsList;
        TTntButton *OKBtn;
        TTntButton *CancelBtn;
        TTntCheckBox *AutoClearClipCheck;
        TTntEdit *AutoClearClipTimeBox;
        TTntUpDown *AutoClearClipTimeSpinBtn;
        TFontDialog *FontDlg;
        TTntLabel *FontSampleLbl;
        TTntTabSheet *FilesSheet;
        TTntLabel *FileEncodingLbl;
        TTntComboBox *FileEncodingList;
        void __fastcall SelectFontBtnClick(TObject *Sender);
        void __fastcall AutoClearClipCheckClick(TObject *Sender);
        void __fastcall ActivateHotKeyCheckClick(TObject *Sender);
        void __fastcall TntFormShow(TObject *Sender);
        void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
        void __fastcall ShowFontSample(TFont* pFont);
public:		// User declarations
        __fastcall TConfigurationDlg(TComponent* Owner);
        void __fastcall LoadConfig(void);
        void __fastcall SaveConfig(void);
        void __fastcall GetOptions(Configuration& config);
        void __fastcall SetOptions(const Configuration& config);
};
//---------------------------------------------------------------------------
extern PACKAGE TConfigurationDlg *ConfigurationDlg;
//---------------------------------------------------------------------------
#endif
