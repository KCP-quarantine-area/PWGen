// Callback.h
//
// PWGEN FOR WINDOWS
// Copyright (c) 2002-2016 by Christian Thoeing <c.thoeing@web.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
// 02111-1307, USA.
//---------------------------------------------------------------------------
#ifndef CallbackH
#define CallbackH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include "TntForms.hpp"
#include "TntStdCtrls.hpp"
#include "TntComCtrls.hpp"
//---------------------------------------------------------------------------
#include "UnicodeUtil.h"

class ECallback : public Exception
{
public:
  ECallback(const AnsiString& asMsg) : Exception(asMsg)
  {
  }
};

class TCallbackForm : public TTntForm
{
__published:	// IDE-managed Components
        TTntProgressBar *ProgressBar;
        TTntLabel *ProgressLbl;
        TTntButton *CancelBtn;
        void __fastcall CancelBtnClick(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall TntFormShow(TObject *Sender);
private:	// User declarations
        TForm* m_pCaller;
        WString m_sErrMsg;
        WString m_sProgressInfo;
        int m_nMaxValue;

        enum CallbackState {
          STATE_IDLE,
          STATE_RUNNING,
          STATE_CANCELED
        };
        CallbackState m_state;
public:		// User declarations
        __fastcall TCallbackForm(TComponent* Owner);
        void __fastcall Init(TForm* pCaller,
                             const WString& sTitle,
                             const WString& sProgressInfo,
                             int nMaxValue);
        void __fastcall Callback(int nValue);
        void __fastcall Terminate(void);
        bool __fastcall IsRunning(void)
        {
          return m_state != STATE_IDLE;
        }
};
//---------------------------------------------------------------------------
extern PACKAGE TCallbackForm *CallbackForm;
//---------------------------------------------------------------------------
#endif
